-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Июл 18 2025 г., 09:35
-- Версия сервера: 5.7.24
-- Версия PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `smart-social`
--

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_actiondom`
--

CREATE TABLE `modx_access_actiondom` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_category`
--

CREATE TABLE `modx_access_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_context`
--

CREATE TABLE `modx_access_context` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_access_context`
--

INSERT INTO `modx_access_context` (`id`, `target`, `principal_class`, `principal`, `authority`, `policy`) VALUES
(1, 'web', 'MODX\\Revolution\\modUserGroup', 0, 9999, 3),
(2, 'mgr', 'MODX\\Revolution\\modUserGroup', 1, 0, 2),
(3, 'web', 'MODX\\Revolution\\modUserGroup', 1, 0, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_elements`
--

CREATE TABLE `modx_access_elements` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_media_source`
--

CREATE TABLE `modx_access_media_source` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_menus`
--

CREATE TABLE `modx_access_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_namespace`
--

CREATE TABLE `modx_access_namespace` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_permissions`
--

CREATE TABLE `modx_access_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `value` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_access_permissions`
--

INSERT INTO `modx_access_permissions` (`id`, `template`, `name`, `description`, `value`) VALUES
(1, 1, 'about', 'perm.about_desc', 1),
(2, 1, 'access_permissions', 'perm.access_permissions_desc', 1),
(3, 1, 'actions', 'perm.actions_desc', 1),
(4, 1, 'change_password', 'perm.change_password_desc', 1),
(5, 1, 'change_profile', 'perm.change_profile_desc', 1),
(6, 1, 'charsets', 'perm.charsets_desc', 1),
(7, 1, 'class_map', 'perm.class_map_desc', 1),
(8, 1, 'components', 'perm.components_desc', 1),
(9, 1, 'content_types', 'perm.content_types_desc', 1),
(10, 1, 'countries', 'perm.countries_desc', 1),
(11, 1, 'create', 'perm.create_desc', 1),
(12, 1, 'credits', 'perm.credits_desc', 1),
(13, 1, 'customize_forms', 'perm.customize_forms_desc', 1),
(14, 1, 'dashboards', 'perm.dashboards_desc', 1),
(15, 1, 'database', 'perm.database_desc', 1),
(16, 1, 'database_truncate', 'perm.database_truncate_desc', 1),
(17, 1, 'delete_category', 'perm.delete_category_desc', 1),
(18, 1, 'delete_chunk', 'perm.delete_chunk_desc', 1),
(19, 1, 'delete_context', 'perm.delete_context_desc', 1),
(20, 1, 'delete_document', 'perm.delete_document_desc', 1),
(21, 1, 'delete_weblink', 'perm.delete_weblink_desc', 1),
(22, 1, 'delete_symlink', 'perm.delete_symlink_desc', 1),
(23, 1, 'delete_static_resource', 'perm.delete_static_resource_desc', 1),
(24, 1, 'delete_eventlog', 'perm.delete_eventlog_desc', 1),
(25, 1, 'delete_plugin', 'perm.delete_plugin_desc', 1),
(26, 1, 'delete_propertyset', 'perm.delete_propertyset_desc', 1),
(27, 1, 'delete_snippet', 'perm.delete_snippet_desc', 1),
(28, 1, 'delete_template', 'perm.delete_template_desc', 1),
(29, 1, 'delete_tv', 'perm.delete_tv_desc', 1),
(30, 1, 'delete_role', 'perm.delete_role_desc', 1),
(31, 1, 'delete_user', 'perm.delete_user_desc', 1),
(32, 1, 'directory_chmod', 'perm.directory_chmod_desc', 1),
(33, 1, 'directory_create', 'perm.directory_create_desc', 1),
(34, 1, 'directory_list', 'perm.directory_list_desc', 1),
(35, 1, 'directory_remove', 'perm.directory_remove_desc', 1),
(36, 1, 'directory_update', 'perm.directory_update_desc', 1),
(37, 1, 'edit_category', 'perm.edit_category_desc', 1),
(38, 1, 'edit_chunk', 'perm.edit_chunk_desc', 1),
(39, 1, 'edit_context', 'perm.edit_context_desc', 1),
(40, 1, 'edit_document', 'perm.edit_document_desc', 1),
(41, 1, 'edit_weblink', 'perm.edit_weblink_desc', 1),
(42, 1, 'edit_symlink', 'perm.edit_symlink_desc', 1),
(43, 1, 'edit_static_resource', 'perm.edit_static_resource_desc', 1),
(44, 1, 'edit_locked', 'perm.edit_locked_desc', 1),
(45, 1, 'edit_plugin', 'perm.edit_plugin_desc', 1),
(46, 1, 'edit_propertyset', 'perm.edit_propertyset_desc', 1),
(47, 1, 'edit_role', 'perm.edit_role_desc', 1),
(48, 1, 'edit_snippet', 'perm.edit_snippet_desc', 1),
(49, 1, 'edit_template', 'perm.edit_template_desc', 1),
(50, 1, 'edit_tv', 'perm.edit_tv_desc', 1),
(51, 1, 'edit_user', 'perm.edit_user_desc', 1),
(52, 1, 'element_tree', 'perm.element_tree_desc', 1),
(53, 1, 'empty_cache', 'perm.empty_cache_desc', 1),
(54, 1, 'error_log_erase', 'perm.error_log_erase_desc', 1),
(55, 1, 'error_log_view', 'perm.error_log_view_desc', 1),
(56, 1, 'export_static', 'perm.export_static_desc', 1),
(57, 1, 'file_create', 'perm.file_create_desc', 1),
(58, 1, 'file_list', 'perm.file_list_desc', 1),
(59, 1, 'file_manager', 'perm.file_manager_desc', 1),
(60, 1, 'file_remove', 'perm.file_remove_desc', 1),
(61, 1, 'file_tree', 'perm.file_tree_desc', 1),
(62, 1, 'file_update', 'perm.file_update_desc', 1),
(63, 1, 'file_upload', 'perm.file_upload_desc', 1),
(64, 1, 'file_unpack', 'perm.file_unpack_desc', 1),
(65, 1, 'file_view', 'perm.file_view_desc', 1),
(66, 1, 'flush_sessions', 'perm.flush_sessions_desc', 1),
(67, 1, 'frames', 'perm.frames_desc', 1),
(68, 1, 'help', 'perm.help_desc', 1),
(69, 1, 'home', 'perm.home_desc', 1),
(70, 1, 'language', 'perm.language_desc', 1),
(71, 1, 'languages', 'perm.languages_desc', 1),
(72, 1, 'lexicons', 'perm.lexicons_desc', 1),
(73, 1, 'list', 'perm.list_desc', 1),
(74, 1, 'load', 'perm.load_desc', 1),
(75, 1, 'logout', 'perm.logout_desc', 1),
(76, 1, 'mgr_log_view', 'perm.mgr_log_view_desc', 1),
(77, 1, 'mgr_log_erase', 'perm.mgr_log_erase_desc', 1),
(78, 1, 'menu_reports', 'perm.menu_reports_desc', 1),
(79, 1, 'menu_security', 'perm.menu_security_desc', 1),
(80, 1, 'menu_site', 'perm.menu_site_desc', 1),
(81, 1, 'menu_support', 'perm.menu_support_desc', 1),
(82, 1, 'menu_system', 'perm.menu_system_desc', 1),
(83, 1, 'menu_tools', 'perm.menu_tools_desc', 1),
(84, 1, 'menu_trash', 'perm.menu_trash_desc', 1),
(85, 1, 'menu_user', 'perm.menu_user_desc', 1),
(86, 1, 'menus', 'perm.menus_desc', 1),
(87, 1, 'messages', 'perm.messages_desc', 1),
(88, 1, 'namespaces', 'perm.namespaces_desc', 1),
(89, 1, 'new_category', 'perm.new_category_desc', 1),
(90, 1, 'new_chunk', 'perm.new_chunk_desc', 1),
(91, 1, 'new_context', 'perm.new_context_desc', 1),
(92, 1, 'new_document', 'perm.new_document_desc', 1),
(93, 1, 'new_static_resource', 'perm.new_static_resource_desc', 1),
(94, 1, 'new_symlink', 'perm.new_symlink_desc', 1),
(95, 1, 'new_weblink', 'perm.new_weblink_desc', 1),
(96, 1, 'new_document_in_root', 'perm.new_document_in_root_desc', 1),
(97, 1, 'new_plugin', 'perm.new_plugin_desc', 1),
(98, 1, 'new_propertyset', 'perm.new_propertyset_desc', 1),
(99, 1, 'new_role', 'perm.new_role_desc', 1),
(100, 1, 'new_snippet', 'perm.new_snippet_desc', 1),
(101, 1, 'new_template', 'perm.new_template_desc', 1),
(102, 1, 'new_tv', 'perm.new_tv_desc', 1),
(103, 1, 'new_user', 'perm.new_user_desc', 1),
(104, 1, 'packages', 'perm.packages_desc', 1),
(105, 1, 'policy_delete', 'perm.policy_delete_desc', 1),
(106, 1, 'policy_edit', 'perm.policy_edit_desc', 1),
(107, 1, 'policy_new', 'perm.policy_new_desc', 1),
(108, 1, 'policy_save', 'perm.policy_save_desc', 1),
(109, 1, 'policy_view', 'perm.policy_view_desc', 1),
(110, 1, 'policy_template_delete', 'perm.policy_template_delete_desc', 1),
(111, 1, 'policy_template_edit', 'perm.policy_template_edit_desc', 1),
(112, 1, 'policy_template_new', 'perm.policy_template_new_desc', 1),
(113, 1, 'policy_template_save', 'perm.policy_template_save_desc', 1),
(114, 1, 'policy_template_view', 'perm.policy_template_view_desc', 1),
(115, 1, 'property_sets', 'perm.property_sets_desc', 1),
(116, 1, 'providers', 'perm.providers_desc', 1),
(117, 1, 'publish_document', 'perm.publish_document_desc', 1),
(118, 1, 'purge_deleted', 'perm.purge_deleted_desc', 1),
(119, 1, 'remove', 'perm.remove_desc', 1),
(120, 1, 'remove_locks', 'perm.remove_locks_desc', 1),
(121, 1, 'resource_duplicate', 'perm.resource_duplicate_desc', 1),
(122, 1, 'resourcegroup_delete', 'perm.resourcegroup_delete_desc', 1),
(123, 1, 'resourcegroup_edit', 'perm.resourcegroup_edit_desc', 1),
(124, 1, 'resourcegroup_new', 'perm.resourcegroup_new_desc', 1),
(125, 1, 'resourcegroup_resource_edit', 'perm.resourcegroup_resource_edit_desc', 1),
(126, 1, 'resourcegroup_resource_list', 'perm.resourcegroup_resource_list_desc', 1),
(127, 1, 'resourcegroup_save', 'perm.resourcegroup_save_desc', 1),
(128, 1, 'resourcegroup_view', 'perm.resourcegroup_view_desc', 1),
(129, 1, 'resource_quick_create', 'perm.resource_quick_create_desc', 1),
(130, 1, 'resource_quick_update', 'perm.resource_quick_update_desc', 1),
(131, 1, 'resource_tree', 'perm.resource_tree_desc', 1),
(132, 1, 'save', 'perm.save_desc', 1),
(133, 1, 'save_category', 'perm.save_category_desc', 1),
(134, 1, 'save_chunk', 'perm.save_chunk_desc', 1),
(135, 1, 'save_context', 'perm.save_context_desc', 1),
(136, 1, 'save_document', 'perm.save_document_desc', 1),
(137, 1, 'save_plugin', 'perm.save_plugin_desc', 1),
(138, 1, 'save_propertyset', 'perm.save_propertyset_desc', 1),
(139, 1, 'save_role', 'perm.save_role_desc', 1),
(140, 1, 'save_snippet', 'perm.save_snippet_desc', 1),
(141, 1, 'save_template', 'perm.save_template_desc', 1),
(142, 1, 'save_tv', 'perm.save_tv_desc', 1),
(143, 1, 'save_user', 'perm.save_user_desc', 1),
(144, 1, 'search', 'perm.search_desc', 1),
(145, 1, 'set_sudo', 'perm.set_sudo_desc', 1),
(146, 1, 'settings', 'perm.settings_desc', 1),
(147, 1, 'events', 'perm.events_desc', 1),
(148, 1, 'source_save', 'perm.source_save_desc', 1),
(149, 1, 'source_delete', 'perm.source_delete_desc', 1),
(150, 1, 'source_edit', 'perm.source_edit_desc', 1),
(151, 1, 'source_view', 'perm.source_view_desc', 1),
(152, 1, 'sources', 'perm.sources_desc', 1),
(153, 1, 'steal_locks', 'perm.steal_locks_desc', 1),
(154, 1, 'tree_show_element_ids', 'perm.tree_show_element_ids_desc', 1),
(155, 1, 'tree_show_resource_ids', 'perm.tree_show_resource_ids_desc', 1),
(156, 1, 'undelete_document', 'perm.undelete_document_desc', 1),
(157, 1, 'unpublish_document', 'perm.unpublish_document_desc', 1),
(158, 1, 'unlock_element_properties', 'perm.unlock_element_properties_desc', 1),
(159, 1, 'usergroup_delete', 'perm.usergroup_delete_desc', 1),
(160, 1, 'usergroup_edit', 'perm.usergroup_edit_desc', 1),
(161, 1, 'usergroup_new', 'perm.usergroup_new_desc', 1),
(162, 1, 'usergroup_save', 'perm.usergroup_save_desc', 1),
(163, 1, 'usergroup_user_edit', 'perm.usergroup_user_edit_desc', 1),
(164, 1, 'usergroup_user_list', 'perm.usergroup_user_list_desc', 1),
(165, 1, 'usergroup_view', 'perm.usergroup_view_desc', 1),
(166, 1, 'view', 'perm.view_desc', 1),
(167, 1, 'view_category', 'perm.view_category_desc', 1),
(168, 1, 'view_chunk', 'perm.view_chunk_desc', 1),
(169, 1, 'view_context', 'perm.view_context_desc', 1),
(170, 1, 'view_document', 'perm.view_document_desc', 1),
(171, 1, 'view_element', 'perm.view_element_desc', 1),
(172, 1, 'view_eventlog', 'perm.view_eventlog_desc', 1),
(173, 1, 'view_offline', 'perm.view_offline_desc', 1),
(174, 1, 'view_plugin', 'perm.view_plugin_desc', 1),
(175, 1, 'view_propertyset', 'perm.view_propertyset_desc', 1),
(176, 1, 'view_role', 'perm.view_role_desc', 1),
(177, 1, 'view_snippet', 'perm.view_snippet_desc', 1),
(178, 1, 'view_sysinfo', 'perm.view_sysinfo_desc', 1),
(179, 1, 'view_template', 'perm.view_template_desc', 1),
(180, 1, 'view_tv', 'perm.view_tv_desc', 1),
(181, 1, 'view_user', 'perm.view_user_desc', 1),
(182, 1, 'view_unpublished', 'perm.view_unpublished_desc', 1),
(183, 1, 'workspaces', 'perm.workspaces_desc', 1),
(184, 2, 'add_children', 'perm.add_children_desc', 1),
(185, 2, 'copy', 'perm.copy_desc', 1),
(186, 2, 'create', 'perm.create_desc', 1),
(187, 2, 'delete', 'perm.delete_desc', 1),
(188, 2, 'list', 'perm.list_desc', 1),
(189, 2, 'load', 'perm.load_desc', 1),
(190, 2, 'move', 'perm.move_desc', 1),
(191, 2, 'publish', 'perm.publish_desc', 1),
(192, 2, 'remove', 'perm.remove_desc', 1),
(193, 2, 'save', 'perm.save_desc', 1),
(194, 2, 'steal_lock', 'perm.steal_lock_desc', 1),
(195, 2, 'undelete', 'perm.undelete_desc', 1),
(196, 2, 'unpublish', 'perm.unpublish_desc', 1),
(197, 2, 'view', 'perm.view_desc', 1),
(198, 3, 'load', 'perm.load_desc', 1),
(199, 3, 'list', 'perm.list_desc', 1),
(200, 3, 'view', 'perm.view_desc', 1),
(201, 3, 'save', 'perm.save_desc', 1),
(202, 3, 'remove', 'perm.remove_desc', 1),
(203, 4, 'add_children', 'perm.add_children_desc', 1),
(204, 4, 'create', 'perm.create_desc', 1),
(205, 4, 'copy', 'perm.copy_desc', 1),
(206, 4, 'delete', 'perm.delete_desc', 1),
(207, 4, 'list', 'perm.list_desc', 1),
(208, 4, 'load', 'perm.load_desc', 1),
(209, 4, 'remove', 'perm.remove_desc', 1),
(210, 4, 'save', 'perm.save_desc', 1),
(211, 4, 'view', 'perm.view_desc', 1),
(212, 5, 'create', 'perm.create_desc', 1),
(213, 5, 'copy', 'perm.copy_desc', 1),
(214, 5, 'list', 'perm.list_desc', 1),
(215, 5, 'load', 'perm.load_desc', 1),
(216, 5, 'remove', 'perm.remove_desc', 1),
(217, 5, 'save', 'perm.save_desc', 1),
(218, 5, 'view', 'perm.view_desc', 1),
(219, 6, 'load', 'perm.load_desc', 1),
(220, 6, 'list', 'perm.list_desc', 1),
(221, 6, 'view', 'perm.view_desc', 1),
(222, 6, 'save', 'perm.save_desc', 1),
(223, 6, 'remove', 'perm.remove_desc', 1),
(224, 6, 'view_unpublished', 'perm.view_unpublished_desc', 1),
(225, 6, 'copy', 'perm.copy_desc', 1),
(226, 7, 'list', 'perm.list_desc', 1),
(227, 7, 'load', 'perm.load_desc', 1),
(228, 7, 'view', 'perm.view_desc', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_policies`
--

CREATE TABLE `modx_access_policies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `class` varchar(191) NOT NULL DEFAULT '',
  `data` text,
  `lexicon` varchar(255) NOT NULL DEFAULT 'permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_access_policies`
--

INSERT INTO `modx_access_policies` (`id`, `name`, `description`, `parent`, `template`, `class`, `data`, `lexicon`) VALUES
(1, 'Resource', 'policy_resource_desc', 0, 2, '', '{\"add_children\":true,\"create\":true,\"copy\":true,\"delete\":true,\"list\":true,\"load\":true,\"move\":true,\"publish\":true,\"remove\":true,\"save\":true,\"steal_lock\":true,\"undelete\":true,\"unpublish\":true,\"view\":true}', 'permissions'),
(2, 'Administrator', 'policy_administrator_desc', 0, 1, '', '{\"about\":true,\"access_permissions\":true,\"actions\":true,\"change_password\":true,\"change_profile\":true,\"charsets\":true,\"class_map\":true,\"components\":true,\"content_types\":true,\"countries\":true,\"create\":true,\"credits\":true,\"customize_forms\":true,\"dashboards\":true,\"database\":true,\"database_truncate\":true,\"delete_category\":true,\"delete_chunk\":true,\"delete_context\":true,\"delete_document\":true,\"delete_eventlog\":true,\"delete_plugin\":true,\"delete_propertyset\":true,\"delete_role\":true,\"delete_snippet\":true,\"delete_static_resource\":true,\"delete_symlink\":true,\"delete_template\":true,\"delete_tv\":true,\"delete_user\":true,\"delete_weblink\":true,\"directory_chmod\":true,\"directory_create\":true,\"directory_list\":true,\"directory_remove\":true,\"directory_update\":true,\"edit_category\":true,\"edit_chunk\":true,\"edit_context\":true,\"edit_document\":true,\"edit_locked\":true,\"edit_plugin\":true,\"edit_propertyset\":true,\"edit_role\":true,\"edit_snippet\":true,\"edit_static_resource\":true,\"edit_symlink\":true,\"edit_template\":true,\"edit_tv\":true,\"edit_user\":true,\"edit_weblink\":true,\"element_tree\":true,\"empty_cache\":true,\"error_log_erase\":true,\"error_log_view\":true,\"events\":true,\"export_static\":true,\"file_create\":true,\"file_list\":true,\"file_manager\":true,\"file_remove\":true,\"file_tree\":true,\"file_unpack\":true,\"file_update\":true,\"file_upload\":true,\"file_view\":true,\"flush_sessions\":true,\"frames\":true,\"help\":true,\"home\":true,\"language\":true,\"languages\":true,\"lexicons\":true,\"list\":true,\"load\":true,\"logout\":true,\"mgr_log_view\":true,\"mgr_log_erase\":true,\"menu_reports\":true,\"menu_security\":true,\"menu_site\":true,\"menu_support\":true,\"menu_system\":true,\"menu_tools\":true,\"menu_trash\":true,\"menu_user\":true,\"menus\":true,\"messages\":true,\"namespaces\":true,\"new_category\":true,\"new_chunk\":true,\"new_context\":true,\"new_document\":true,\"new_document_in_root\":true,\"new_plugin\":true,\"new_propertyset\":true,\"new_role\":true,\"new_snippet\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_template\":true,\"new_tv\":true,\"new_user\":true,\"new_weblink\":true,\"packages\":true,\"policy_delete\":true,\"policy_edit\":true,\"policy_new\":true,\"policy_save\":true,\"policy_template_delete\":true,\"policy_template_edit\":true,\"policy_template_new\":true,\"policy_template_save\":true,\"policy_template_view\":true,\"policy_view\":true,\"property_sets\":true,\"providers\":true,\"publish_document\":true,\"purge_deleted\":true,\"remove\":true,\"remove_locks\":true,\"resource_duplicate\":true,\"resource_quick_create\":true,\"resource_quick_update\":true,\"resource_tree\":true,\"resourcegroup_delete\":true,\"resourcegroup_edit\":true,\"resourcegroup_new\":true,\"resourcegroup_resource_edit\":true,\"resourcegroup_resource_list\":true,\"resourcegroup_save\":true,\"resourcegroup_view\":true,\"save\":true,\"save_category\":true,\"save_chunk\":true,\"save_context\":true,\"save_document\":true,\"save_plugin\":true,\"save_propertyset\":true,\"save_role\":true,\"save_snippet\":true,\"save_template\":true,\"save_tv\":true,\"save_user\":true,\"search\":true,\"set_sudo\":true,\"settings\":true,\"source_delete\":true,\"source_edit\":true,\"source_save\":true,\"source_view\":true,\"sources\":true,\"steal_locks\":true,\"tree_show_element_ids\":true,\"tree_show_resource_ids\":true,\"undelete_document\":true,\"unlock_element_properties\":true,\"unpublish_document\":true,\"usergroup_delete\":true,\"usergroup_edit\":true,\"usergroup_new\":true,\"usergroup_save\":true,\"usergroup_user_edit\":true,\"usergroup_user_list\":true,\"usergroup_view\":true,\"view\":true,\"view_category\":true,\"view_chunk\":true,\"view_context\":true,\"view_document\":true,\"view_element\":true,\"view_eventlog\":true,\"view_offline\":true,\"view_plugin\":true,\"view_propertyset\":true,\"view_role\":true,\"view_snippet\":true,\"view_sysinfo\":true,\"view_template\":true,\"view_tv\":true,\"view_unpublished\":true,\"view_user\":true,\"workspaces\":true}', 'permissions'),
(3, 'Load Only', 'policy_load_only_desc', 0, 3, '', '{\"load\":true}', 'permissions'),
(4, 'Load, List and View', 'policy_load_list_and_view_desc', 0, 3, '', '{\"load\":true,\"list\":true,\"view\":true}', 'permissions'),
(5, 'Object', 'policy_object_desc', 0, 3, '', '{\"load\":true,\"list\":true,\"view\":true,\"save\":true,\"remove\":true}', 'permissions'),
(6, 'Element', 'policy_element_desc', 0, 4, '', '{\"add_children\":true,\"create\":true,\"delete\":true,\"list\":true,\"load\":true,\"remove\":true,\"save\":true,\"view\":true,\"copy\":true}', 'permissions'),
(7, 'Content Editor', 'policy_content_editor_desc', 0, 1, '', '{\"change_profile\":true,\"class_map\":true,\"countries\":true,\"delete_document\":true,\"delete_static_resource\":true,\"delete_symlink\":true,\"delete_weblink\":true,\"edit_document\":true,\"edit_static_resource\":true,\"edit_symlink\":true,\"edit_weblink\":true,\"frames\":true,\"help\":true,\"home\":true,\"language\":true,\"list\":true,\"load\":true,\"logout\":true,\"menu_reports\":true,\"menu_site\":true,\"menu_support\":true,\"menu_tools\":true,\"menu_user\":true,\"new_document\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_weblink\":true,\"resource_duplicate\":true,\"resource_tree\":true,\"save_document\":true,\"source_view\":true,\"tree_show_resource_ids\":true,\"view\":true,\"view_document\":true,\"view_template\":true}', 'permissions'),
(8, 'Media Source Admin', 'policy_media_source_admin_desc', 0, 5, '', '{\"create\":true,\"copy\":true,\"load\":true,\"list\":true,\"save\":true,\"remove\":true,\"view\":true}', 'permissions'),
(9, 'Media Source User', 'policy_media_source_user_desc', 0, 5, '', '{\"load\":true,\"list\":true,\"view\":true}', 'permissions'),
(10, 'Developer', 'policy_developer_desc', 0, 1, '', '{\"about\":true,\"change_password\":true,\"change_profile\":true,\"charsets\":true,\"class_map\":true,\"components\":true,\"content_types\":true,\"countries\":true,\"create\":true,\"credits\":true,\"customize_forms\":true,\"dashboards\":true,\"database\":true,\"delete_category\":true,\"delete_chunk\":true,\"delete_context\":true,\"delete_document\":true,\"delete_eventlog\":true,\"delete_plugin\":true,\"delete_propertyset\":true,\"delete_role\":true,\"delete_snippet\":true,\"delete_template\":true,\"delete_tv\":true,\"delete_user\":true,\"directory_chmod\":true,\"directory_create\":true,\"directory_list\":true,\"directory_remove\":true,\"directory_update\":true,\"edit_category\":true,\"edit_chunk\":true,\"edit_context\":true,\"edit_document\":true,\"edit_locked\":true,\"edit_plugin\":true,\"edit_propertyset\":true,\"edit_role\":true,\"edit_snippet\":true,\"edit_static_resource\":true,\"edit_symlink\":true,\"edit_template\":true,\"edit_tv\":true,\"edit_user\":true,\"edit_weblink\":true,\"element_tree\":true,\"empty_cache\":true,\"error_log_erase\":true,\"error_log_view\":true,\"export_static\":true,\"file_create\":true,\"file_list\":true,\"file_manager\":true,\"file_remove\":true,\"file_tree\":true,\"file_unpack\":true,\"file_update\":true,\"file_upload\":true,\"file_view\":true,\"frames\":true,\"help\":true,\"home\":true,\"language\":true,\"languages\":true,\"lexicons\":true,\"list\":true,\"load\":true,\"logout\":true,\"mgr_log_view\":true,\"mgr_log_erase\":true,\"menu_reports\":true,\"menu_site\":true,\"menu_support\":true,\"menu_system\":true,\"menu_tools\":true,\"menu_user\":true,\"menus\":true,\"messages\":true,\"namespaces\":true,\"new_category\":true,\"new_chunk\":true,\"new_context\":true,\"new_document\":true,\"new_document_in_root\":true,\"new_plugin\":true,\"new_propertyset\":true,\"new_role\":true,\"new_snippet\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_template\":true,\"new_tv\":true,\"new_user\":true,\"new_weblink\":true,\"packages\":true,\"property_sets\":true,\"providers\":true,\"publish_document\":true,\"purge_deleted\":true,\"remove\":true,\"resource_duplicate\":true,\"resource_quick_create\":true,\"resource_quick_update\":true,\"resource_tree\":true,\"save\":true,\"save_category\":true,\"save_chunk\":true,\"save_context\":true,\"save_document\":true,\"save_plugin\":true,\"save_propertyset\":true,\"save_snippet\":true,\"save_template\":true,\"save_tv\":true,\"save_user\":true,\"search\":true,\"settings\":true,\"source_delete\":true,\"source_edit\":true,\"source_save\":true,\"source_view\":true,\"sources\":true,\"tree_show_element_ids\":true,\"tree_show_resource_ids\":true,\"undelete_document\":true,\"unlock_element_properties\":true,\"unpublish_document\":true,\"view\":true,\"view_category\":true,\"view_chunk\":true,\"view_context\":true,\"view_document\":true,\"view_element\":true,\"view_eventlog\":true,\"view_offline\":true,\"view_plugin\":true,\"view_propertyset\":true,\"view_role\":true,\"view_snippet\":true,\"view_sysinfo\":true,\"view_template\":true,\"view_tv\":true,\"view_unpublished\":true,\"view_user\":true,\"workspaces\":true}', 'permissions'),
(11, 'Context', 'policy_context_desc', 0, 6, '', '{\"load\":true,\"list\":true,\"view\":true,\"save\":true,\"remove\":true,\"copy\":true,\"view_unpublished\":true}', 'permissions'),
(12, 'Hidden Namespace', 'policy_hidden_namespace_desc', 0, 7, '', '{\"load\":false,\"list\":false,\"view\":true}', 'permissions');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_policy_templates`
--

CREATE TABLE `modx_access_policy_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `template_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` mediumtext,
  `lexicon` varchar(255) NOT NULL DEFAULT 'permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_access_policy_templates`
--

INSERT INTO `modx_access_policy_templates` (`id`, `template_group`, `name`, `description`, `lexicon`) VALUES
(1, 1, 'AdministratorTemplate', 'policy_template_administrator_desc', 'permissions'),
(2, 3, 'ResourceTemplate', 'policy_template_resource_desc', 'permissions'),
(3, 2, 'ObjectTemplate', 'policy_template_object_desc', 'permissions'),
(4, 4, 'ElementTemplate', 'policy_template_element_desc', 'permissions'),
(5, 5, 'MediaSourceTemplate', 'policy_template_mediasource_desc', 'permissions'),
(6, 7, 'ContextTemplate', 'policy_template_context_desc', 'permissions'),
(7, 6, 'NamespaceTemplate', 'policy_template_namespace_desc', 'permissions');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_policy_template_groups`
--

CREATE TABLE `modx_access_policy_template_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_access_policy_template_groups`
--

INSERT INTO `modx_access_policy_template_groups` (`id`, `name`, `description`) VALUES
(1, 'Administrator', 'policy_template_group_administrator_desc'),
(2, 'Object', 'policy_template_group_object_desc'),
(3, 'Resource', 'policy_template_group_resource_desc'),
(4, 'Element', 'policy_template_group_element_desc'),
(5, 'MediaSource', 'policy_template_group_mediasource_desc'),
(6, 'Namespace', 'policy_template_group_namespace_desc'),
(7, 'Context', 'policy_template_group_context_desc');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_resources`
--

CREATE TABLE `modx_access_resources` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_resource_groups`
--

CREATE TABLE `modx_access_resource_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_access_templatevars`
--

CREATE TABLE `modx_access_templatevars` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_actiondom`
--

CREATE TABLE `modx_actiondom` (
  `id` int(10) UNSIGNED NOT NULL,
  `set` int(11) NOT NULL DEFAULT '0',
  `action` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `xtype` varchar(100) NOT NULL DEFAULT '',
  `container` varchar(255) NOT NULL DEFAULT '',
  `rule` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `constraint` varchar(255) NOT NULL DEFAULT '',
  `constraint_field` varchar(100) NOT NULL DEFAULT '',
  `constraint_class` varchar(100) NOT NULL DEFAULT '',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `for_parent` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_actions_fields`
--

CREATE TABLE `modx_actions_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `action` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(100) NOT NULL DEFAULT 'field',
  `tab` varchar(191) NOT NULL DEFAULT '',
  `form` varchar(255) NOT NULL DEFAULT '',
  `other` varchar(255) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_actions_fields`
--

INSERT INTO `modx_actions_fields` (`id`, `action`, `name`, `type`, `tab`, `form`, `other`, `rank`) VALUES
(1, 'resource/update', 'modx-resource-settings', 'tab', '', 'modx-panel-resource', '', 0),
(2, 'resource/update', 'modx-resource-main-left', 'tab', '', 'modx-panel-resource', '', 1),
(3, 'resource/update', 'id', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 0),
(4, 'resource/update', 'pagetitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 1),
(5, 'resource/update', 'alias', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 2),
(6, 'resource/update', 'longtitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 3),
(7, 'resource/update', 'description', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 4),
(8, 'resource/update', 'introtext', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 5),
(9, 'resource/update', 'modx-resource-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 0),
(10, 'resource/update', 'modx-resource-main-right', 'tab', '', 'modx-panel-resource', '', 3),
(11, 'resource/update', 'modx-resource-main-right-top', 'tab', '', 'modx-panel-resource', '', 4),
(12, 'resource/update', 'published', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 0),
(13, 'resource/update', 'deleted', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 1),
(14, 'resource/update', 'publishedon', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 2),
(15, 'resource/update', 'pub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 3),
(16, 'resource/update', 'unpub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 4),
(17, 'resource/update', 'modx-resource-main-right-middle', 'tab', '', 'modx-panel-resource', '', 5),
(18, 'resource/update', 'template', 'field', 'modx-resource-main-right-middle', 'modx-panel-resource', '', 0),
(19, 'resource/update', 'modx-resource-main-right-bottom', 'tab', '', 'modx-panel-resource', '', 6),
(20, 'resource/update', 'hidemenu', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 0),
(21, 'resource/update', 'menutitle', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 1),
(22, 'resource/update', 'link_attributes', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 2),
(23, 'resource/update', 'menuindex', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 3),
(24, 'resource/update', 'modx-page-settings', 'tab', '', 'modx-panel-resource', '', 7),
(25, 'resource/update', 'modx-page-settings-left', 'tab', '', 'modx-panel-resource', '', 8),
(26, 'resource/update', 'class_key', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 0),
(27, 'resource/update', 'content_type', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 1),
(28, 'resource/update', 'modx-page-settings-right', 'tab', '', 'modx-panel-resource', '', 9),
(29, 'resource/update', 'parent-cmb', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 0),
(30, 'resource/update', 'content_dispo', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 1),
(31, 'resource/update', 'modx-page-settings-box-left', 'tab', '', 'modx-panel-resource', '', 10),
(32, 'resource/update', 'isfolder', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 0),
(33, 'resource/update', 'show_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 1),
(34, 'resource/update', 'hide_children_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 2),
(35, 'resource/update', 'alias_visible', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 3),
(36, 'resource/update', 'uri_override', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 4),
(37, 'resource/update', 'uri', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 5),
(38, 'resource/update', 'modx-page-settings-box-right', 'tab', '', 'modx-panel-resource', '', 11),
(39, 'resource/update', 'richtext', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 0),
(40, 'resource/update', 'cacheable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 1),
(41, 'resource/update', 'searchable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 2),
(42, 'resource/update', 'syncsite', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 3),
(43, 'resource/update', 'modx-panel-resource-tv', 'tab', '', 'modx-panel-resource', 'tv', 12),
(44, 'resource/update', 'modx-resource-access-permissions', 'tab', '', 'modx-panel-resource', '', 13),
(45, 'resource/create', 'modx-resource-settings', 'tab', '', 'modx-panel-resource', '', 0),
(46, 'resource/create', 'modx-resource-main-left', 'tab', '', 'modx-panel-resource', '', 1),
(47, 'resource/create', 'id', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 0),
(48, 'resource/create', 'pagetitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 1),
(49, 'resource/create', 'alias', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 2),
(50, 'resource/create', 'longtitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 3),
(51, 'resource/create', 'description', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 4),
(52, 'resource/create', 'introtext', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 5),
(53, 'resource/create', 'modx-resource-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 0),
(54, 'resource/create', 'modx-resource-main-right', 'tab', '', 'modx-panel-resource', '', 3),
(55, 'resource/create', 'modx-resource-main-right-top', 'tab', '', 'modx-panel-resource', '', 4),
(56, 'resource/create', 'published', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 0),
(57, 'resource/create', 'deleted', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 1),
(58, 'resource/create', 'publishedon', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 2),
(59, 'resource/create', 'pub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 3),
(60, 'resource/create', 'unpub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 4),
(61, 'resource/create', 'modx-resource-main-right-middle', 'tab', '', 'modx-panel-resource', '', 5),
(62, 'resource/create', 'template', 'field', 'modx-resource-main-right-middle', 'modx-panel-resource', '', 0),
(63, 'resource/create', 'modx-resource-main-right-bottom', 'tab', '', 'modx-panel-resource', '', 6),
(64, 'resource/create', 'hidemenu', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 0),
(65, 'resource/create', 'menutitle', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 1),
(66, 'resource/create', 'link_attributes', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 2),
(67, 'resource/create', 'menuindex', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 3),
(68, 'resource/create', 'modx-page-settings', 'tab', '', 'modx-panel-resource', '', 7),
(69, 'resource/create', 'modx-page-settings-left', 'tab', '', 'modx-panel-resource', '', 8),
(70, 'resource/create', 'class_key', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 0),
(71, 'resource/create', 'content_type', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 1),
(72, 'resource/create', 'modx-page-settings-right', 'tab', '', 'modx-panel-resource', '', 9),
(73, 'resource/create', 'parent-cmb', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 0),
(74, 'resource/create', 'content_dispo', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 1),
(75, 'resource/create', 'modx-page-settings-box-left', 'tab', '', 'modx-panel-resource', '', 10),
(76, 'resource/create', 'isfolder', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 0),
(77, 'resource/create', 'show_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 1),
(78, 'resource/create', 'hide_children_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 2),
(79, 'resource/create', 'alias_visible', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 3),
(80, 'resource/create', 'uri_override', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 4),
(81, 'resource/create', 'uri', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 5),
(82, 'resource/create', 'modx-page-settings-box-right', 'tab', '', 'modx-panel-resource', '', 11),
(83, 'resource/create', 'richtext', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 0),
(84, 'resource/create', 'cacheable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 1),
(85, 'resource/create', 'searchable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 2),
(86, 'resource/create', 'syncsite', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 3),
(87, 'resource/create', 'modx-panel-resource-tv', 'tab', '', 'modx-panel-resource', 'tv', 12),
(88, 'resource/create', 'modx-resource-access-permissions', 'tab', '', 'modx-panel-resource', '', 13);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_active_users`
--

CREATE TABLE `modx_active_users` (
  `internalKey` int(9) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `lasthit` int(20) NOT NULL DEFAULT '0',
  `id` int(10) DEFAULT NULL,
  `action` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_categories`
--

CREATE TABLE `modx_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(10) UNSIGNED DEFAULT '0',
  `category` varchar(45) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_categories`
--

INSERT INTO `modx_categories` (`id`, `parent`, `category`, `rank`) VALUES
(1, 0, 'MIGX', 0),
(6, 0, 'TinyMCE Rich Text Editor', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_categories_closure`
--

CREATE TABLE `modx_categories_closure` (
  `ancestor` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `descendant` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `depth` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_categories_closure`
--

INSERT INTO `modx_categories_closure` (`ancestor`, `descendant`, `depth`) VALUES
(0, 1, 0),
(0, 6, 0),
(1, 1, 0),
(6, 6, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_content_type`
--

CREATE TABLE `modx_content_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` tinytext,
  `mime_type` tinytext,
  `file_extensions` tinytext,
  `icon` tinytext,
  `headers` mediumtext,
  `binary` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_content_type`
--

INSERT INTO `modx_content_type` (`id`, `name`, `description`, `mime_type`, `file_extensions`, `icon`, `headers`, `binary`) VALUES
(1, 'HTML', 'HTML content', 'text/html', '.html', '', NULL, 0),
(2, 'XML', 'XML content', 'text/xml', '.xml', 'icon-xml', NULL, 0),
(3, 'Text', 'Plain text content', 'text/plain', '.txt', 'icon-txt', NULL, 0),
(4, 'CSS', 'CSS content', 'text/css', '.css', 'icon-css', NULL, 0),
(5, 'JavaScript', 'JavaScript content', 'text/javascript', '.js', 'icon-js', NULL, 0),
(6, 'RSS', 'For RSS feeds', 'application/rss+xml', '.rss', 'icon-rss', NULL, 0),
(7, 'JSON', 'JSON', 'application/json', '.json', 'icon-json', NULL, 0),
(8, 'PDF', 'PDF Files', 'application/pdf', '.pdf', 'icon-pdf', NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_context`
--

CREATE TABLE `modx_context` (
  `key` varchar(100) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `description` tinytext,
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_context`
--

INSERT INTO `modx_context` (`key`, `name`, `description`, `rank`) VALUES
('mgr', 'Manager', 'The default manager or administration context for content management activity.', 0),
('web', 'Website', 'The default front-end context for your web site.', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_context_resource`
--

CREATE TABLE `modx_context_resource` (
  `context_key` varchar(191) NOT NULL,
  `resource` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_context_setting`
--

CREATE TABLE `modx_context_setting` (
  `context_key` varchar(191) NOT NULL,
  `key` varchar(50) NOT NULL,
  `value` mediumtext,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_context_setting`
--

INSERT INTO `modx_context_setting` (`context_key`, `key`, `value`, `xtype`, `namespace`, `area`, `editedon`) VALUES
('mgr', 'allow_tags_in_post', '1', 'combo-boolean', 'core', 'system', NULL),
('mgr', 'modRequest.class', 'MODX\\Revolution\\modManagerRequest', 'textfield', 'core', 'system', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_dashboard`
--

CREATE TABLE `modx_dashboard` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `hide_trees` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `customizable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_dashboard`
--

INSERT INTO `modx_dashboard` (`id`, `name`, `description`, `hide_trees`, `customizable`) VALUES
(1, 'Default', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_dashboard_widget`
--

CREATE TABLE `modx_dashboard_widget` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `type` varchar(100) NOT NULL,
  `content` mediumtext,
  `properties` text,
  `namespace` varchar(191) NOT NULL DEFAULT '',
  `lexicon` varchar(191) NOT NULL DEFAULT 'core:dashboards',
  `size` varchar(255) NOT NULL DEFAULT 'half',
  `permission` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_dashboard_widget`
--

INSERT INTO `modx_dashboard_widget` (`id`, `name`, `description`, `type`, `content`, `properties`, `namespace`, `lexicon`, `size`, `permission`) VALUES
(1, 'w_newsfeed', 'w_newsfeed_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.modx-news.php', NULL, 'core', 'core:dashboards', 'one-third', ''),
(2, 'w_securityfeed', 'w_securityfeed_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.modx-security.php', NULL, 'core', 'core:dashboards', 'one-third', ''),
(3, 'w_whosonline', 'w_whosonline_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.grid-online.php', NULL, 'core', 'core:dashboards', 'one-third', ''),
(4, 'w_recentlyeditedresources', 'w_recentlyeditedresources_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.grid-rer.php', NULL, 'core', 'core:dashboards', 'two-thirds', 'view_document'),
(5, 'w_configcheck', 'w_configcheck_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.configcheck.php', NULL, 'core', 'core:dashboards', 'full', ''),
(6, 'w_buttons', 'w_buttons_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.buttons.php', '{\"create-resource\":{\"link\":\"[[++manager_url]]?a=resource\\/create\",\"icon\":\"file-o\",\"title\":\"[[%action_new_resource]]\",\"description\":\"[[%action_new_resource_desc]]\"},\"view-site\":{\"link\":\"[[++site_url]]\",\"icon\":\"eye\",\"title\":\"[[%action_view_website]]\",\"description\":\"[[%action_view_website_desc]]\",\"target\":\"_blank\"},\"advanced-search\":{\"link\":\"[[++manager_url]]?a=search\",\"icon\":\"search\",\"title\":\"[[%action_advanced_search]]\",\"description\":\"[[%action_advanced_search_desc]]\"},\"manage-users\":{\"link\":\"[[++manager_url]]?a=security\\/user\",\"icon\":\"user\",\"title\":\"[[%action_manage_users]]\",\"description\":\"[[%action_manage_users_desc]]\"}}', 'core', 'core:dashboards', 'full', ''),
(7, 'w_updates', 'w_updates_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.updates.php', NULL, 'core', 'core:dashboards', 'one-third', 'workspaces');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_dashboard_widget_placement`
--

CREATE TABLE `modx_dashboard_widget_placement` (
  `user` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `dashboard` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `widget` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `size` varchar(255) NOT NULL DEFAULT 'half'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_dashboard_widget_placement`
--

INSERT INTO `modx_dashboard_widget_placement` (`user`, `dashboard`, `widget`, `rank`, `size`) VALUES
(0, 1, 1, 2, 'one-third'),
(0, 1, 2, 3, 'one-third'),
(0, 1, 3, 5, 'one-third'),
(0, 1, 4, 6, 'two-thirds'),
(0, 1, 5, 1, 'full'),
(0, 1, 6, 0, 'full'),
(0, 1, 7, 4, 'one-third'),
(1, 1, 1, 2, 'one-third'),
(1, 1, 2, 3, 'one-third'),
(1, 1, 3, 5, 'one-third'),
(1, 1, 4, 6, 'two-thirds'),
(1, 1, 5, 1, 'full'),
(1, 1, 6, 0, 'full'),
(1, 1, 7, 4, 'one-third');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_deprecated_call`
--

CREATE TABLE `modx_deprecated_call` (
  `id` int(10) UNSIGNED NOT NULL,
  `method` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `call_count` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `caller` varchar(191) NOT NULL DEFAULT '',
  `caller_file` varchar(191) NOT NULL DEFAULT '',
  `caller_line` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_deprecated_call`
--

INSERT INTO `modx_deprecated_call` (`id`, `method`, `call_count`, `caller`, `caller_file`, `caller_line`) VALUES
(1, 1, 20, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(2, 2, 20, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(3, 2, 20, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(4, 3, 1, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(5, 4, 24, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(6, 4, 24, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(7, 5, 83, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(8, 5, 83, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(9, 5, 83, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(10, 6, 565, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(11, 6, 565, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(12, 7, 1, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(13, 7, 1, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(14, 8, 535, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(15, 9, 19, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(16, 10, 19, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(17, 10, 19, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(18, 11, 21, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(19, 11, 21, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(20, 11, 21, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(21, 4, 23, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(22, 12, 1, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(23, 13, 1, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(24, 13, 1, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(25, 14, 10, 'xPDO\\Om\\xPDOQuery::__construct', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOQuery.php', 122),
(26, 14, 10, 'xPDO\\xPDO::getTableName', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1289),
(27, 14, 10, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(28, 14, 10, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(29, 15, 30, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(30, 15, 30, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(31, 15, 30, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(32, 15, 30, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(33, 16, 16, 'xPDO\\Om\\xPDOQuery::__construct', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOQuery.php', 122),
(34, 17, 2390, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(35, 17, 2390, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(36, 18, 2382, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(37, 19, 603, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(38, 20, 133, 'xPDO\\xPDO::getService', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1258),
(39, 16, 133, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(40, 16, 133, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(41, 16, 133, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(42, 16, 133, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(43, 18, 115, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(44, 18, 115, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(45, 18, 1418, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(46, 18, 1418, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(47, 21, 9, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(48, 21, 9, 'MODX\\Revolution\\modAccessibleObject::loadCollection', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 164),
(49, 19, 53, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(50, 19, 53, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(51, 18, 15145, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(52, 18, 15145, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(53, 18, 14460, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(54, 17, 14463, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(55, 17, 14463, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(56, 19, 3074, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(57, 19, 3074, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(58, 19, 17094, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(59, 20, 45, 'xPDO\\xPDO::getService', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1258),
(60, 16, 45, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(61, 16, 45, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(62, 16, 45, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(63, 16, 45, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(64, 18, 47, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(65, 18, 47, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(66, 15, 12, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(67, 15, 12, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(68, 15, 12, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(69, 15, 12, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(70, 21, 1, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(71, 21, 1, 'MODX\\Revolution\\modAccessibleObject::loadCollection', 'D:\\Projects\\Hosts\\smart-social-modx.local\\release\\core\\src\\Revolution\\modAccessibleObject.php', 164);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_deprecated_method`
--

CREATE TABLE `modx_deprecated_method` (
  `id` int(10) UNSIGNED NOT NULL,
  `definition` varchar(191) NOT NULL DEFAULT '',
  `since` varchar(191) NOT NULL DEFAULT '',
  `recommendation` varchar(1024) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_deprecated_method`
--

INSERT INTO `modx_deprecated_method` (`id`, `definition`, `since`, `recommendation`) VALUES
(1, 'modx.modNamespace', '3.0', 'Replace references to class modx.modNamespace with MODX\\Revolution\\modNamespace to take advantage of PSR-4 autoloading.'),
(2, 'modNamespace', '3.0', 'Replace references to class modNamespace with MODX\\Revolution\\modNamespace to take advantage of PSR-4 autoloading.'),
(3, 'modx.modPlugin', '3.0', 'Replace references to class modx.modPlugin with MODX\\Revolution\\modPlugin to take advantage of PSR-4 autoloading.'),
(4, 'modPlugin', '3.0', 'Replace references to class modPlugin with MODX\\Revolution\\modPlugin to take advantage of PSR-4 autoloading.'),
(5, 'modPluginEvent', '3.0', 'Replace references to class modPluginEvent with MODX\\Revolution\\modPluginEvent to take advantage of PSR-4 autoloading.'),
(6, 'modSystemSetting', '3.0', 'Replace references to class modSystemSetting with MODX\\Revolution\\modSystemSetting to take advantage of PSR-4 autoloading.'),
(7, 'modEvent', '3.0', 'Replace references to class modEvent with MODX\\Revolution\\modEvent to take advantage of PSR-4 autoloading.'),
(8, 'modx.modSystemSetting', '3.0', 'Replace references to class modx.modSystemSetting with MODX\\Revolution\\modSystemSetting to take advantage of PSR-4 autoloading.'),
(9, 'modx.modCategory', '3.0', 'Replace references to class modx.modCategory with MODX\\Revolution\\modCategory to take advantage of PSR-4 autoloading.'),
(10, 'modCategory', '3.0', 'Replace references to class modCategory with MODX\\Revolution\\modCategory to take advantage of PSR-4 autoloading.'),
(11, 'modSnippet', '3.0', 'Replace references to class modSnippet with MODX\\Revolution\\modSnippet to take advantage of PSR-4 autoloading.'),
(12, 'modx.modMenu', '3.0', 'Replace references to class modx.modMenu with MODX\\Revolution\\modMenu to take advantage of PSR-4 autoloading.'),
(13, 'modMenu', '3.0', 'Replace references to class modMenu with MODX\\Revolution\\modMenu to take advantage of PSR-4 autoloading.'),
(14, 'transport.modTransportPackage', '3.0', 'Replace references to class transport.modTransportPackage with MODX\\Revolution\\Transport\\modTransportPackage to take advantage of PSR-4 autoloading.'),
(15, 'modContentType', '3.0', 'Replace references to class modContentType with MODX\\Revolution\\modContentType to take advantage of PSR-4 autoloading.'),
(16, 'modResource', '3.0', 'Replace references to class modResource with MODX\\Revolution\\modResource to take advantage of PSR-4 autoloading.'),
(17, 'modContextSetting', '3.0', 'Replace references to class modContextSetting with MODX\\Revolution\\modContextSetting to take advantage of PSR-4 autoloading.'),
(18, 'modTemplateVar', '3.0', 'Replace references to class modTemplateVar with MODX\\Revolution\\modTemplateVar to take advantage of PSR-4 autoloading.'),
(19, 'modChunk', '3.0', 'Replace references to class modChunk with MODX\\Revolution\\modChunk to take advantage of PSR-4 autoloading.'),
(20, 'smarty.modSmarty', '3.0', 'Replace references to class smarty.modSmarty with MODX\\Revolution\\Smarty\\modSmarty to take advantage of PSR-4 autoloading.'),
(21, 'modContext', '3.0', 'Replace references to class modContext with MODX\\Revolution\\modContext to take advantage of PSR-4 autoloading.');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_documentgroup_names`
--

CREATE TABLE `modx_documentgroup_names` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `private_memgroup` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `private_webgroup` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_document_groups`
--

CREATE TABLE `modx_document_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `document_group` int(10) NOT NULL DEFAULT '0',
  `document` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_element_property_sets`
--

CREATE TABLE `modx_element_property_sets` (
  `element` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `element_class` varchar(100) NOT NULL DEFAULT '',
  `property_set` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_extension_packages`
--

CREATE TABLE `modx_extension_packages` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `name` varchar(100) NOT NULL DEFAULT 'core',
  `path` text,
  `table_prefix` varchar(255) NOT NULL DEFAULT '',
  `service_class` varchar(255) NOT NULL DEFAULT '',
  `service_name` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_fc_profiles`
--

CREATE TABLE `modx_fc_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_fc_profiles_usergroups`
--

CREATE TABLE `modx_fc_profiles_usergroups` (
  `usergroup` int(11) NOT NULL DEFAULT '0',
  `profile` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_fc_sets`
--

CREATE TABLE `modx_fc_sets` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile` int(11) NOT NULL DEFAULT '0',
  `action` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `template` int(11) NOT NULL DEFAULT '0',
  `constraint` varchar(255) NOT NULL DEFAULT '',
  `constraint_field` varchar(100) NOT NULL DEFAULT '',
  `constraint_class` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_lexicon_entries`
--

CREATE TABLE `modx_lexicon_entries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `topic` varchar(191) NOT NULL DEFAULT 'default',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `language` varchar(20) NOT NULL DEFAULT 'en',
  `createdon` datetime DEFAULT NULL,
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_lexicon_entries`
--

INSERT INTO `modx_lexicon_entries` (`id`, `name`, `value`, `topic`, `namespace`, `language`, `createdon`, `editedon`) VALUES
(1, 'setting_address', 'Адрес', 'default', 'core', 'ru', '2025-07-17 15:54:07', NULL),
(2, 'setting_contact', 'Контактное лицо', 'default', 'core', 'ru', '2025-07-17 15:54:50', NULL),
(3, 'setting_phone-text', 'Телефон (текст)', 'default', 'core', 'ru', '2025-07-17 15:55:49', NULL),
(4, 'setting_phone-text', 'Телефон (текст)', 'setting', 'core', 'ru', '2025-07-17 15:56:23', NULL),
(5, 'setting_phone-link', 'Телефон (ссылка)', 'default', 'core', 'ru', '2025-07-17 15:57:44', NULL),
(6, 'setting_phone-link_desc', 'Телефон в формате +79991112233 (без пробелов и запятых)', 'default', 'core', 'ru', '2025-07-17 15:57:44', NULL),
(7, 'setting_telegram-name', 'Аккаунт в Телеграм (имя)', 'default', 'core', 'ru', '2025-07-17 15:58:36', NULL),
(8, 'setting_telegram-link', 'Аккаунт в телеграм (ссылка)', 'default', 'core', 'ru', '2025-07-17 15:59:21', NULL),
(9, 'setting_email', 'E-mail', 'default', 'core', 'ru', '2025-07-17 15:59:59', NULL),
(10, 'setting_address', 'Адрес', 'setting', 'core', 'ru', '2025-07-18 09:13:10', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_manager_log`
--

CREATE TABLE `modx_manager_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `occurred` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(100) NOT NULL DEFAULT '',
  `classKey` varchar(100) NOT NULL DEFAULT '',
  `item` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_manager_log`
--

INSERT INTO `modx_manager_log` (`id`, `user`, `occurred`, `action`, `classKey`, `item`) VALUES
(1, 1, '2025-07-17 13:30:13', 'login', 'MODX\\Revolution\\modContext', 'mgr'),
(2, 1, '2025-07-17 13:33:03', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(3, 1, '2025-07-17 13:37:02', 'provider_create', 'MODX\\Revolution\\Transport\\modTransportProvider', '2'),
(4, 1, '2025-07-17 13:44:40', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.menubar'),
(5, 1, '2025-07-17 13:48:18', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'which_editor'),
(6, 1, '2025-07-17 13:51:00', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.browser_spellcheck'),
(7, 1, '2025-07-17 13:51:03', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.content_css'),
(8, 1, '2025-07-17 13:51:09', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.enable_link_list'),
(9, 1, '2025-07-17 13:51:12', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.external_config'),
(10, 1, '2025-07-17 13:51:15', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.image_advtab'),
(11, 1, '2025-07-17 13:51:19', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.image_class_list'),
(12, 1, '2025-07-17 13:51:22', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.link_class_list'),
(13, 1, '2025-07-17 13:51:27', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.links_across_contexts'),
(14, 1, '2025-07-17 13:51:30', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.max_height'),
(15, 1, '2025-07-17 13:51:34', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.menubar'),
(16, 1, '2025-07-17 13:51:38', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.object_resizing'),
(17, 1, '2025-07-17 13:51:42', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.paste_as_text'),
(18, 1, '2025-07-17 13:51:46', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.plugins'),
(19, 1, '2025-07-17 13:51:51', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.relative_urls'),
(20, 1, '2025-07-17 13:51:57', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.remove_script_host'),
(21, 1, '2025-07-17 13:52:00', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.settings'),
(22, 1, '2025-07-17 13:52:04', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.skin'),
(23, 1, '2025-07-17 13:52:07', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.statusbar'),
(24, 1, '2025-07-17 13:52:11', 'setting_delete', 'MODX\\Revolution\\modSystemSetting', 'tinymcerte.valid_elements'),
(25, 1, '2025-07-17 13:54:10', 'package_uninstall', 'MODX\\Revolution\\Transport\\modTransportPackage', 'unknown'),
(26, 1, '2025-07-17 13:54:38', 'package_uninstall', 'MODX\\Revolution\\Transport\\modTransportPackage', 'unknown'),
(27, 1, '2025-07-17 13:57:44', 'chunk_create', 'MODX\\Revolution\\modChunk', '1'),
(28, 1, '2025-07-17 13:58:35', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(29, 1, '2025-07-17 13:58:35', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(30, 1, '2025-07-17 14:54:09', 'tv_create', 'MODX\\Revolution\\modTemplateVar', '1'),
(31, 1, '2025-07-17 14:54:31', 'tv_update', 'MODX\\Revolution\\modTemplateVar', '1'),
(32, 1, '2025-07-17 14:54:31', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplateVar 1 Default'),
(33, 1, '2025-07-17 14:58:22', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(34, 1, '2025-07-17 15:00:09', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(35, 1, '2025-07-17 15:05:54', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(36, 1, '2025-07-17 15:12:24', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(37, 1, '2025-07-17 15:12:53', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(38, 1, '2025-07-17 15:12:53', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(39, 1, '2025-07-17 15:16:10', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(40, 1, '2025-07-17 15:16:46', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(41, 1, '2025-07-17 15:16:46', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(42, 1, '2025-07-17 15:18:27', 'chunk_create', 'MODX\\Revolution\\modChunk', '2'),
(43, 1, '2025-07-17 15:19:06', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'site_name'),
(44, 1, '2025-07-17 15:20:17', 'clear_cache', '', 'mgr'),
(45, 1, '2025-07-17 15:20:23', 'clear_cache', '', 'mgr'),
(46, 1, '2025-07-17 15:20:45', 'chunk_update', 'MODX\\Revolution\\modChunk', '2'),
(47, 1, '2025-07-17 15:20:46', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 2 Default'),
(48, 1, '2025-07-17 15:22:57', 'chunk_update', 'MODX\\Revolution\\modChunk', '2'),
(49, 1, '2025-07-17 15:22:57', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 2 Default'),
(50, 1, '2025-07-17 15:23:22', 'chunk_update', 'MODX\\Revolution\\modChunk', '2'),
(51, 1, '2025-07-17 15:23:22', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 2 Default'),
(52, 1, '2025-07-17 15:24:25', 'chunk_create', 'MODX\\Revolution\\modChunk', '3'),
(53, 1, '2025-07-17 15:24:39', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(54, 1, '2025-07-17 15:24:39', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(55, 1, '2025-07-17 15:24:53', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(56, 1, '2025-07-17 15:24:54', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(57, 1, '2025-07-17 15:25:29', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(58, 1, '2025-07-17 15:25:29', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(59, 1, '2025-07-17 15:27:57', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(60, 1, '2025-07-17 15:27:57', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(61, 1, '2025-07-17 15:28:19', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(62, 1, '2025-07-17 15:28:19', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(63, 1, '2025-07-17 15:28:40', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(64, 1, '2025-07-17 15:28:40', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(65, 1, '2025-07-17 15:29:25', 'chunk_create', 'MODX\\Revolution\\modChunk', '4'),
(66, 1, '2025-07-17 15:29:52', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(67, 1, '2025-07-17 15:29:52', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(68, 1, '2025-07-17 15:30:03', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(69, 1, '2025-07-17 15:30:03', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(70, 1, '2025-07-17 15:31:07', 'chunk_update', 'MODX\\Revolution\\modChunk', '2'),
(71, 1, '2025-07-17 15:31:07', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 2 Default'),
(72, 1, '2025-07-17 15:31:42', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(73, 1, '2025-07-17 15:31:42', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(74, 1, '2025-07-17 15:31:55', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(75, 1, '2025-07-17 15:31:55', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(76, 1, '2025-07-17 15:32:33', 'chunk_update', 'MODX\\Revolution\\modChunk', '4'),
(77, 1, '2025-07-17 15:32:33', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 4 Default'),
(78, 1, '2025-07-17 15:32:42', 'chunk_update', 'MODX\\Revolution\\modChunk', '4'),
(79, 1, '2025-07-17 15:32:42', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 4 Default'),
(80, 1, '2025-07-17 15:33:14', 'chunk_update', 'MODX\\Revolution\\modChunk', '4'),
(81, 1, '2025-07-17 15:33:14', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 4 Default'),
(82, 1, '2025-07-17 15:44:55', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(83, 1, '2025-07-17 15:45:22', 'chunk_update', 'MODX\\Revolution\\modChunk', '2'),
(84, 1, '2025-07-17 15:45:22', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 2 Default'),
(85, 1, '2025-07-17 15:45:49', 'chunk_update', 'MODX\\Revolution\\modChunk', '4'),
(86, 1, '2025-07-17 15:45:49', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 4 Default'),
(87, 1, '2025-07-17 15:46:05', 'chunk_update', 'MODX\\Revolution\\modChunk', '1'),
(88, 1, '2025-07-17 15:46:06', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 1 Default'),
(89, 1, '2025-07-17 15:47:36', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(90, 1, '2025-07-17 15:47:36', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(91, 1, '2025-07-17 15:48:30', 'chunk_create', 'MODX\\Revolution\\modChunk', '5'),
(92, 1, '2025-07-17 15:48:47', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(93, 1, '2025-07-17 15:48:47', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(94, 1, '2025-07-17 15:52:13', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(95, 1, '2025-07-17 15:52:14', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(96, 1, '2025-07-17 15:53:01', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(97, 1, '2025-07-17 15:53:01', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(98, 1, '2025-07-17 15:54:07', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'address'),
(99, 1, '2025-07-17 15:54:50', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'contact'),
(100, 1, '2025-07-17 15:55:49', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'phone-text'),
(101, 1, '2025-07-17 15:56:23', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'phone-text'),
(102, 1, '2025-07-17 15:57:44', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'phone-link'),
(103, 1, '2025-07-17 15:58:36', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'telegram-name'),
(104, 1, '2025-07-17 15:59:21', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'telegram-link'),
(105, 1, '2025-07-17 16:00:00', 'setting_create', 'MODX\\Revolution\\modSystemSetting', 'email'),
(106, 1, '2025-07-17 16:00:32', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(107, 1, '2025-07-17 16:00:32', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(108, 1, '2025-07-17 16:00:57', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(109, 1, '2025-07-17 16:00:57', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(110, 1, '2025-07-17 16:01:14', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(111, 1, '2025-07-17 16:01:14', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(112, 1, '2025-07-17 16:01:57', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(113, 1, '2025-07-17 16:01:57', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(114, 1, '2025-07-17 16:02:01', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(115, 1, '2025-07-17 16:02:01', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(116, 1, '2025-07-17 16:02:05', 'chunk_update', 'MODX\\Revolution\\modChunk', '5'),
(117, 1, '2025-07-17 16:02:05', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 5 Default'),
(118, 1, '2025-07-17 16:03:05', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(119, 1, '2025-07-17 16:03:05', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(120, 1, '2025-07-17 16:03:43', 'chunk_create', 'MODX\\Revolution\\modChunk', '6'),
(121, 1, '2025-07-17 16:34:44', 'chunk_create', 'MODX\\Revolution\\modChunk', '7'),
(122, 1, '2025-07-17 16:35:24', 'chunk_create', 'MODX\\Revolution\\modChunk', '8'),
(123, 1, '2025-07-17 16:35:35', 'chunk_update', 'MODX\\Revolution\\modChunk', '8'),
(124, 1, '2025-07-17 16:35:35', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 8 Default'),
(125, 1, '2025-07-17 16:36:17', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(126, 1, '2025-07-17 16:36:17', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(127, 1, '2025-07-17 16:36:28', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(128, 1, '2025-07-17 16:36:28', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(129, 1, '2025-07-17 16:36:38', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(130, 1, '2025-07-17 16:36:38', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(131, 1, '2025-07-17 16:37:05', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(132, 1, '2025-07-17 16:37:05', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(133, 1, '2025-07-17 16:37:41', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(134, 1, '2025-07-17 16:37:41', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(135, 1, '2025-07-17 16:39:08', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(136, 1, '2025-07-17 16:39:08', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(137, 1, '2025-07-17 16:39:24', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(138, 1, '2025-07-17 16:39:25', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(139, 1, '2025-07-17 16:39:55', 'chunk_update', 'MODX\\Revolution\\modChunk', '7'),
(140, 1, '2025-07-17 16:39:55', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 7 Default'),
(141, 1, '2025-07-17 16:43:34', 'chunk_create', 'MODX\\Revolution\\modChunk', '9'),
(142, 1, '2025-07-17 16:46:14', 'chunk_update', 'MODX\\Revolution\\modChunk', '9'),
(143, 1, '2025-07-17 16:46:14', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 9 Default'),
(144, 1, '2025-07-17 16:46:27', 'chunk_update', 'MODX\\Revolution\\modChunk', '9'),
(145, 1, '2025-07-17 16:46:27', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 9 Default'),
(146, 1, '2025-07-17 16:46:58', 'chunk_update', 'MODX\\Revolution\\modChunk', '9'),
(147, 1, '2025-07-17 16:46:58', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 9 Default'),
(148, 1, '2025-07-17 16:47:13', 'chunk_create', 'MODX\\Revolution\\modChunk', '10'),
(149, 1, '2025-07-17 16:50:42', 'chunk_create', 'MODX\\Revolution\\modChunk', '11'),
(150, 1, '2025-07-17 16:51:35', 'chunk_update', 'MODX\\Revolution\\modChunk', '9'),
(151, 1, '2025-07-17 16:51:36', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 9 Default'),
(152, 1, '2025-07-17 16:52:29', 'chunk_create', 'MODX\\Revolution\\modChunk', '12'),
(153, 1, '2025-07-17 16:53:17', 'chunk_update', 'MODX\\Revolution\\modChunk', '9'),
(154, 1, '2025-07-17 16:53:17', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 9 Default'),
(155, 1, '2025-07-17 16:53:46', 'chunk_update', 'MODX\\Revolution\\modChunk', '12'),
(156, 1, '2025-07-17 16:53:46', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 12 Default'),
(157, 1, '2025-07-17 16:54:58', 'chunk_create', 'MODX\\Revolution\\modChunk', '13'),
(158, 1, '2025-07-17 16:55:33', 'chunk_update', 'MODX\\Revolution\\modChunk', '13'),
(159, 1, '2025-07-17 16:55:33', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 13 Default'),
(160, 1, '2025-07-17 16:56:16', 'chunk_create', 'MODX\\Revolution\\modChunk', '14'),
(161, 1, '2025-07-17 16:57:01', 'chunk_update', 'MODX\\Revolution\\modChunk', '13'),
(162, 1, '2025-07-17 16:57:01', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 13 Default'),
(163, 1, '2025-07-17 16:58:52', 'chunk_create', 'MODX\\Revolution\\modChunk', '15'),
(164, 1, '2025-07-17 16:59:32', 'chunk_create', 'MODX\\Revolution\\modChunk', '16'),
(165, 1, '2025-07-17 17:00:24', 'chunk_update', 'MODX\\Revolution\\modChunk', '15'),
(166, 1, '2025-07-17 17:00:25', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 15 Default'),
(167, 1, '2025-07-17 17:02:15', 'chunk_create', 'MODX\\Revolution\\modChunk', '17'),
(168, 1, '2025-07-17 17:02:50', 'chunk_create', 'MODX\\Revolution\\modChunk', '18'),
(169, 1, '2025-07-17 17:06:13', 'chunk_update', 'MODX\\Revolution\\modChunk', '14'),
(170, 1, '2025-07-17 17:06:13', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 14 Default'),
(171, 1, '2025-07-17 17:08:52', 'chunk_update', 'MODX\\Revolution\\modChunk', '14'),
(172, 1, '2025-07-17 17:08:52', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 14 Default'),
(173, 1, '2025-07-17 17:09:12', 'chunk_update', 'MODX\\Revolution\\modChunk', '14'),
(174, 1, '2025-07-17 17:09:12', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 14 Default'),
(175, 1, '2025-07-17 17:09:24', 'chunk_update', 'MODX\\Revolution\\modChunk', '18'),
(176, 1, '2025-07-17 17:09:24', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 18 Default'),
(177, 1, '2025-07-17 17:10:40', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(178, 1, '2025-07-17 17:11:56', 'chunk_update', 'MODX\\Revolution\\modChunk', '18'),
(179, 1, '2025-07-17 17:11:56', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 18 Default'),
(180, 1, '2025-07-17 17:13:28', 'chunk_update', 'MODX\\Revolution\\modChunk', '18'),
(181, 1, '2025-07-17 17:13:28', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 18 Default'),
(182, 1, '2025-07-17 17:32:31', 'chunk_update', 'MODX\\Revolution\\modChunk', '18'),
(183, 1, '2025-07-17 17:32:31', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 18 Default'),
(184, 1, '2025-07-17 17:36:39', 'chunk_update', 'MODX\\Revolution\\modChunk', '18'),
(185, 1, '2025-07-17 17:36:39', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 18 Default'),
(186, 1, '2025-07-17 17:37:10', 'chunk_update', 'MODX\\Revolution\\modChunk', '18'),
(187, 1, '2025-07-17 17:37:10', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 18 Default'),
(188, 1, '2025-07-17 17:40:11', 'chunk_create', 'MODX\\Revolution\\modChunk', '19'),
(189, 1, '2025-07-17 17:41:53', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(190, 1, '2025-07-17 17:44:38', 'chunk_update', 'MODX\\Revolution\\modChunk', '19'),
(191, 1, '2025-07-17 17:44:38', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 19 Default'),
(192, 1, '2025-07-17 17:45:27', 'chunk_create', 'MODX\\Revolution\\modChunk', '20'),
(193, 1, '2025-07-17 17:50:38', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(194, 1, '2025-07-17 17:50:53', 'chunk_update', 'MODX\\Revolution\\modChunk', '20'),
(195, 1, '2025-07-17 17:50:53', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 20 Default'),
(196, 1, '2025-07-17 17:51:48', 'chunk_create', 'MODX\\Revolution\\modChunk', '21'),
(197, 1, '2025-07-17 17:52:33', 'chunk_update', 'MODX\\Revolution\\modChunk', '21'),
(198, 1, '2025-07-17 17:52:33', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 21 Default'),
(199, 1, '2025-07-17 17:55:26', 'chunk_update', 'MODX\\Revolution\\modChunk', '20'),
(200, 1, '2025-07-17 17:55:26', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 20 Default'),
(201, 1, '2025-07-17 17:56:32', 'chunk_create', 'MODX\\Revolution\\modChunk', '22'),
(202, 1, '2025-07-17 17:58:38', 'chunk_update', 'MODX\\Revolution\\modChunk', '20'),
(203, 1, '2025-07-17 17:58:38', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 20 Default'),
(204, 1, '2025-07-17 17:59:38', 'chunk_update', 'MODX\\Revolution\\modChunk', '20'),
(205, 1, '2025-07-17 17:59:38', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 20 Default'),
(206, 1, '2025-07-17 18:01:00', 'chunk_update', 'MODX\\Revolution\\modChunk', '22'),
(207, 1, '2025-07-17 18:01:00', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 22 Default'),
(208, 1, '2025-07-17 18:01:08', 'chunk_update', 'MODX\\Revolution\\modChunk', '22'),
(209, 1, '2025-07-17 18:01:09', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 22 Default'),
(210, 1, '2025-07-17 18:01:22', 'chunk_update', 'MODX\\Revolution\\modChunk', '22'),
(211, 1, '2025-07-17 18:01:22', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 22 Default'),
(212, 1, '2025-07-17 18:01:35', 'chunk_update', 'MODX\\Revolution\\modChunk', '22'),
(213, 1, '2025-07-17 18:01:35', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 22 Default'),
(214, 1, '2025-07-17 18:02:33', 'chunk_update', 'MODX\\Revolution\\modChunk', '20'),
(215, 1, '2025-07-17 18:02:33', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 20 Default'),
(216, 1, '2025-07-17 18:03:06', 'chunk_update', 'MODX\\Revolution\\modChunk', '22'),
(217, 1, '2025-07-17 18:03:06', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 22 Default'),
(218, 1, '2025-07-17 18:03:20', 'chunk_update', 'MODX\\Revolution\\modChunk', '22'),
(219, 1, '2025-07-17 18:03:20', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 22 Default'),
(220, 1, '2025-07-17 18:05:44', 'chunk_create', 'MODX\\Revolution\\modChunk', '23'),
(221, 1, '2025-07-17 18:06:05', 'chunk_update', 'MODX\\Revolution\\modChunk', '23'),
(222, 1, '2025-07-17 18:06:05', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 23 Default'),
(223, 1, '2025-07-17 18:07:35', 'chunk_update', 'MODX\\Revolution\\modChunk', '20'),
(224, 1, '2025-07-17 18:07:35', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 20 Default'),
(225, 1, '2025-07-17 18:19:00', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(226, 1, '2025-07-17 18:19:33', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(227, 1, '2025-07-17 18:20:08', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(228, 1, '2025-07-17 18:21:08', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(229, 1, '2025-07-17 18:21:57', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(230, 1, '2025-07-17 18:26:35', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(231, 1, '2025-07-17 18:27:05', 'chunk_update', 'MODX\\Revolution\\modChunk', '15'),
(232, 1, '2025-07-17 18:27:05', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 15 Default'),
(233, 1, '2025-07-17 18:27:36', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(234, 1, '2025-07-17 18:27:49', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(235, 1, '2025-07-17 18:28:25', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(236, 1, '2025-07-17 18:28:43', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(237, 1, '2025-07-18 08:57:01', 'login', 'MODX\\Revolution\\modContext', 'mgr'),
(238, 1, '2025-07-18 08:59:34', 'user_create', 'MODX\\Revolution\\modUser', '2'),
(239, 1, '2025-07-18 09:01:09', 'user_create', 'MODX\\Revolution\\modUser', '3'),
(240, 1, '2025-07-18 09:07:24', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(241, 1, '2025-07-18 09:10:30', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(242, 1, '2025-07-18 09:12:18', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(243, 1, '2025-07-18 09:12:50', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(244, 1, '2025-07-18 09:12:51', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(245, 1, '2025-07-18 09:13:11', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(246, 1, '2025-07-18 09:13:20', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(247, 1, '2025-07-18 09:13:20', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(248, 1, '2025-07-18 09:13:28', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(249, 1, '2025-07-18 09:13:45', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(250, 1, '2025-07-18 09:13:46', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(251, 1, '2025-07-18 09:13:58', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(252, 1, '2025-07-18 09:13:58', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(253, 1, '2025-07-18 09:14:28', 'clear_cache', '', 'mgr'),
(254, 1, '2025-07-18 09:14:33', 'clear_cache', '', 'mgr'),
(255, 1, '2025-07-18 09:14:42', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(256, 1, '2025-07-18 09:14:49', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(257, 1, '2025-07-18 09:14:57', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(258, 1, '2025-07-18 09:15:05', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(259, 1, '2025-07-18 09:15:06', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(260, 1, '2025-07-18 09:15:15', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(261, 1, '2025-07-18 09:15:15', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(262, 1, '2025-07-18 09:15:22', 'clear_cache', '', 'mgr'),
(263, 1, '2025-07-18 09:15:40', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(264, 1, '2025-07-18 09:15:40', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(265, 1, '2025-07-18 09:15:46', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(266, 1, '2025-07-18 09:15:54', 'clear_cache', '', 'mgr'),
(267, 1, '2025-07-18 09:16:15', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(268, 1, '2025-07-18 09:16:15', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(269, 1, '2025-07-18 09:16:26', 'clear_cache', '', 'mgr'),
(270, 1, '2025-07-18 09:16:59', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(271, 1, '2025-07-18 09:16:59', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(272, 1, '2025-07-18 09:17:14', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(273, 1, '2025-07-18 09:17:14', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(274, 1, '2025-07-18 09:17:20', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(275, 1, '2025-07-18 09:17:20', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(276, 1, '2025-07-18 09:17:29', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(277, 1, '2025-07-18 09:17:34', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(278, 1, '2025-07-18 09:17:42', 'clear_cache', '', 'mgr'),
(279, 1, '2025-07-18 09:18:01', 'resource_update', 'MODX\\Revolution\\modResource', '1'),
(280, 1, '2025-07-18 09:18:41', 'chunk_update', 'MODX\\Revolution\\modChunk', '3'),
(281, 1, '2025-07-18 09:18:41', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 3 Default'),
(282, 1, '2025-07-18 09:18:49', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(283, 1, '2025-07-18 09:19:01', 'clear_cache', '', 'mgr'),
(284, 1, '2025-07-18 09:21:02', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(285, 1, '2025-07-18 09:21:14', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(286, 1, '2025-07-18 09:21:29', 'clear_cache', '', 'mgr'),
(287, 1, '2025-07-18 09:22:21', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(288, 1, '2025-07-18 09:22:59', 'clear_cache', '', 'mgr'),
(289, 1, '2025-07-18 09:25:39', 'clear_cache', '', 'mgr'),
(290, 1, '2025-07-18 09:25:53', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(291, 1, '2025-07-18 09:25:59', 'clear_cache', '', 'mgr'),
(292, 1, '2025-07-18 09:27:03', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(293, 1, '2025-07-18 09:27:40', 'clear_cache', '', 'mgr'),
(294, 1, '2025-07-18 09:27:50', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(295, 1, '2025-07-18 09:28:00', 'clear_cache', '', 'mgr'),
(296, 1, '2025-07-18 09:28:28', 'clear_cache', '', 'mgr'),
(297, 1, '2025-07-18 09:30:06', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(298, 1, '2025-07-18 09:30:16', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address'),
(299, 1, '2025-07-18 09:30:21', 'setting_update', 'MODX\\Revolution\\modSystemSetting', 'address');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_media_sources`
--

CREATE TABLE `modx_media_sources` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `class_key` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\Sources\\modFileMediaSource',
  `properties` mediumtext,
  `is_stream` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_media_sources`
--

INSERT INTO `modx_media_sources` (`id`, `name`, `description`, `class_key`, `properties`, `is_stream`) VALUES
(1, 'Filesystem', '', 'MODX\\Revolution\\Sources\\modFileMediaSource', 'a:0:{}', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_media_sources_contexts`
--

CREATE TABLE `modx_media_sources_contexts` (
  `source` int(11) NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_media_sources_elements`
--

CREATE TABLE `modx_media_sources_elements` (
  `source` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `object_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modTemplateVar',
  `object` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_media_sources_elements`
--

INSERT INTO `modx_media_sources_elements` (`source`, `object_class`, `object`, `context_key`) VALUES
(1, 'MODX\\Revolution\\modTemplateVar', 1, 'web');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_membergroup_names`
--

CREATE TABLE `modx_membergroup_names` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `dashboard` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_membergroup_names`
--

INSERT INTO `modx_membergroup_names` (`id`, `name`, `description`, `parent`, `rank`, `dashboard`) VALUES
(1, 'Administrator', NULL, 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_member_groups`
--

CREATE TABLE `modx_member_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `member` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `role` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_member_groups`
--

INSERT INTO `modx_member_groups` (`id`, `user_group`, `member`, `role`, `rank`) VALUES
(1, 1, 1, 2, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_menus`
--

CREATE TABLE `modx_menus` (
  `text` varchar(191) NOT NULL DEFAULT '',
  `parent` varchar(191) NOT NULL DEFAULT '',
  `action` varchar(191) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `menuindex` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `handler` text NOT NULL,
  `permissions` text NOT NULL,
  `namespace` varchar(100) NOT NULL DEFAULT 'core'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_menus`
--

INSERT INTO `modx_menus` (`text`, `parent`, `action`, `description`, `icon`, `menuindex`, `params`, `handler`, `permissions`, `namespace`) VALUES
('about', 'usernav', 'help', 'about_desc', '<i class=\"icon-question-circle icon\"></i>', 3, '', '', 'help', 'core'),
('access', 'usernav', '', '', '<i class=\"icon-user-lock icon\"></i>', 1, '', '', 'access_permissions', 'core'),
('acls', 'access', 'security/permission', 'acls_desc', '', 2, '', '', 'access_permissions', 'core'),
('admin', 'usernav', '', '', '<i class=\"icon-gear icon\"></i>', 2, '', '', 'settings', 'core'),
('components', 'topnav', '', '', '<i class=\"icon-cube icon\"></i>', 2, '', '', 'components', 'core'),
('content_types', 'site', 'system/contenttype', 'content_types_desc', '', 4, '', '', 'content_types', 'core'),
('contexts', 'admin', 'context', 'contexts_desc', '', 4, '', '', 'view_context', 'core'),
('dashboards', 'admin', 'system/dashboards', 'dashboards_desc', '', 5, '', '', 'dashboards', 'core'),
('edit_menu', 'admin', 'system/action', 'edit_menu_desc', '', 3, '', '', 'actions', 'core'),
('eventlog_viewer', 'reports', 'system/event', 'eventlog_viewer_desc', '', 1, '', '', 'view_eventlog', 'core'),
('file_browser', 'media', 'media/browser', 'file_browser_desc', '', 0, '', '', 'file_manager', 'core'),
('flush_access', 'access', '', 'flush_access_desc', '', 3, '', 'MODx.msg.confirm({\n                            title: _(\'flush_access\')\n                            ,text: _(\'flush_access_confirm\')\n                            ,url: MODx.config.connector_url\n                            ,params: {\n                                action: \'security/access/flush\'\n                            }\n                            ,listeners: {\n                                \'success\': {fn:function() { location.href = \'./\'; },scope:this},\n                                \'failure\': {fn:function(response) { Ext.MessageBox.alert(\'failure\', response.responseText); },scope:this},\n                            }\n                        });', 'access_permissions', 'core'),
('flush_sessions', 'access', '', 'flush_sessions_desc', '', 4, '', 'MODx.msg.confirm({\n                            title: _(\'flush_sessions\')\n                            ,text: _(\'flush_sessions_confirm\')\n                            ,url: MODx.config.connector_url\n                            ,params: {\n                                action: \'security/flush\'\n                            }\n                            ,listeners: {\n                                \'success\': {fn:function() { location.href = \'./\'; },scope:this}\n                            }\n                        });', 'flush_sessions', 'core'),
('form_customization', 'admin', 'security/forms', 'form_customization_desc', '', 1, '', '', 'customize_forms', 'core'),
('installer', 'components', 'workspaces', 'installer_desc', '', 0, '', '', 'packages', 'core'),
('language', 'admin', '', 'language_desc', '', 8, '', '', 'language', 'core'),
('lexicon_management', 'admin', 'workspaces/lexicon', 'lexicon_management_desc', '', 7, '', '', 'lexicons', 'core'),
('logout', 'user', 'security/logout', 'logout_desc', '', 2, '', 'MODx.logout(); return false;', 'logout', 'core'),
('media', 'topnav', '', '', '<i class=\"icon-file-image-o icon\"></i>', 1, '', '', 'file_manager', 'core'),
('messages', 'user', 'security/message', 'messages_desc', '', 1, '', '', 'messages', 'core'),
('MIGX', 'components', 'index', '', '', 1, '&configs=migxconfigs||packagemanager', '', '', 'migx'),
('namespaces', 'admin', 'workspaces/namespace', 'namespaces_desc', '', 6, '', '', 'namespaces', 'core'),
('new_resource', 'site', 'resource/create', 'new_resource_desc', '', 0, '', '', 'new_document', 'core'),
('propertysets', 'admin', 'element/propertyset', 'propertysets_desc', '', 2, '', '', 'property_sets', 'core'),
('refreshuris', 'refresh_site', '', 'refreshuris_desc', '', 0, '', 'MODx.refreshURIs(); return false;', 'empty_cache', 'core'),
('refresh_site', 'site', '', 'refresh_site_desc', '', 1, '', 'MODx.clearCache(); return false;', 'empty_cache', 'core'),
('remove_locks', 'site', '', 'remove_locks_desc', '', 2, '', 'MODx.removeLocks();return false;', 'remove_locks', 'core'),
('reports', 'admin', '', 'reports_desc', '', 9, '', '', 'menu_reports', 'core'),
('resource_groups', 'access', 'security/resourcegroup', 'resource_groups_desc', '', 1, '', '', 'access_permissions', 'core'),
('site', 'topnav', '', '', '<i class=\"icon-file-text-o icon\"></i>', 0, '', '', 'menu_site', 'core'),
('site_schedule', 'site', 'resource/site_schedule', 'site_schedule_desc', '', 3, '', '', 'view_document', 'core'),
('sources', 'media', 'source', 'sources_desc', '', 1, '', '', 'sources', 'core'),
('system_settings', 'admin', 'system/settings', 'system_settings_desc', '', 0, '', '', 'settings', 'core'),
('topnav', '', '', 'topnav_desc', '', 0, '', '', '', 'core'),
('trash', 'site', 'resource/trash', 'trash_desc', '', 5, '', '', 'menu_trash', 'core'),
('user', 'usernav', '', '', '<span id=\"user-avatar\" title=\"{$username}\">{$userImage}</span> <span id=\"user-username\">{$username}</span>', 0, '', '', 'menu_user', 'core'),
('usernav', '', '', 'usernav_desc', '', 1, '', '', '', 'core'),
('users', 'access', 'security/user', 'user_management_desc', '', 0, '', '', 'view_user', 'core'),
('view_logging', 'reports', 'system/logs', 'view_logging_desc', '', 0, '', '', 'mgr_log_view', 'core'),
('view_sysinfo', 'reports', 'system/info', 'view_sysinfo_desc', '', 2, '', '', 'view_sysinfo', 'core'),
('{$username}', 'user', 'security/profile', 'profile_desc', '', 0, '', '', 'change_profile', 'core');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_migx_configs`
--

CREATE TABLE `modx_migx_configs` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `formtabs` text NOT NULL,
  `contextmenus` text NOT NULL,
  `actionbuttons` text NOT NULL,
  `columnbuttons` text NOT NULL,
  `filters` text NOT NULL,
  `extended` text NOT NULL,
  `permissions` text NOT NULL,
  `fieldpermissions` text NOT NULL,
  `columns` text NOT NULL,
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` datetime DEFAULT NULL,
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` datetime DEFAULT NULL,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `deletedon` datetime DEFAULT NULL,
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `publishedon` datetime DEFAULT NULL,
  `publishedby` int(10) NOT NULL DEFAULT '0',
  `category` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_migx_configs`
--

INSERT INTO `modx_migx_configs` (`id`, `name`, `formtabs`, `contextmenus`, `actionbuttons`, `columnbuttons`, `filters`, `extended`, `permissions`, `fieldpermissions`, `columns`, `createdby`, `createdon`, `editedby`, `editedon`, `deleted`, `deletedon`, `deletedby`, `published`, `publishedon`, `publishedby`, `category`) VALUES
(1, 'Points', '[{\"MIGX_id\":1,\"caption\":\"\\u041f\\u043e\\u0438\\u043d\\u0442\\u044b\",\"print_before_tabs\":\"0\",\"fields\":[{\"MIGX_id\":1,\"field\":\"header\",\"caption\":\"\\u0417\\u0430\\u0433\\u043e\\u043b\\u043e\\u0432\\u043e\\u043a\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":1},{\"MIGX_id\":16,\"field\":\"anchor\",\"caption\":\"\\u042f\\u043a\\u043e\\u0440\\u044c \\u0432\\u043a\\u043b\\u0430\\u0434\\u043a\\u0438\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":2},{\"MIGX_id\":2,\"field\":\"intro\",\"caption\":\"\\u0412\\u0441\\u0442\\u0443\\u043f\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439 \\u0442\\u0435\\u043a\\u0441\\u0442\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"textarea\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":3},{\"MIGX_id\":3,\"field\":\"icon\",\"caption\":\"\\u0418\\u043a\\u043e\\u043d\\u043a\\u0430 (\\u0434\\u043b\\u044f \\u0431\\u043b\\u043e\\u043a\\u0430 \\u041f\\u0440\\u0438\\u0433\\u043b\\u0430\\u0448\\u0435\\u043d\\u0438\\u0435)\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"file\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"tv\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":4},{\"MIGX_id\":4,\"field\":\"content\",\"caption\":\"\\u041a\\u043e\\u043d\\u0442\\u0435\\u043d\\u0442\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"richtext\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":5}],\"pos\":1}]', '', '', '', '', '{\"migx_add\":\"\",\"disable_add_item\":\"\",\"add_items_directly\":\"\",\"formcaption\":\"\",\"update_win_title\":\"\",\"win_id\":\"\",\"maxRecords\":\"\",\"addNewItemAt\":\"bottom\",\"media_source_id\":\"\",\"multiple_formtabs\":\"\",\"multiple_formtabs_label\":\"\",\"multiple_formtabs_field\":\"\",\"multiple_formtabs_optionstext\":\"\",\"multiple_formtabs_optionsvalue\":\"\",\"actionbuttonsperrow\":\"4\",\"winbuttonslist\":\"\",\"extrahandlers\":\"\",\"filtersperrow\":\"4\",\"packageName\":\"\",\"classname\":\"\",\"task\":\"\",\"getlistsort\":\"\",\"getlistsortdir\":\"\",\"sortconfig\":\"\",\"gridpagesize\":\"\",\"use_custom_prefix\":\"0\",\"prefix\":\"\",\"grid\":\"\",\"gridload_mode\":\"1\",\"check_resid\":\"1\",\"check_resid_TV\":\"\",\"join_alias\":\"\",\"has_jointable\":\"yes\",\"getlistwhere\":\"\",\"joins\":\"\",\"hooksnippets\":\"\",\"cmpmaincaption\":\"\",\"cmptabcaption\":\"\",\"cmptabdescription\":\"\",\"cmptabcontroller\":\"\",\"winbuttons\":\"\",\"onsubmitsuccess\":\"\",\"submitparams\":\"\"}', '{\"apiaccess\":\"\",\"view\":\"\",\"list\":\"\",\"save\":\"\",\"create\":\"\",\"remove\":\"\",\"delete\":\"\",\"publish\":\"\",\"unpublish\":\"\",\"viewdeleted\":\"\",\"viewunpublished\":\"\"}', '', '[{\"MIGX_id\":\"1\",\"header\":\"\\u0417\\u0430\\u0433\\u043e\\u043b\\u043e\\u0432\\u043e\\u043a\",\"dataIndex\":\"header\",\"width\":\"\",\"sortable\":\"false\",\"show_in_grid\":\"1\",\"customrenderer\":\"\",\"renderer\":\"\",\"clickaction\":\"\",\"selectorconfig\":\"\",\"renderchunktpl\":\"\",\"renderoptions\":\"\",\"editor\":\"\"}]', 1, '2025-07-17 14:50:39', 1, '2025-07-17 17:49:33', 0, NULL, 0, 1, NULL, 0, ''),
(2, 'sectionContent', '[{\"MIGX_id\":2,\"caption\":\"\\u0421\\u043e\\u0434\\u0435\\u0440\\u0436\\u0430\\u043d\\u0438\\u0435\",\"print_before_tabs\":\"0\",\"fields\":[{\"MIGX_id\":5,\"field\":\"header\",\"caption\":\"\\u0417\\u0430\\u0433\\u043e\\u043b\\u043e\\u0432\\u043e\\u043a\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":1},{\"MIGX_id\":7,\"field\":\"intro\",\"caption\":\"\\u0422\\u0435\\u043a\\u0441\\u0442-\\u0432\\u0441\\u0442\\u0443\\u043f\\u043b\\u0435\\u043d\\u0438\\u0435 (\\u0434\\u043b\\u044f \\u0433\\u0435\\u0440\\u043e\\u044f)\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":2},{\"MIGX_id\":8,\"field\":\"points\",\"caption\":\"\\u042d\\u043b\\u0435\\u043c\\u0435\\u043d\\u0442\\u044b\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"migx\",\"validation\":\"\",\"configs\":\"Points\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":3}],\"pos\":1},{\"MIGX_id\":3,\"caption\":\"\\u041d\\u0430\\u0441\\u0442\\u0440\\u043e\\u0439\\u043a\\u0438\",\"print_before_tabs\":\"0\",\"fields\":[{\"MIGX_id\":12,\"field\":\"anchor\",\"caption\":\"\\u042f\\u043a\\u043e\\u0440\\u044c\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":1},{\"MIGX_id\":13,\"field\":\"chunk\",\"caption\":\"\\u0418\\u043c\\u044f \\u0447\\u0430\\u043d\\u043a\\u0430\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":2},{\"MIGX_id\":14,\"field\":\"menutitle\",\"caption\":\"\\u041f\\u0443\\u043d\\u043a\\u0442 \\u043c\\u0435\\u043d\\u044e\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":3},{\"MIGX_id\":15,\"field\":\"show-in-navi\",\"caption\":\"\\u041f\\u043e\\u043a\\u0430\\u0437\\u044b\\u0432\\u0430\\u0442\\u044c \\u0432 \\u043d\\u0430\\u0432\\u0438\\u0433\\u0430\\u0446\\u0438\\u0438\",\"description\":\"\",\"description_is_code\":\"0\",\"inputTV\":\"\",\"inputTVtype\":\"checkbox\",\"validation\":\"\",\"configs\":\"\",\"restrictive_condition\":\"\",\"display\":\"\",\"sourceFrom\":\"config\",\"sources\":\"\",\"inputOptionValues\":\"\\u0414\\u0430==1\",\"default\":\"\",\"useDefaultIfEmpty\":\"0\",\"pos\":4}],\"pos\":2}]', '', '', '', '', '{\"migx_add\":\"\",\"disable_add_item\":\"\",\"add_items_directly\":\"\",\"formcaption\":\"\",\"update_win_title\":\"\",\"win_id\":\"\",\"maxRecords\":\"\",\"addNewItemAt\":\"bottom\",\"media_source_id\":\"\",\"multiple_formtabs\":\"\",\"multiple_formtabs_label\":\"\",\"multiple_formtabs_field\":\"\",\"multiple_formtabs_optionstext\":\"\",\"multiple_formtabs_optionsvalue\":\"\",\"actionbuttonsperrow\":\"4\",\"winbuttonslist\":\"\",\"extrahandlers\":\"\",\"filtersperrow\":\"4\",\"packageName\":\"\",\"classname\":\"\",\"task\":\"\",\"getlistsort\":\"\",\"getlistsortdir\":\"\",\"sortconfig\":\"\",\"gridpagesize\":\"\",\"use_custom_prefix\":\"0\",\"prefix\":\"\",\"grid\":\"\",\"gridload_mode\":\"1\",\"check_resid\":\"1\",\"check_resid_TV\":\"\",\"join_alias\":\"\",\"has_jointable\":\"yes\",\"getlistwhere\":\"\",\"joins\":\"\",\"hooksnippets\":\"\",\"cmpmaincaption\":\"\",\"cmptabcaption\":\"\",\"cmptabdescription\":\"\",\"cmptabcontroller\":\"\",\"winbuttons\":\"\",\"onsubmitsuccess\":\"\",\"submitparams\":\"\"}', '{\"apiaccess\":\"\",\"view\":\"\",\"list\":\"\",\"save\":\"\",\"create\":\"\",\"remove\":\"\",\"delete\":\"\",\"publish\":\"\",\"unpublish\":\"\",\"viewdeleted\":\"\",\"viewunpublished\":\"\"}', '', '[{\"MIGX_id\":\"1\",\"header\":\"\\u0417\\u0430\\u0433\\u043e\\u043b\\u043e\\u0432\\u043e\\u043a\",\"dataIndex\":\"header\",\"width\":\"\",\"sortable\":\"false\",\"show_in_grid\":\"1\",\"customrenderer\":\"\",\"renderer\":\"\",\"clickaction\":\"\",\"selectorconfig\":\"\",\"renderchunktpl\":\"\",\"renderoptions\":\"\",\"editor\":\"\"},{\"MIGX_id\":\"2\",\"header\":\"\\u041f\\u0443\\u043d\\u043a\\u0442 \\u043c\\u0435\\u043d\\u044e\",\"dataIndex\":\"menutitle\",\"width\":\"\",\"sortable\":\"false\",\"show_in_grid\":\"1\",\"customrenderer\":\"\",\"renderer\":\"\",\"clickaction\":\"\",\"selectorconfig\":\"\",\"renderchunktpl\":\"\",\"renderoptions\":\"\",\"editor\":\"\"}]', 1, '2025-07-17 14:53:15', 1, '2025-07-17 15:42:12', 0, NULL, 0, 1, NULL, 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_migx_config_elements`
--

CREATE TABLE `modx_migx_config_elements` (
  `id` int(10) UNSIGNED NOT NULL,
  `config_id` int(10) NOT NULL DEFAULT '0',
  `element_id` int(10) NOT NULL DEFAULT '0',
  `rank` int(10) NOT NULL DEFAULT '0',
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` datetime DEFAULT NULL,
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` datetime DEFAULT NULL,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `deletedon` datetime DEFAULT NULL,
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `publishedon` datetime DEFAULT NULL,
  `publishedby` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_migx_elements`
--

CREATE TABLE `modx_migx_elements` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(100) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` datetime DEFAULT NULL,
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` datetime DEFAULT NULL,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `deletedon` datetime DEFAULT NULL,
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `publishedon` datetime DEFAULT NULL,
  `publishedby` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_migx_formtabs`
--

CREATE TABLE `modx_migx_formtabs` (
  `id` int(10) UNSIGNED NOT NULL,
  `config_id` int(10) NOT NULL DEFAULT '0',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `pos` int(10) NOT NULL DEFAULT '0',
  `print_before_tabs` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `extended` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_migx_formtabs`
--

INSERT INTO `modx_migx_formtabs` (`id`, `config_id`, `caption`, `pos`, `print_before_tabs`, `extended`) VALUES
(1, 1, 'Поинты', 1, 0, ''),
(2, 2, 'Содержание', 1, 0, ''),
(3, 2, 'Настройки', 2, 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_migx_formtab_fields`
--

CREATE TABLE `modx_migx_formtab_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `config_id` int(10) NOT NULL DEFAULT '0',
  `formtab_id` int(10) NOT NULL DEFAULT '0',
  `field` varchar(191) NOT NULL DEFAULT '',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `pos` int(10) NOT NULL DEFAULT '0',
  `description_is_code` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `inputTV` varchar(255) NOT NULL DEFAULT '',
  `inputTVtype` varchar(255) NOT NULL DEFAULT '',
  `validation` text NOT NULL,
  `configs` varchar(255) NOT NULL DEFAULT '',
  `restrictive_condition` text NOT NULL,
  `display` varchar(255) NOT NULL DEFAULT '',
  `sourceFrom` varchar(255) NOT NULL DEFAULT '',
  `sources` varchar(255) NOT NULL DEFAULT '',
  `inputOptionValues` text NOT NULL,
  `default` text NOT NULL,
  `extended` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_migx_formtab_fields`
--

INSERT INTO `modx_migx_formtab_fields` (`id`, `config_id`, `formtab_id`, `field`, `caption`, `description`, `pos`, `description_is_code`, `inputTV`, `inputTVtype`, `validation`, `configs`, `restrictive_condition`, `display`, `sourceFrom`, `sources`, `inputOptionValues`, `default`, `extended`) VALUES
(1, 1, 1, 'header', 'Заголовок', '', 1, 0, '', '', '', '', '', '', 'config', '', '', '', ''),
(2, 1, 1, 'intro', 'Вступительный текст', '', 3, 0, '', 'textarea', '', '', '', '', 'config', '', '', '', ''),
(3, 1, 1, 'icon', 'Иконка (для блока Приглашение)', '', 4, 0, '', 'file', '', '', '', '', 'tv', '', '', '', ''),
(4, 1, 1, 'content', 'Контент', '', 5, 0, '', 'richtext', '', '', '', '', 'config', '', '', '', ''),
(5, 2, 2, 'header', 'Заголовок', '', 1, 0, '', '', '', '', '', '', 'config', '', '', '', ''),
(7, 2, 2, 'intro', 'Текст-вступление (для героя)', '', 2, 0, '', '', '', '', '', '', 'config', '', '', '', ''),
(8, 2, 2, 'points', 'Элементы', '', 3, 0, '', 'migx', '', 'Points', '', '', 'config', '', '', '', ''),
(12, 2, 3, 'anchor', 'Якорь', '', 1, 0, '', '', '', '', '', '', 'config', '', '', '', ''),
(13, 2, 3, 'chunk', 'Имя чанка', '', 2, 0, '', '', '', '', '', '', 'config', '', '', '', ''),
(14, 2, 3, 'menutitle', 'Пункт меню', '', 3, 0, '', '', '', '', '', '', 'config', '', '', '', ''),
(15, 2, 3, 'show-in-navi', 'Показывать в навигации', '', 4, 0, '', 'checkbox', '', '', '', '', 'config', '', 'Да==1', '', ''),
(16, 1, 1, 'anchor', 'Якорь вкладки', '', 2, 0, '', '', '', '', '', '', 'config', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_namespaces`
--

CREATE TABLE `modx_namespaces` (
  `name` varchar(40) NOT NULL DEFAULT '',
  `path` text,
  `assets_path` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_namespaces`
--

INSERT INTO `modx_namespaces` (`name`, `path`, `assets_path`) VALUES
('ace', '{core_path}components/ace/', ''),
('core', '{core_path}', '{assets_path}'),
('migx', '{core_path}components/migx/', '{assets_path}components/migx/'),
('tinymcerte', '{core_path}components/tinymcerte/', '{assets_path}components/tinymcerte/');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_property_set`
--

CREATE TABLE `modx_property_set` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `category` int(10) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL DEFAULT '',
  `properties` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_register_messages`
--

CREATE TABLE `modx_register_messages` (
  `topic` int(10) UNSIGNED NOT NULL,
  `id` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `valid` datetime NOT NULL,
  `accessed` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `accesses` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `expires` int(20) NOT NULL DEFAULT '0',
  `payload` mediumtext NOT NULL,
  `kill` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_register_messages`
--

INSERT INTO `modx_register_messages` (`topic`, `id`, `created`, `valid`, `accessed`, `accesses`, `expires`, `payload`, `kill`) VALUES
(1, 'c4ca4238a0b923820dcc509a6f75849b', '2025-07-18 09:34:26', '2025-07-18 09:34:26', '2025-07-18 06:34:26', 0, 1752820826, 'if (time() > 1752820826) return null;\nreturn 1;\n', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_register_queues`
--

CREATE TABLE `modx_register_queues` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `options` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_register_queues`
--

INSERT INTO `modx_register_queues` (`id`, `name`, `options`) VALUES
(1, 'locks', 'a:1:{s:9:\"directory\";s:5:\"locks\";}');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_register_topics`
--

CREATE TABLE `modx_register_topics` (
  `id` int(10) UNSIGNED NOT NULL,
  `queue` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `options` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_register_topics`
--

INSERT INTO `modx_register_topics` (`id`, `queue`, `name`, `created`, `updated`, `options`) VALUES
(1, 1, '/resource/', '2025-07-17 13:32:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_session`
--

CREATE TABLE `modx_session` (
  `id` varchar(191) NOT NULL DEFAULT '',
  `access` int(20) UNSIGNED NOT NULL,
  `data` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_session`
--

INSERT INTO `modx_session` (`id`, `access`, `data`) VALUES
('23c37943cfb366dab3a4c8e0f971e244', 1752766037, 'modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}manager_language|s:2:\"ru\";modx.user.0.resourceGroups|a:1:{s:3:\"mgr\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"mgr\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}modx.mgr.user.token|s:52:\"modx6878d099730245.20316726_16878d0b5ddd497.44187579\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:38:{i:0;s:23:\"6878d157be6b97.61735514\";i:1;s:23:\"6878d175091834.27639772\";i:2;s:23:\"6878d18db0f386.59288031\";i:3;s:23:\"6878d1d41bdce1.18149129\";i:4;s:23:\"6878d1d46a2562.42549250\";i:5;s:23:\"6878d1d4e6a8d0.63797876\";i:6;s:23:\"6878d28949ef22.70371392\";i:7;s:23:\"6878d29bb13311.81017336\";i:8;s:23:\"6878d3c4681a34.53518244\";i:9;s:23:\"6878d3c997a4d7.26681429\";i:10;s:23:\"6878d41e1161e1.53923375\";i:11;s:23:\"6878d422870f80.18515010\";i:12;s:23:\"6878d428a78a82.99393537\";i:13;s:23:\"6878d43663d717.12006762\";i:14;s:23:\"6878d4cc173329.61660490\";i:15;s:23:\"6878d4d0f3c2a6.32417166\";i:16;s:23:\"6878d4d7e09e09.84905138\";i:17;s:23:\"6878d51c54bd27.83790070\";i:18;s:23:\"6878d520c50ee5.69713545\";i:19;s:23:\"6878d69466b6d3.02782587\";i:20;s:23:\"6878d69b19fba8.75073211\";i:21;s:23:\"6878e1ef710ea8.89712960\";i:22;s:23:\"6878e468a879c0.72464588\";i:23;s:23:\"6878e486cf18c9.72415448\";i:24;s:23:\"6878e602e4f335.35898141\";i:25;s:23:\"6878e8b1aaee76.75492883\";i:26;s:23:\"6878e9466a38b2.47811758\";i:27;s:23:\"6878ea709cfbf6.88722065\";i:28;s:23:\"6878ece9910504.07244451\";i:29;s:23:\"6878edef2ee114.07606373\";i:30;s:23:\"687902a1dfc743.45243070\";i:31;s:23:\"68790437106e15.77389015\";i:32;s:23:\"68790b992640c5.89043336\";i:33;s:23:\"68790d1a251b09.19532258\";i:34;s:23:\"68790d805b2292.20894475\";i:35;s:23:\"68791123b60402.56216854\";i:36;s:23:\"68791402ef9208.94732369\";i:37;s:23:\"68791654efde23.13592427\";}'),
('9af6d9a3bf28a95edc405fc511f6b8c3', 1752820015, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:0:{}'),
('b26588bfd04a515026a2c87cf77ab5df', 1752820467, 'modx.user.0.resourceGroups|a:1:{s:3:\"mgr\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"mgr\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}manager_language|s:2:\"ru\";modx.mgr.user.token|s:52:\"modx6878d099730245.20316726_16879e22d435407.44221109\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:4:{i:0;s:23:\"6879e236efaae1.15653805\";i:1;s:23:\"6879e32a92ab27.89961932\";i:2;s:23:\"6879e70f2bf6b0.82225101\";i:3;s:23:\"6879eaf0e73d78.28694618\";}');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_content`
--

CREATE TABLE `modx_site_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'document',
  `pagetitle` varchar(191) NOT NULL DEFAULT '',
  `longtitle` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `alias` varchar(191) DEFAULT '',
  `link_attributes` varchar(255) NOT NULL DEFAULT '',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `pub_date` int(20) NOT NULL DEFAULT '0',
  `unpub_date` int(20) NOT NULL DEFAULT '0',
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `isfolder` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `introtext` text,
  `content` mediumtext,
  `richtext` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `template` int(10) NOT NULL DEFAULT '0',
  `menuindex` int(10) NOT NULL DEFAULT '0',
  `searchable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `cacheable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0',
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` int(20) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `deletedon` int(20) NOT NULL DEFAULT '0',
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `publishedon` int(20) NOT NULL DEFAULT '0',
  `publishedby` int(10) NOT NULL DEFAULT '0',
  `menutitle` varchar(255) NOT NULL DEFAULT '',
  `content_dispo` tinyint(1) NOT NULL DEFAULT '0',
  `hidemenu` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `class_key` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modDocument',
  `context_key` varchar(100) NOT NULL DEFAULT 'web',
  `content_type` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `uri` text,
  `uri_override` tinyint(1) NOT NULL DEFAULT '0',
  `hide_children_in_tree` tinyint(1) NOT NULL DEFAULT '0',
  `show_in_tree` tinyint(1) NOT NULL DEFAULT '1',
  `properties` mediumtext,
  `alias_visible` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_content`
--

INSERT INTO `modx_site_content` (`id`, `type`, `pagetitle`, `longtitle`, `description`, `alias`, `link_attributes`, `published`, `pub_date`, `unpub_date`, `parent`, `isfolder`, `introtext`, `content`, `richtext`, `template`, `menuindex`, `searchable`, `cacheable`, `createdby`, `createdon`, `editedby`, `editedon`, `deleted`, `deletedon`, `deletedby`, `publishedon`, `publishedby`, `menutitle`, `content_dispo`, `hidemenu`, `class_key`, `context_key`, `content_type`, `uri`, `uri_override`, `hide_children_in_tree`, `show_in_tree`, `properties`, `alias_visible`) VALUES
(1, 'document', 'Главная', 'Поздравляем!', '', 'index', '', 1, 0, 0, 0, 0, '', '<p>Содержимое страницы редактируется во вкладке &laquo;Дополнительные поля&raquo;.</p>\r\n<p>Страница представляет собой набор логических блоков (секций). Чтобы отредактировать содержимое секции, нужно кликнуть на ней правой кнопкой мыши, и выбрать &laquo;редактировать&raquo;. Редактор разбит на вкладки &laquo;Содержание&raquo; и &laquo;Настройки&raquo;. В содержании представлены заголовок, текст-вступление и пункты (поинты), которые используются в секции. Нажмите на поинте правой кнопкой мыши, и нажмите &laquo;Редактировать&raquo;, чтобы изменить его содержимое. Выберите &laquo;Удалить&raquo;, чтобы удалить поинт, либо нажмите кнопку &laquo;Добавить элемент&raquo; в окне редактора, чтобы добавить новый поинт.</p>\r\n<p>Чтобы отредактировать контактные данные (адреса, телефоны, и т.д.), нажмите на иконку с изображением шестерёнки в нижнем правом углу окна и выберите &laquo;Системные настройки&raquo;, в выпадающем списке &laquo;Фильтры по разделу&raquo; выберите &laquo;Контакты&raquo;. Все контакты представлены там.</p>\r\n<p>!Важно. Не удаляйте поля из системных настроек, если хотите скрыть какое-то поле, просто оставьте его пустым.</p>', 1, 1, 0, 1, 0, 1, 1752748196, 1, 1752819481, 0, 0, 0, 0, 0, '', 0, 0, 'MODX\\Revolution\\modDocument', 'web', 1, '', 0, 0, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_htmlsnippets`
--

CREATE TABLE `modx_site_htmlsnippets` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Chunk',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_htmlsnippets`
--

INSERT INTO `modx_site_htmlsnippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `static`, `static_file`) VALUES
(1, 1, 0, 'header', '', 0, 0, 0, '<header>\n	<div class=\"container\">\n		<div class=\"row\">\n			<div class=\"col\">\n				<nav>\n					<a href=\"#top\" class=\"logo scroll-link\"><img src=\"/assets/img/logo/smart-social.svg\" alt=\"Добро пожаловать!\" /></a>\n					<ul class=\"hide-l-down\">\n						<li><a href=\"#hero\" class=\"scroll-link active\">Добро пожаловать!</a></li>\n					    [[!getImageList?\n					        &tpl=`sections-navi`\n					        &tvname=`sections`\n					        &docid=`[[*id]]`\n					    ]]\n					</ul>\n					<div class=\"burger-wrapper hide-l-up\">\n						<a href=\"#mobile-menu\" class=\"bx bx-menu sidenav-trigger\"></a>\n					</div>\n				</nav>\n			</div>\n		</div>\n	</div>\n</header>\n<ul class=\"sidenav\" id=\"mobile-menu\">\n	<li><a class=\"scroll-link\" href=\"#hero\">Добро пожаловать</a></li>\n	[[!getImageList?\n	    &tpl=`sections-navi`\n	    &tvname=`sections`\n	    &docid=`[[*id]]`\n	]]\n</ul>\n', 0, 'a:0:{}', 0, ''),
(2, 1, 0, 'head', '', 0, 0, 0, '		<meta charset=\"UTF-8\" />\n		<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n		<title>[[++site_name]] || [[*pagetitle]]</title>\n		<link rel=\"stylesheet\" href=\"/assets/css/master.css\" />\n		<link rel=\"stylesheet\" href=\"/assets/css/pages/main.css\" />\n\n		<!-- Favicon -->\n		<link rel=\"icon\" type=\"image/png\" href=\"/assets/favicon/favicon-96x96.png\" sizes=\"96x96\" />\n		<link rel=\"icon\" type=\"image/svg+xml\" href=\"//assetsfavicon/favicon.svg\" />\n		<link rel=\"shortcut icon\" href=\"/assets/favicon/favicon.ico\" />\n		<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/assets/favicon/apple-touch-icon.png\" />\n		<meta name=\"apple-mobile-web-app-title\" content=\"[[++site_name]]\" />\n		<link rel=\"manifest\" href=\"/assets/favicon/site.webmanifest\" />\n		<!-- /Favicon -->', 0, 'a:0:{}', 0, ''),
(3, 1, 0, 'hero', '', 0, 0, 0, '<section id=\"hero\">\n	<div class=\"container\">\n		<div class=\"cross-top\"></div>\n		<div class=\"cross-bottom\"></div>\n		<div class=\"row\">\n			<div class=\"col l6 m8 s8 offset-s2 xs10 offset-xs1\">\n				<hgroup>\n					<h1>[[+header]]</h1>\n					<div class=\"big\">[[+intro]]</div>\n					[[++address:isnot=``:then=`<p><i class=\"bx bxs-map\"></i><span> [[++address]]</span></p>`]]\n				</hgroup>\n			</div>\n		</div>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(4, 1, 0, 'sections-navi', '', 0, 0, 0, '[[+show-in-navi:is=`1`:then=`<li><a class=\"scroll-link\" href=\"#[[+anchor]]\">[[+menutitle]]</a></li>`]]', 0, 'a:0:{}', 0, ''),
(5, 1, 0, 'footer', '', 0, 0, 0, '<footer>\n	<div class=\"container\">\n		<div class=\"row\">\n			<div class=\"col l2\">\n				<div class=\"footer-header\">Контакты</div>\n			</div>\n			<div class=\"col xl4 l4 m4 s6\">\n				<ul>\n				    [[++contact:ne:then=`\n					<li data-prefix=\"Контактное лицо\"><span><i class=\"bx bxs-user\"></i>[[++contact]]</span></li>\n				    `]]\n				    [[++phone-link:ne:then=`\n					<li data-prefix=\"Телефон\">\n						<a href=\"tel:[[++phone-link]]\"><i class=\"bx bxs-phone\"></i>[[++phone-text]]</a>\n					</li>\n				    `]]\n					[[++telegram-link:ne:then=`\n					<li data-prefix=\"Телеграм\">\n						<a href=\"[[++telegram-link]]\" target=\"_blank\"><i class=\"bx bxl-telegram\"></i>@[[++telegram-name]]</a>\n					</li>\n					`]]\n					[[++email:ne:then=`\n					<li data-prefix=\"E-mail\">\n						<a href=\"mailto:[[++email]]\"><i class=\"bx bxs-envelope-open\"></i>[[++email]]</a>\n					</li>\n					`]]\n				</ul>\n			</div>\n			<div class=\"col xl3 l3 m5 s6\">\n				<div class=\"link\">\n					<a href=\"/policy.pdf\">Политика конфиденциальности</a>\n				</div>\n				<div class=\"link\">\n					<a href=\"/agreement.pdf\">Пользовательское соглашение</a>\n				</div>\n			</div>\n			<div class=\"col xl3 l3 m3 align-right-l-up\"><small>Организатор</small><br /><a href=\"https://mobius-it.ru/\" target=\"_blank\" rel=\"nofollow\"><img src=\"/assets/img/logo/mobius.svg\" alt=\"Мобиус технологии\" /></a></div>\n		</div>\n	</div>\n</footer>\n<div class=\"footer-copyright\">\n	<div class=\"container\">\n		<div class=\"row\">\n			<div class=\"col\">\n				<div class=\"copy\">© Smart Social 2.0, Все права защищены</div>\n				<div class=\"credits\">\n					Дизайн, разработка — <a href=\"https://2br.agency\"><strong>2BR</strong></a>\n				</div>\n			</div>\n		</div>\n	</div>\n</div>\n', 0, 'a:0:{}', 0, ''),
(6, 1, 0, 'sections', '', 0, 0, 0, '[[$[[+chunk]]]]', 0, 'a:0:{}', 0, ''),
(7, 1, 0, 'about', '', 0, 0, 0, '<section id=\"about\">\n	<div class=\"container\">\n		<div class=\"row\">\n			<div class=\"col xl10 offset-xl1 l12\">\n				<div class=\"row flex\">\n					<div class=\"cross-bottom\"></div>\n					<div class=\"col\">\n						<h2>[[+header]]</h2>\n					</div>\n					[[!getImageList?\n					    &value=`[[+points]]`\n					    &tpl=`about-point`\n					]]\n				</div>\n			</div>\n		</div>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(8, 1, 0, 'about-point', '', 0, 0, 0, '<div class=\"col xl4 offset-xl1 l4 offset-l1 m6 s12\">\n	<div class=\"point\">\n		<h3>[[+header]]</h3>\n		<p>\n			[[+intro]]\n		</p>\n	</div>\n</div>', 0, 'a:0:{}', 0, ''),
(9, 1, 0, 'purpose', '', 0, 0, 0, '<section id=\"purpose\">\n	<div class=\"container\">\n		<div class=\"row\">\n			<div class=\"col xl10 offset-xl1\">\n				<div class=\"row flex purpose-wrapper\">\n					<div class=\"col\">\n						<h2>[[+header]]</h2>\n					</div>\n					<div class=\"col l6 m6 hide-m-down\">\n						<ul class=\"purpose-list\">\n						    [[!getImageList?\n						        &value=`[[+points]]`\n						        &tpl=`purpose-point`\n						    ]]\n						</ul>\n					</div>\n					<div class=\"col l5 offset-l1 m6 hide-m-down output-container-wrapper\">\n						<div class=\"output-container\">\n						    [[!getImageList?\n						        &value=`[[+points]]`\n						        &limit=`1`\n						        &tpl=`purpose-inital-point`\n						    ]]\n						</div>\n					</div>\n					<div class=\"col s12 hide-m-up\">\n						[[!getImageList?\n						    &value=`[[+points]]`\n						    &tpl=`purpose-mobile-point`\n						]]\n					</div>\n				</div>\n			</div>\n		</div>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(10, 1, 0, 'purpose-point', '', 0, 0, 0, '<li data-text=\"[[+intro]]\">\n    <div class=\"big\">[[+header]]</div>\n</li>', 0, 'a:0:{}', 0, ''),
(11, 1, 0, 'purpose-mobile-point', '', 0, 0, 0, '<details>\n	<summary><span>[[+header]]</span></summary>\n	<div class=\"details-content\">\n		<p>\n			[[+intro]]\n		</p>\n	</div>\n</details>', 0, 'a:0:{}', 0, ''),
(12, 1, 0, 'purpose-inital-point', '', 0, 0, 0, '[[+intro]]', 0, 'a:0:{}', 0, ''),
(13, 1, 0, 'included', '', 0, 0, 0, '<section id=\"includes\">\n	<div class=\"container\">\n		<div class=\"row\">\n			<div class=\"col\">\n				<h2>[[+header]]</h2>\n				<ol class=\"include-wrapper\">\n				    [[!getImageList?\n				        &value=`[[+points]]`\n				        &tpl=`included-point`\n				    ]]\n				</ol>\n			</div>\n		</div>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(14, 1, 0, 'included-point', '', 0, 0, 0, '<li class=\"include-point\">\n	<hgroup>\n		<h3>[[+header]]</h3>\n		<p>[[+intro]]</p>\n	</hgroup>\n</li>', 0, 'a:0:{}', 0, ''),
(15, 1, 0, 'discuss', '', 0, 0, 0, '<section id=\"discuss\">\n	<div class=\"container\">\n		<div class=\"row flex\">\n			<div class=\"col\">\n				<h2>[[+header]]</h2>\n			</div>\n			[[!getImageList?\n			    &value=`[[+points]]`\n			    &tpl=`discuss-point`\n			]]\n		</div>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(16, 1, 0, 'discuss-point', '', 0, 0, 0, '<div class=\"col l6 m6 s12 margin-bottom\">\r\n	<hgroup data-id=\"[[+idx]]\">\r\n		<h3>[[+header]]</h3>\r\n		<p>[[+intro]]</p>\r\n	</hgroup>\r\n</div>', 0, 'a:0:{}', 0, ''),
(17, 1, 0, 'invitation', '', 0, 0, 0, '<section id=\"invitation\">\r\n	<div class=\"container\">\r\n		<div class=\"row\">\r\n			<div class=\"col l9 offset-l3 m11 offset-m1 s12\">\r\n				<h2 style=\"font-size: clamp(21px, 3.5vw, 46px);\">[[+header]]</h2>\r\n			</div>\r\n		</div>\r\n		<div class=\"row\">\r\n			<div class=\"col l6 offset-l6 m7 offset-m5\">\r\n			    [[!getImageList?\r\n			        &value=`[[+points]]`\r\n			        &tpl=`invitation-point`\r\n			    ]]\r\n			</div>\r\n		</div>\r\n	</div>\r\n</section>\r\n', 0, 'a:0:{}', 0, ''),
(18, 1, 0, 'invitation-point', '', 0, 0, 0, '<hgroup>\n	<div class=\"icon\" style=\"background-image: url(\'[[+icon]]\')\"></div>\n	<h3>\n    	<span>[[+header]]</span>\n    	<small>[[+intro]]</small>\n	</h3>\n</hgroup>', 0, 'a:0:{}', 0, ''),
(19, 1, 0, 'speaker-form', '', 0, 0, 0, '<section id=\"speaker-form\">\n	<div class=\"container\">\n		<form class=\"row\" id=\"speaker-register-form\">\n			<div class=\"col l1 hide-l-down\">\n				<img src=\"/assets/img/dots.svg\" class=\"dots\" />\n			</div>\n			<div class=\"col l10 offset-l1\">\n				<div class=\"row flex\">\n					<div class=\"col\">\n						<div class=\"form-header\">\n							<h2>[[+header]]</h2>\n							<input type=\"hidden\" value=\"Спикер\" name=\"type\" />\n						</div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Имя, фамилия</label><input type=\"text\" name=\"name\" /></div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Компания</label><input type=\"text\" name=\"company\" /></div>\n					</div>\n					<div class=\"col l4 m12\">\n						<div class=\"input-field\"><label for=\"\">Официальный сайт компании</label><input type=\"text\" name=\"website\" /></div>\n					</div>\n					<div class=\"col l6 m12\">\n						<div class=\"input-field\"><label for=\"\">Темы выступления</label><input type=\"text\" name=\"themes\" /></div>\n					</div>\n					<div class=\"col l6 m12\">\n						<!-- <div class=\"input-field\"><label for=\"\">Название трека</label><input type=\"text\" name=\"track\" /></div> -->\n						 <div class=\"input-field\">\n							<label for=\"\">Выберите трек</label>\n							<ul class=\"select\">\n								<li class=\"current\">\n									<span>&nbsp;</span>\n									<ul class=\"list\">\n										<li class=\"waves-effect waves-light\">Инвестируем в коллаборации</li>\n										<li class=\"waves-effect waves-light\">Инвестируем в образование</li>\n										<li class=\"waves-effect waves-light\">Инвестируем в сотрудников</li>\n										<li class=\"waves-effect waves-light\">Инвестируем в общество</li>\n										<li class=\"waves-effect waves-light\">Инвестируем в корпоративную культуру</li>\n										<li class=\"waves-effect waves-light\">Инвестируем в доверие</li>\n									</ul>\n								</li>\n							</ul>\n							<input type=\"hidden\" name=\"track\">\n						 </div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Телефон</label><input type=\"text\" name=\"phone\" /></div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Аккаунт в Телеграм</label><input type=\"text\" name=\"telegram\" /></div>\n					</div>\n					<div class=\"col l4 m12\">\n						<div class=\"input-field\">\n							<a href=\"#!\" class=\"bttn register\">Зарегистрироваться</a>\n						</div>\n					</div>\n					<div class=\"col\">\n						<div class=\"check-field\">\n							<input type=\"checkbox\" id=\"speaker-agreement\" name=\"agreement\" />\n							<label for=\"speaker-agreement\"\n								><span\n									>Я даю своё согласие на сбор и обработку персональных данных согласно\n									<a href=\"policy.html\">Политике конфиденциальности</a> и <a href=\"agreement.html\">Пользовательскому соглашению</a>.</span\n								></label\n							>\n						</div>\n					</div>\n				</div>\n			</div>\n		</form>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(20, 1, 0, 'partnership', '', 0, 0, 0, '<section id=\"partnership\">\n	<div class=\"container\">\n		<div class=\"card-wrapper\">\n			<div class=\"partnership-card\">\n				<div class=\"row flex\">\n					<div class=\"col\">\n						<h2>[[+header]]</h2>\n					</div>\n					<!-- Вкладки -->\n					<div class=\"col xl3 l3 m12\">\n						<div class=\"pin\">\n							<ul class=\"tabs\">\n							    [[!getImageList?\n							        &value=`[[+points]]`\n							        &tpl=`partner-tab`\n							    ]]\n							</ul>\n						</div>\n					</div>\n					<!-- Возможности -->\n					<div class=\"col xl6 l6 m8 order1-l-down\">\n						<h3>Возможности</h3>\n						<div class=\"possibilities\">\n						    [[!getImageList?\n						        &value=`[[+points]]`\n						        &tpl=`partner-content`\n						    ]]\n						</div>\n						<small>Больше деталей расскажет наш менеджер</small>\n					</div>\n					<!-- Описание -->\n					<div class=\"col xl3 l3 m4\">\n						<div class=\"description\">\n							<div class=\"pin\">\n								<p class=\"tab-description active general\">Создаёт ключевой трек, участвует в пленарной сессии - всегда и везде на первых ролях!</p>\n								<p class=\"tab-description strategic\">\n									Проводит собственную сессию, появляется на рекламных материалах и всегда упоминается в контексте конференции!\n								</p>\n								<p class=\"tab-description leading\">\n									Выступает в рамках любой сессии, рекомендует спикеров, получается места под логотипы и занимает важное место среди главных\n									действующих лиц.\n								</p>\n								<p class=\"tab-description regular\">\n									Важный участник организационной команды Форума: влияет на сессии, появляется на рекламных материалах и присутствует на баннерах\n									площадки.\n								</p>\n							</div>\n						</div>\n					</div>\n				</div>\n			</div>\n		</div>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, ''),
(21, 1, 0, 'partner-tab', '', 0, 0, 0, '<li class=\"tab[[+idx:is=`1`:then=` active`]]\" data-tab=\"[[+anchor]]\">\n	<a href=\"#!\"><span>[[+header]]</span></a>\n</li>', 0, 'a:0:{}', 0, ''),
(22, 1, 0, 'partner-content', '', 0, 0, 0, '<div class=\"tab-content [[+anchor]] [[+idx:is=`1`:then=`active`]]\">\n	[[+content]]\n</div>', 0, 'a:0:{}', 0, ''),
(23, 1, 0, 'register-partner', '', 0, 0, 0, '<section id=\"partner-form\">\n	<div class=\"container\">\n		<form class=\"row\" id=\"partner-register-form\">\n			<div class=\"col l1 hide-l-down\">\n				<img src=\"/assets/img/dots.svg\" class=\"dots\" />\n			</div>\n			<div class=\"col l10 offset-l1\">\n				<div class=\"row flex\">\n					<div class=\"col\">\n						<div class=\"form-header\">\n							<h2>[[+header]]</h2>\n							<input type=\"hidden\" value=\"Партнёр\" name=\"type\" />\n							<input type=\"hidden\" name=\"partner-type\" value=\"general\" />\n						</div>\n					</div>\n					<div class=\"col\">\n						<div class=\"radio-group\">\n							<div class=\"radio\">\n								<input id=\"gen\" checked type=\"radio\" name=\"partner-type\" value=\"Генеральный партнёр\" /><label for=\"gen\"\n									>Генеральный партнёр</label\n								>\n							</div>\n							<div class=\"radio\">\n								<input id=\"strat\" type=\"radio\" name=\"partner-type\" value=\"Стратегический партнёр\" /><label for=\"strat\"\n									>Стратегический партнёр</label\n								>\n							</div>\n							<div class=\"radio\">\n								<input id=\"lead\" type=\"radio\" name=\"partner-type\" value=\"Ведущий партнёр\" /><label for=\"lead\">Ведущий партнёр</label>\n							</div>\n							<div class=\"radio\"><input id=\"reg\" type=\"radio\" name=\"partner-type\" value=\"Партнёр\" /><label for=\"reg\">Партнёр</label></div>\n						</div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Имя, фамилия</label><input type=\"text\" name=\"name\" /></div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Компания</label><input type=\"text\" name=\"company\" /></div>\n					</div>\n					<div class=\"col l4 m12\">\n						<div class=\"input-field\"><label for=\"\">Официальный сайт компании</label><input type=\"text\" name=\"website\" /></div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Телефон</label><input type=\"text\" name=\"phone\" /></div>\n					</div>\n					<div class=\"col l4 m6 s12\">\n						<div class=\"input-field\"><label for=\"\">Аккаунт в Телеграм</label><input type=\"text\" name=\"telegram\" /></div>\n					</div>\n					<div class=\"col l4 m12\">\n						<div class=\"input-field\">\n							<a href=\"#!\" class=\"bttn register\">Зарегистрироваться</a>\n						</div>\n					</div>\n					<div class=\"col\">\n						<div class=\"check-field\">\n							<input type=\"checkbox\" id=\"partner-agreement\" name=\"agreement\" />\n							<label for=\"partner-agreement\"\n								><span\n									>Я даю своё согласие на сбор и обработку персональных данных согласно <a href=\"policy.pdf\">Политике конфиденциальности</a> и <a href=\"agreement.pdf\">Пользовательскому соглашению</a>.</span\n								></label\n							>\n						</div>\n					</div>\n				</div>\n			</div>\n		</form>\n	</div>\n</section>\n', 0, 'a:0:{}', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_plugins`
--

CREATE TABLE `modx_site_plugins` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `plugincode` mediumtext NOT NULL,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `moduleguid` varchar(32) NOT NULL DEFAULT '',
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_plugins`
--

INSERT INTO `modx_site_plugins` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `plugincode`, `locked`, `properties`, `disabled`, `moduleguid`, `static`, `static_file`) VALUES
(1, 0, 0, 'Ace', 'Ace code editor plugin for MODx Revolution', 0, 0, 0, '/**\n * Ace Source Editor Plugin\n *\n * Events: OnManagerPageBeforeRender, OnRichTextEditorRegister, OnSnipFormPrerender,\n * OnTempFormPrerender, OnChunkFormPrerender, OnPluginFormPrerender,\n * OnFileCreateFormPrerender, OnFileEditFormPrerender, OnDocFormPrerender\n *\n * @author Danil Kostin <danya.postfactum(at)gmail.com>\n *\n * @package ace\n *\n * @var array $scriptProperties\n * @var Ace $ace\n */\nif ($modx->event->name == \'OnRichTextEditorRegister\') {\n    $modx->event->output(\'Ace\');\n    return;\n}\n\nif ($modx->getOption(\'which_element_editor\', null, \'Ace\') !== \'Ace\') {\n    return;\n}\n\n$corePath = $modx->getOption(\'ace.core_path\', null, $modx->getOption(\'core_path\').\'components/ace/\');\n$ace = $modx->getService(\'ace\', \'Ace\', $corePath.\'model/ace/\');\n$ace->initialize();\n\n$extensionMap = array(\n    \'tpl\'   => \'text/x-smarty\',\n    \'htm\'   => \'text/html\',\n    \'html\'  => \'text/html\',\n    \'css\'   => \'text/css\',\n    \'scss\'  => \'text/x-scss\',\n    \'less\'  => \'text/x-less\',\n    \'svg\'   => \'image/svg+xml\',\n    \'xml\'   => \'application/xml\',\n    \'xsl\'   => \'application/xml\',\n    \'js\'    => \'application/javascript\',\n    \'json\'  => \'application/json\',\n    \'php\'   => \'application/x-php\',\n    \'sql\'   => \'text/x-sql\',\n    \'md\'    => \'text/x-markdown\',\n    \'txt\'   => \'text/plain\',\n    \'twig\'  => \'text/x-twig\'\n);\n\n// Define default mime for html elements(templates, chunks and html resources)\n$html_elements_mime=$modx->getOption(\'ace.html_elements_mime\',null,false);\nif(!$html_elements_mime){\n    // this may deprecated in future because components may set ace.html_elements_mime option now\n    switch (true) {\n        case $modx->getOption(\'twiggy_class\'):\n            $html_elements_mime = \'text/x-twig\';\n            break;\n        case $modx->getOption(\'pdotools_fenom_parser\'):\n            $html_elements_mime = \'text/x-smarty\';\n            break;\n        default:\n            $html_elements_mime = \'text/html\';\n    }\n}\n\n// Defines wether we should highlight modx tags\n$modxTags = false;\nswitch ($modx->event->name) {\n    case \'OnSnipFormPrerender\':\n        $field = \'modx-snippet-snippet\';\n        $mimeType = \'application/x-php\';\n        break;\n    case \'OnTempFormPrerender\':\n        $field = \'modx-template-content\';\n        $modxTags = true;\n        $mimeType = $html_elements_mime;\n        break;\n    case \'OnChunkFormPrerender\':\n        $field = \'modx-chunk-snippet\';\n        if ($modx->controller->chunk && $modx->controller->chunk->isStatic()) {\n            $extension = pathinfo($modx->controller->chunk->name, PATHINFO_EXTENSION);\n            if(!$extension||!isset($extensionMap[$extension])){\n                $extension = pathinfo($modx->controller->chunk->getSourceFile(), PATHINFO_EXTENSION);\n            }\n            $mimeType = isset($extensionMap[$extension]) ? $extensionMap[$extension] : \'text/plain\';\n        } else {\n            $mimeType = $html_elements_mime;\n        }\n        $modxTags = true;\n        break;\n    case \'OnPluginFormPrerender\':\n        $field = \'modx-plugin-plugincode\';\n        $mimeType = \'application/x-php\';\n        break;\n    case \'OnFileCreateFormPrerender\':\n        $field = \'modx-file-content\';\n        $mimeType = \'text/plain\';\n        break;\n    case \'OnFileEditFormPrerender\':\n        $field = \'modx-file-content\';\n        $extension = pathinfo($scriptProperties[\'file\'], PATHINFO_EXTENSION);\n        $mimeType = isset($extensionMap[$extension])\n            ? $extensionMap[$extension]\n            : (\'@FILE:\'.pathinfo($scriptProperties[\'file\'], PATHINFO_BASENAME));\n        $modxTags = $extension == \'tpl\';\n        break;\n    case \'OnDocFormPrerender\':\n        if (!$modx->controller->resourceArray) {\n            return;\n        }\n        $field = \'ta\';\n        $mimeType = $modx->getObject(\'modContentType\', $modx->controller->resourceArray[\'content_type\'])->get(\'mime_type\');\n\n        if($mimeType == \'text/html\')$mimeType = $html_elements_mime;\n\n        if ($modx->getOption(\'use_editor\')){\n            $richText = $modx->controller->resourceArray[\'richtext\'];\n            $classKey = $modx->controller->resourceArray[\'class_key\'];\n            if ($richText || in_array($classKey, array(\'modStaticResource\',\'modSymLink\',\'modWebLink\',\'modXMLRPCResource\'))) {\n                $field = false;\n            }\n        }\n        $modxTags = true;\n        break;\n    case \'OnTVInputRenderList\':\n        $modx->event->output($corePath . \'elements/tv/input/\');\n        break;\n    default:\n        return;\n}\n\n$modxTags = (int) $modxTags;\n$script = \'\';\nif (!empty($field)) {\n    $script .= \"MODx.ux.Ace.replaceComponent(\'$field\', \'$mimeType\', $modxTags);\";\n}\n\nif ($modx->event->name == \'OnDocFormPrerender\' && !$modx->getOption(\'use_editor\')) {\n    $script .= \"MODx.ux.Ace.replaceTextAreas(Ext.query(\'.modx-richtext\'));\";\n}\n\nif ($script) {\n    $modx->controller->addHtml(\'<script>Ext.onReady(function() {\' . $script . \'});</script>\');\n}', 0, NULL, 0, '', 0, 'ace/elements/plugins/ace.plugin.php'),
(2, 0, 0, 'MIGX', '', 0, 1, 0, '$corePath = $modx->getOption(\'migx.core_path\',null,$modx->getOption(\'core_path\').\'components/migx/\');\r\n$assetsUrl = $modx->getOption(\'migx.assets_url\', null, $modx->getOption(\'assets_url\') . \'components/migx/\');\r\nswitch ($modx->event->name) {\r\n    case \'OnTVInputRenderList\':\r\n        $modx->event->output($corePath.\'elements/tv/input/\');\r\n        break;\r\n    case \'OnTVInputPropertiesList\':\r\n        $modx->event->output($corePath.\'elements/tv/inputoptions/\');\r\n        break;\r\n\r\n        case \'OnDocFormPrerender\':\r\n        $modx->controller->addCss($assetsUrl.\'css/mgr.css\');\r\n        break; \r\n \r\n    /*          \r\n    case \'OnTVOutputRenderList\':\r\n        $modx->event->output($corePath.\'elements/tv/output/\');\r\n        break;\r\n    case \'OnTVOutputRenderPropertiesList\':\r\n        $modx->event->output($corePath.\'elements/tv/properties/\');\r\n        break;\r\n    \r\n    case \'OnDocFormPrerender\':\r\n        $assetsUrl = $modx->getOption(\'colorpicker.assets_url\',null,$modx->getOption(\'assets_url\').\'components/colorpicker/\'); \r\n        $modx->regClientStartupHTMLBlock(\'<script type=\"text/javascript\">\r\n        Ext.onReady(function() {\r\n            \r\n        });\r\n        </script>\');\r\n        $modx->regClientStartupScript($assetsUrl.\'sources/ColorPicker.js\');\r\n        $modx->regClientStartupScript($assetsUrl.\'sources/ColorMenu.js\');\r\n        $modx->regClientStartupScript($assetsUrl.\'sources/ColorPickerField.js\');		\r\n        $modx->regClientCSS($assetsUrl.\'resources/css/colorpicker.css\');\r\n        break;\r\n     */\r\n}\r\nreturn;', 0, 'a:0:{}', 0, '', 0, ''),
(3, 0, 0, 'MIGXquip', '', 0, 1, 0, '$quipCorePath = $modx->getOption(\'quip.core_path\', null, $modx->getOption(\'core_path\') . \'components/quip/\');\r\n//$assetsUrl = $modx->getOption(\'migx.assets_url\', null, $modx->getOption(\'assets_url\') . \'components/migx/\');\r\nswitch ($modx->event->name)\r\n{\r\n\r\n    case \'OnDocFormPrerender\':\r\n\r\n        \r\n        require_once $quipCorePath . \'model/quip/quip.class.php\';\r\n        $modx->quip = new Quip($modx);\r\n\r\n        $modx->lexicon->load(\'quip:default\');\r\n        $quipconfig = $modx->toJson($modx->quip->config);\r\n        \r\n        $js = \"\r\n        Quip.config = Ext.util.JSON.decode(\'{$quipconfig}\');\r\n        console.log(Quip);\";\r\n\r\n        //$modx->controller->addCss($assetsUrl . \'css/mgr.css\');\r\n        $modx->controller->addJavascript($modx->quip->config[\'jsUrl\'].\'quip.js\');\r\n        $modx->controller->addHtml(\'<script type=\"text/javascript\">\' . $js . \'</script>\');\r\n        break;\r\n\r\n}\r\nreturn;', 0, 'a:0:{}', 1, '', 0, ''),
(4, 0, 0, 'migxResizeOnUpload', '', 0, 1, 0, '/**\n * migxResizeOnUpload Plugin\n *\n * Events: OnFileManagerUpload\n * Author: Bruno Perner <b.perner@gmx.de>\n * Modified to read multiple configs from mediasource-property\n * \n * First Author: Vasiliy Naumkin <bezumkin@yandex.ru>\n * Required: PhpThumbOf snippet for resizing images\n * \n * Example: mediasource - property \'resizeConfig\':\n * [{\"alias\":\"origin\",\"w\":\"500\",\"h\":\"500\",\"far\":1},{\"alias\":\"thumb\",\"w\":\"150\",\"h\":\"150\",\"far\":1}]\n */\n\nif ($modx->event->name != \'OnFileManagerUpload\') {\n    return;\n}\n\n\n$file = $modx->event->params[\'files\'][\'file\'];\n$directory = $modx->event->params[\'directory\'];\n\nif ($file[\'error\'] != 0) {\n    return;\n}\n\n$name = $file[\'name\'];\n//$extensions = explode(\',\', $modx->getOption(\'upload_images\'));\n\n$source = $modx->event->params[\'source\'];\n\nif ($source instanceof modMediaSource) {\n    //$dirTree = $modx->getOption(\'dirtree\', $_REQUEST, \'\');\n    //$modx->setPlaceholder(\'docid\', $resource_id);\n    $source->initialize();\n    $basePath = str_replace(\'/./\', \'/\', $source->getBasePath());\n    //$cachepath = $cachepath . $dirTree;\n    $baseUrl = $modx->getOption(\'site_url\') . $source->getBaseUrl();\n    //$baseUrl = $baseUrl . $dirTree;\n    $sourceProperties = $source->getPropertyList();\n\n    //echo \'<pre>\' . print_r($sourceProperties, 1) . \'</pre>\';\n    //$allowedExtensions = $modx->getOption(\'allowedFileTypes\', $sourceProperties, \'\');\n    //$allowedExtensions = empty($allowedExtensions) ? \'jpg,jpeg,png,gif\' : $allowedExtensions;\n    //$maxFilesizeMb = $modx->getOption(\'maxFilesizeMb\', $sourceProperties, \'8\');\n    //$maxFiles = $modx->getOption(\'maxFiles\', $sourceProperties, \'0\');\n    //$thumbX = $modx->getOption(\'thumbX\', $sourceProperties, \'100\');\n    //$thumbY = $modx->getOption(\'thumbY\', $sourceProperties, \'100\');\n    $resizeConfigs = $modx->getOption(\'resizeConfigs\', $sourceProperties, \'\');\n    $resizeConfigs = $modx->fromJson($resizeConfigs);\n    $thumbscontainer = $modx->getOption(\'thumbscontainer\', $sourceProperties, \'thumbs/\');\n    $imageExtensions = $modx->getOption(\'imageExtensions\', $sourceProperties, \'jpg,jpeg,png,gif,JPG\');\n    $imageExtensions = explode(\',\', $imageExtensions);\n    //$uniqueFilenames = $modx->getOption(\'uniqueFilenames\', $sourceProperties, false);\n    //$onImageUpload = $modx->getOption(\'onImageUpload\', $sourceProperties, \'\');\n    //$onImageRemove = $modx->getOption(\'onImageRemove\', $sourceProperties, \'\');\n    $cleanalias = $modx->getOption(\'cleanFilename\', $sourceProperties, false);\n\n}\n\nif (is_array($resizeConfigs) && count($resizeConfigs) > 0) {\n    foreach ($resizeConfigs as $rc) {\n        if (isset($rc[\'alias\'])) {\n            $filePath = $basePath . $directory;\n            $filePath = str_replace(\'//\',\'/\',$filePath);\n            if ($rc[\'alias\'] == \'origin\') {\n                $thumbPath = $filePath;\n            } else {\n                $thumbPath = $filePath . $rc[\'alias\'] . \'/\';\n                $permissions = octdec(\'0\' . (int)($modx->getOption(\'new_folder_permissions\', null, \'755\', true)));\n                if (!@mkdir($thumbPath, $permissions, true)) {\n                    $modx->log(MODX_LOG_LEVEL_ERROR, sprintf(\'[migxResourceMediaPath]: could not create directory %s).\', $thumbPath));\n                } else {\n                    chmod($thumbPath, $permissions);\n                }\n\n            }\n\n\n            $filename = $filePath . $name;\n            $thumbname = $thumbPath . $name;\n            $ext = substr(strrchr($name, \'.\'), 1);\n            if (in_array($ext, $imageExtensions)) {\n                $sizes = getimagesize($filename);\n                echo $sizes[0]; \n                //$format = substr($sizes[\'mime\'], 6);\n                if ($sizes[0] > $rc[\'w\'] || $sizes[1] > $rc[\'h\']) {\n                    if ($sizes[0] < $rc[\'w\']) {\n                        $rc[\'w\'] = $sizes[0];\n                    }\n                    if ($sizes[1] < $rc[\'h\']) {\n                        $rc[\'h\'] = $sizes[1];\n                    }\n                    $type = $sizes[0] > $sizes[1] ? \'landscape\' : \'portrait\';\n                    if (isset($rc[\'far\']) && $rc[\'far\'] == \'1\' && isset($rc[\'w\']) && isset($rc[\'h\'])) {\n                        if ($type = \'landscape\') {\n                            unset($rc[\'h\']);\n                        }else {\n                            unset($rc[\'w\']);\n                        }\n                    }\n\n                    $options = \'\';\n                    foreach ($rc as $k => $v) {\n                        if ($k != \'alias\') {\n                            $options .= \'&\' . $k . \'=\' . $v;\n                        }\n                    }\n                    $resized = $modx->runSnippet(\'phpthumbof\', array(\'input\' => $filePath . $name, \'options\' => $options));\n                    rename(MODX_BASE_PATH . substr($resized, 1), $thumbname);\n                }\n            }\n\n\n        }\n    }\n}', 0, 'a:0:{}', 0, '', 0, ''),
(10, 0, 0, 'TinyMCE Rich Text Editor', 'TinyMCE Rich Text Editor runtime hooks - registers and includes javascripts on document edit pages', 0, 6, 0, '/**\n * TinyMCE Rich Tech Editor Plugin\n *\n * @package tinymcerte\n * @subpackage plugin\n *\n * @var modX $modx\n * @var array $scriptProperties\n */\n\n$className = \'TinyMCERTE\\Plugins\\Events\\\\\' . $modx->event->name;\n\n$corePath = $modx->getOption(\'tinymcerte.core_path\', null, $modx->getOption(\'core_path\') . \'components/tinymcerte/\');\n/** @var TinyMCERTE $tinymcerte */\n$tinymcerte = $modx->getService(\'tinymcerte\', \'TinyMCERTE\', $corePath . \'model/tinymcerte/\', [\n    \'core_path\' => $corePath\n]);\n\nif ($tinymcerte) {\n    if (class_exists($className)) {\n        $handler = new $className($modx, $scriptProperties);\n        if (get_class($handler) == $className) {\n            $handler->run();\n        } else {\n            $modx->log(xPDO::LOG_LEVEL_ERROR, $className. \' could not be initialized!\', \'\', \'TinyMCE RTE Plugin\');\n        }\n    } else {\n        $modx->log(xPDO::LOG_LEVEL_ERROR, $className. \' was not found!\', \'\', \'TinyMCE RTE Plugin\');\n    }\n}\n\nreturn;', 0, 'a:0:{}', 0, '', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_plugin_events`
--

CREATE TABLE `modx_site_plugin_events` (
  `pluginid` int(10) NOT NULL DEFAULT '0',
  `event` varchar(191) NOT NULL DEFAULT '',
  `priority` int(10) NOT NULL DEFAULT '0',
  `propertyset` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_plugin_events`
--

INSERT INTO `modx_site_plugin_events` (`pluginid`, `event`, `priority`, `propertyset`) VALUES
(1, 'OnChunkFormPrerender', 0, 0),
(1, 'OnDocFormPrerender', 0, 0),
(1, 'OnFileCreateFormPrerender', 0, 0),
(1, 'OnFileEditFormPrerender', 0, 0),
(1, 'OnManagerPageBeforeRender', 0, 0),
(1, 'OnPluginFormPrerender', 0, 0),
(1, 'OnRichTextEditorRegister', 0, 0),
(1, 'OnSnipFormPrerender', 0, 0),
(1, 'OnTempFormPrerender', 0, 0),
(1, 'OnTVInputRenderList', 0, 0),
(2, 'OnDocFormPrerender', 0, 0),
(2, 'OnTVInputPropertiesList', 0, 0),
(2, 'OnTVInputRenderList', 0, 0),
(3, 'OnDocFormPrerender', 0, 0),
(4, 'OnFileManagerUpload', 0, 0),
(10, 'OnManagerPageBeforeRender', 0, 0),
(10, 'OnRichTextBrowserInit', 0, 0),
(10, 'OnRichTextEditorInit', 0, 0),
(10, 'OnRichTextEditorRegister', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_snippets`
--

CREATE TABLE `modx_site_snippets` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `moduleguid` varchar(32) NOT NULL DEFAULT '',
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_snippets`
--

INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(1, 0, 0, 'getImageList', '', 0, 1, 0, '/**\r\n * getImageList\r\n *\r\n * Copyright 2009-2014 by Bruno Perner <b.perner@gmx.de>\r\n *\r\n * getImageList is free software; you can redistribute it and/or modify it\r\n * under the terms of the GNU General Public License as published by the Free\r\n * Software Foundation; either version 2 of the License, or (at your option) any\r\n * later version.\r\n *\r\n * getImageList is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * getImageList; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package migx\r\n */\r\n/**\r\n * getImageList\r\n *\r\n * display Items from outputvalue of TV with custom-TV-input-type MIGX or from other JSON-string for MODx Revolution \r\n *\r\n * @version 1.4\r\n * @author Bruno Perner <b.perner@gmx.de>\r\n * @copyright Copyright &copy; 2009-2014\r\n * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License\r\n * version 2 or (at your option) any later version.\r\n * @package migx\r\n */\r\n\r\n/*example: <ul>[[!getImageList? &tvname=`myTV`&tpl=`@CODE:<li>[[+idx]]<img src=\"[[+imageURL]]\"/><p>[[+imageAlt]]</p></li>`]]</ul>*/\r\n/* get default properties */\r\n\r\n$allow_request = (bool)$modx->getOption(\'allowRequest\', $scriptProperties, false);\r\n$tvname = $modx->getOption(\'tvname\', $scriptProperties, \'\');\r\n$inherit_children_tvname = $modx->getOption(\'inherit_children_tvname\', $scriptProperties, \'\');\r\n$tpl = $modx->getOption(\'tpl\', $scriptProperties, \'\');\r\n$wrapperTpl = $modx->getOption(\'wrapperTpl\', $scriptProperties, \'\');\r\n$emptyTpl = $modx->getOption(\'emptyTpl\', $scriptProperties, \'\'); \r\n$limit = $modx->getOption(\'limit\', $scriptProperties, \'0\');\r\n$offset = $modx->getOption(\'offset\', $scriptProperties, 0);\r\n$totalVar = $modx->getOption(\'totalVar\', $scriptProperties, \'total\');\r\n$randomize = $modx->getOption(\'randomize\', $scriptProperties, false);\r\n$preselectLimit = $modx->getOption(\'preselectLimit\', $scriptProperties, 0); // when random preselect important images\r\n$where = $modx->getOption(\'where\', $scriptProperties, \'\');\r\n$where = !empty($where) ? $modx->fromJSON($where) : array();\r\n$sort = $modx->getOption(\'sort\', $scriptProperties, \'\');\r\n$sort = !empty($sort) ? $modx->fromJSON($sort) : array();\r\n$toSeparatePlaceholders = $modx->getOption(\'toSeparatePlaceholders\', $scriptProperties, false);\r\n$toPlaceholder = $modx->getOption(\'toPlaceholder\', $scriptProperties, false);\r\n$outputSeparator = $modx->getOption(\'outputSeparator\', $scriptProperties, \'\');\r\n$splitSeparator = $modx->getOption(\'splitSeparator\', $scriptProperties, \'\');\r\n$placeholdersKeyField = $modx->getOption(\'placeholdersKeyField\', $scriptProperties, \'MIGX_id\');\r\n$toJsonPlaceholder = $modx->getOption(\'toJsonPlaceholder\', $scriptProperties, false);\r\n$jsonVarKey = $modx->getOption(\'jsonVarKey\', $scriptProperties, \'migx_outputvalue\');\r\n$outputvalue = $modx->getOption(\'value\', $scriptProperties, \'\');\r\nif ($allow_request) {\r\n    $outputvalue = isset($_REQUEST[$jsonVarKey]) ? $_REQUEST[$jsonVarKey] : $outputvalue;\r\n}\r\n$docidVarKey = $modx->getOption(\'docidVarKey\', $scriptProperties, \'migx_docid\');\r\n$docid = $modx->getOption(\'docid\', $scriptProperties, (isset($modx->resource) ? $modx->resource->get(\'id\') : 1));\r\nif ($allow_request) {\r\n    $docid = isset($_REQUEST[$docidVarKey]) ? $_REQUEST[$docidVarKey] : $docid;\r\n}\r\n$processTVs = $modx->getOption(\'processTVs\', $scriptProperties, \'1\');\r\n$reverse = $modx->getOption(\'reverse\', $scriptProperties, \'0\');\r\n$sumFields = $modx->getOption(\'sumFields\', $scriptProperties, \'\');\r\n$sumPrefix = $modx->getOption(\'sumPrefix\', $scriptProperties, \'summary_\');\r\n$addfields = $modx->getOption(\'addfields\', $scriptProperties, \'\');\r\n$addfields = !empty($addfields) ? explode(\',\', $addfields) : null;\r\n//split json into parts\r\n$splits = $modx->fromJson($modx->getOption(\'splits\', $scriptProperties, 0));\r\n$splitTpl = $modx->getOption(\'splitTpl\', $scriptProperties, \'\');\r\n$splitSeparator = $modx->getOption(\'splitSeparator\', $scriptProperties, \'\');\r\n$inheritFrom = $modx->getOption(\'inheritFrom\', $scriptProperties, \'\'); //commaseparated list of resource-ids or/and the keyword \'parents\' where to inherit from\r\n$inheritFrom = !empty($inheritFrom) ? explode(\',\', $inheritFrom) : \'\';\r\n\r\n$modx->setPlaceholder(\'docid\', $docid);\r\n\r\n$base_path = $modx->getOption(\'base_path\', null, MODX_BASE_PATH);\r\n$base_url = $modx->getOption(\'base_url\', null, MODX_BASE_URL);\r\n\r\n$migx = $modx->getService(\'migx\', \'Migx\', $modx->getOption(\'migx.core_path\', null, $modx->getOption(\'core_path\') . \'components/migx/\') . \'model/migx/\', $scriptProperties);\r\nif (!($migx instanceof Migx))\r\n    return \'\';\r\n$migx->working_context = isset($modx->resource) ? $modx->resource->get(\'context_key\') : \'web\';\r\n\r\nif (!empty($tvname)) {\r\n    if ($tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $tvname))) {\r\n\r\n        /*\r\n        *   get inputProperties\r\n        */\r\n\r\n\r\n        $properties = $tv->get(\'input_properties\');\r\n        $properties = isset($properties[\'formtabs\']) ? $properties : $tv->getProperties();\r\n\r\n        $migx->config[\'configs\'] = $modx->getOption(\'configs\', $properties, \'\');\r\n        if (!empty($migx->config[\'configs\'])) {\r\n            $migx->loadConfigs();\r\n            // get tabs from file or migx-config-table\r\n            $formtabs = $migx->getTabs();\r\n        }\r\n        if (empty($formtabs) && isset($properties[\'formtabs\'])) {\r\n            //try to get formtabs and its fields from properties\r\n            $formtabs = $modx->fromJSON($properties[\'formtabs\']);\r\n        }\r\n\r\n        if (!empty($properties[\'basePath\'])) {\r\n            if ($properties[\'autoResourceFolders\'] == \'true\') {\r\n                $scriptProperties[\'base_path\'] = $base_path . $properties[\'basePath\'] . $docid . \'/\';\r\n                $scriptProperties[\'base_url\'] = $base_url . $properties[\'basePath\'] . $docid . \'/\';\r\n            } else {\r\n                $scriptProperties[\'base_path\'] = $base_path . $properties[\'base_path\'];\r\n                $scriptProperties[\'base_url\'] = $base_url . $properties[\'basePath\'];\r\n            }\r\n        }\r\n        if ($jsonVarKey == \'migx_outputvalue\' && !empty($properties[\'jsonvarkey\'])) {\r\n            $jsonVarKey = $properties[\'jsonvarkey\'];\r\n            $outputvalue = $allow_request && isset($_REQUEST[$jsonVarKey]) ? $_REQUEST[$jsonVarKey] : $outputvalue;\r\n        }\r\n\r\n        if (empty($outputvalue)) {\r\n            $outputvalue = $tv->renderOutput($docid);\r\n            if (empty($outputvalue) && !empty($inheritFrom)) {\r\n                foreach ($inheritFrom as $from) {\r\n                    if ($from == \'parents\') {\r\n                        if (!empty($inherit_children_tvname)){\r\n                            //try to get items from optional MIGX-TV for children\r\n                            if ($inh_tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $inherit_children_tvname))) {\r\n                                $outputvalue = $inh_tv->processInheritBinding(\'\', $docid);    \r\n                            }\r\n                        }\r\n                        $outputvalue = empty($outputvalue) ? $tv->processInheritBinding(\'\', $docid) : $outputvalue;\r\n                    } else {\r\n                        $outputvalue = $tv->renderOutput($from);\r\n                    }\r\n                    if (!empty($outputvalue)) {\r\n                        break;\r\n                    }\r\n                }\r\n            }\r\n        }\r\n\r\n\r\n        /*\r\n        *   get inputTvs \r\n        */\r\n        $inputTvs = array();\r\n        if (is_array($formtabs)) {\r\n\r\n            //multiple different Forms\r\n            // Note: use same field-names and inputTVs in all forms\r\n            $inputTvs = $migx->extractInputTvs($formtabs);\r\n        }\r\n        if ($migx->source = $tv->getSource($migx->working_context, false)) {\r\n            $migx->source->initialize();\r\n        }\r\n\r\n    }\r\n\r\n\r\n}\r\n\r\nif (empty($outputvalue)) {\r\n    $modx->setPlaceholder($totalVar, 0);\r\n    return \'\';\r\n}\r\n\r\n//echo $outputvalue.\'<br/><br/>\';\r\n\r\n$items = $modx->fromJSON($outputvalue);\r\n\r\n// where filter\r\nif (is_array($where) && count($where) > 0) {\r\n    $items = $migx->filterItems($where, $items);\r\n}\r\n$modx->setPlaceholder($totalVar, count($items));\r\n\r\nif (!empty($reverse)) {\r\n    $items = array_reverse($items);\r\n}\r\n\r\n// sort items\r\nif (is_array($sort) && count($sort) > 0) {\r\n    $items = $migx->sortDbResult($items, $sort);\r\n}\r\n\r\n$summaries = array();\r\n$output = \'\';\r\n$items = $offset > 0 ? array_slice($items, $offset) : $items;\r\n$count = count($items);\r\n\r\nif ($count > 0) {\r\n    $limit = $limit == 0 || $limit > $count ? $count : $limit;\r\n    $preselectLimit = $preselectLimit > $count ? $count : $preselectLimit;\r\n    //preselect important items\r\n    $preitems = array();\r\n    if ($randomize && $preselectLimit > 0) {\r\n        for ($i = 0; $i < $preselectLimit; $i++) {\r\n            $preitems[] = $items[$i];\r\n            unset($items[$i]);\r\n        }\r\n        $limit = $limit - count($preitems);\r\n    }\r\n\r\n    //shuffle items\r\n    if ($randomize) {\r\n        shuffle($items);\r\n    }\r\n\r\n    //limit items\r\n    $count = count($items);\r\n    $tempitems = array();\r\n\r\n    for ($i = 0; $i < $limit; $i++) {\r\n        if ($i >= $count) {\r\n            break;\r\n        }\r\n        $tempitems[] = $items[$i];\r\n    }\r\n    $items = $tempitems;\r\n\r\n    //add preselected items and schuffle again\r\n    if ($randomize && $preselectLimit > 0) {\r\n        $items = array_merge($preitems, $items);\r\n        shuffle($items);\r\n    }\r\n\r\n    $properties = array();\r\n    foreach ($scriptProperties as $property => $value) {\r\n        $properties[\'property.\' . $property] = $value;\r\n    }\r\n\r\n    $idx = 0;\r\n    $output = array();\r\n    $template = array();\r\n    $count = count($items);\r\n\r\n    foreach ($items as $key => $item) {\r\n        $formname = isset($item[\'MIGX_formname\']) ? $item[\'MIGX_formname\'] . \'_\' : \'\';\r\n        $fields = array();\r\n        foreach ($item as $field => $value) {\r\n            if (is_array($value)) {\r\n                if (is_array($value[0])) {\r\n                    //nested array - convert to json\r\n                    $value = $modx->toJson($value);\r\n                } else {\r\n                    $value = implode(\'||\', $value); //handle arrays (checkboxes, multiselects)\r\n                }\r\n            }\r\n\r\n\r\n            $inputTVkey = $formname . $field;\r\n\r\n            if ($processTVs && isset($inputTvs[$inputTVkey])) {\r\n                if (isset($inputTvs[$inputTVkey][\'inputTV\']) && $tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $inputTvs[$inputTVkey][\'inputTV\']))) {\r\n\r\n                } else {\r\n                    $tv = $modx->newObject(\'modTemplateVar\');\r\n                    $tv->set(\'type\', $inputTvs[$inputTVkey][\'inputTVtype\']);\r\n                }\r\n                $inputTV = $inputTvs[$inputTVkey];\r\n\r\n                $mTypes = $modx->getOption(\'manipulatable_url_tv_output_types\', null, \'image,file\');\r\n                //don\'t manipulate any urls here\r\n                $modx->setOption(\'manipulatable_url_tv_output_types\', \'\');\r\n                $tv->set(\'default_text\', $value);\r\n\r\n                // $value = $tv->renderOutput($docid); breaks if the TV used in MIGX is also assigned to this Template,\r\n                // example tv: imageLogo is assigned to the template and imageLogo is assigned to the MIGX TV as a result\r\n                // only the value of the imageLogo is returned for the MIGX TV instance\r\n                // need to override default MODX method: $value = $tv->renderOutput($docid);\r\n                /* process any TV commands in value */\r\n                $tv_value = $tv->processBindings($value, $docid);\r\n                $params = $tv->get(\'output_properties\');\r\n                if (empty($params) || $params === null) {\r\n                    $params = [];\r\n                }\r\n                /* run prepareOutput to allow for custom overriding */\r\n                $tv_value = $tv->prepareOutput($tv_value, $docid);\r\n                /* find the render */\r\n                $outputRenderPaths = $tv->getRenderDirectories(\'OnTVOutputRenderList\',\'output\');\r\n                $value = $tv->getRender($params, $tv_value, $outputRenderPaths, \'output\', $docid, $tv->get(\'display\'));\r\n                // End override of $value = $tv->renderOutput($docid);\r\n				\r\n                //set option back\r\n                $modx->setOption(\'manipulatable_url_tv_output_types\', $mTypes);\r\n                //now manipulate urls\r\n                if ($mediasource = $migx->getFieldSource($inputTV, $tv)) {\r\n                    $mTypes = explode(\',\', $mTypes);\r\n                    if (!empty($value) && in_array($tv->get(\'type\'), $mTypes)) {\r\n                        //$value = $mediasource->prepareOutputUrl($value);\r\n                        $value = str_replace(\'/./\', \'/\', $mediasource->prepareOutputUrl($value));\r\n                    }\r\n                }\r\n\r\n            }\r\n            $fields[$field] = $value;\r\n\r\n        }\r\n\r\n        if (!empty($addfields)) {\r\n            foreach ($addfields as $addfield) {\r\n                $addfield = explode(\':\', $addfield);\r\n                $addname = $addfield[0];\r\n                $adddefault = isset($addfield[1]) ? $addfield[1] : \'\';\r\n                $fields[$addname] = $adddefault;\r\n            }\r\n        }\r\n\r\n        if (!empty($sumFields)) {\r\n            $sumFields = is_array($sumFields) ? $sumFields : explode(\',\', $sumFields);\r\n            foreach ($sumFields as $sumField) {\r\n                if (isset($fields[$sumField])) {\r\n                    $summaries[$sumPrefix . $sumField] = $summaries[$sumPrefix . $sumField] + $fields[$sumField];\r\n                    $fields[$sumPrefix . $sumField] = $summaries[$sumPrefix . $sumField];\r\n                }\r\n            }\r\n        }\r\n\r\n\r\n        if ($toJsonPlaceholder) {\r\n            $output[] = $fields;\r\n        } else {\r\n            $fields[\'_alt\'] = $idx % 2;\r\n            $idx++;\r\n            $fields[\'_first\'] = $idx == 1 ? true : \'\';\r\n            $fields[\'_last\'] = $idx == $limit ? true : \'\';\r\n            $fields[\'idx\'] = $idx;\r\n            $rowtpl = \'\';\r\n            //get changing tpls from field\r\n            if (substr($tpl, 0, 7) == \"@FIELD:\") {\r\n                $tplField = substr($tpl, 7);\r\n                $rowtpl = $fields[$tplField];\r\n            }\r\n\r\n            if ($fields[\'_first\'] && !empty($tplFirst)) {\r\n                $rowtpl = $tplFirst;\r\n            }\r\n            if ($fields[\'_last\'] && empty($rowtpl) && !empty($tplLast)) {\r\n                $rowtpl = $tplLast;\r\n            }\r\n            $tplidx = \'tpl_\' . $idx;\r\n            if (empty($rowtpl) && !empty($$tplidx)) {\r\n                $rowtpl = $$tplidx;\r\n            }\r\n            if ($idx > 1 && empty($rowtpl)) {\r\n                $divisors = $migx->getDivisors($idx);\r\n                if (!empty($divisors)) {\r\n                    foreach ($divisors as $divisor) {\r\n                        $tplnth = \'tpl_n\' . $divisor;\r\n                        if (!empty($$tplnth)) {\r\n                            $rowtpl = $$tplnth;\r\n                            if (!empty($rowtpl)) {\r\n                                break;\r\n                            }\r\n                        }\r\n                    }\r\n                }\r\n            }\r\n\r\n            if ($count == 1 && isset($tpl_oneresult)) {\r\n                $rowtpl = $tpl_oneresult;\r\n            }\r\n\r\n            $fields = array_merge($fields, $properties);\r\n\r\n            if (!empty($rowtpl)) {\r\n                $template = $migx->getTemplate($tpl, $template);\r\n                $fields[\'_tpl\'] = $template[$tpl];\r\n            } else {\r\n                $rowtpl = $tpl;\r\n\r\n            }\r\n            $template = $migx->getTemplate($rowtpl, $template);\r\n\r\n\r\n            if ($template[$rowtpl]) {\r\n                $chunk = $modx->newObject(\'modChunk\');\r\n                $chunk->setCacheable(false);\r\n                $chunk->setContent($template[$rowtpl]);\r\n\r\n\r\n                if (!empty($placeholdersKeyField) && isset($fields[$placeholdersKeyField])) {\r\n                    $output[$fields[$placeholdersKeyField]] = $chunk->process($fields);\r\n                } else {\r\n                    $output[] = $chunk->process($fields);\r\n                }\r\n            } else {\r\n                if (!empty($placeholdersKeyField)) {\r\n                    $output[$fields[$placeholdersKeyField]] = \'<pre>\' . print_r($fields, 1) . \'</pre>\';\r\n                } else {\r\n                    $output[] = \'<pre>\' . print_r($fields, 1) . \'</pre>\';\r\n                }\r\n            }\r\n        }\r\n\r\n\r\n    }\r\n}\r\n\r\nif (count($summaries) > 0) {\r\n    $modx->toPlaceholders($summaries);\r\n}\r\n\r\n\r\nif ($toJsonPlaceholder) {\r\n    $modx->setPlaceholder($toJsonPlaceholder, $modx->toJson($output));\r\n    return \'\';\r\n}\r\n\r\nif (!empty($toSeparatePlaceholders)) {\r\n    $modx->toPlaceholders($output, $toSeparatePlaceholders);\r\n    return \'\';\r\n}\r\n/*\r\nif (!empty($outerTpl))\r\n$o = parseTpl($outerTpl, array(\'output\'=>implode($outputSeparator, $output)));\r\nelse \r\n*/\r\n\r\nif ($count > 0 && $splits > 0) {\r\n    $size = ceil($count / $splits);\r\n    $chunks = array_chunk($output, $size);\r\n    $output = array();\r\n    foreach ($chunks as $chunk) {\r\n        $o = implode($outputSeparator, $chunk);\r\n        $output[] = $modx->getChunk($splitTpl, array(\'output\' => $o));\r\n    }\r\n    $outputSeparator = $splitSeparator;\r\n}\r\n\r\nif (is_array($output)) {\r\n    $o = implode($outputSeparator, $output);\r\n} else {\r\n    $o = $output;\r\n}\r\n\r\nif (!empty($o) && !empty($wrapperTpl)) {\r\n    $template = $migx->getTemplate($wrapperTpl);\r\n    if ($template[$wrapperTpl]) {\r\n        $chunk = $modx->newObject(\'modChunk\');\r\n        $chunk->setCacheable(false);\r\n        $chunk->setContent($template[$wrapperTpl]);\r\n        $properties[\'output\'] = $o;\r\n        $o = $chunk->process($properties);\r\n    }\r\n}\r\n\r\nif (empty($o) && !empty($emptyTpl)) {\r\n    $template = $migx->getTemplate($emptyTpl);\r\n    if ($template[$emptyTpl]) {\r\n        $chunk = $modx->newObject(\'modChunk\');\r\n        $chunk->setCacheable(false);\r\n        $chunk->setContent($template[$emptyTpl]);\r\n        $o = $chunk->process($properties);\r\n    }\r\n}\r\n\r\nif (!empty($toPlaceholder)) {\r\n    $modx->setPlaceholder($toPlaceholder, $o);\r\n    return \'\';\r\n}\r\n\r\nreturn $o;', 0, 'a:0:{}', '', 0, ''),
(2, 0, 0, 'migxGetRelations', '', 0, 1, 0, '$id = $modx->getOption(\'id\', $scriptProperties, $modx->resource->get(\'id\'));\r\n$toPlaceholder = $modx->getOption(\'toPlaceholder\', $scriptProperties, \'\');\r\n$element = $modx->getOption(\'element\', $scriptProperties, \'getResources\');\r\n$outputSeparator = $modx->getOption(\'outputSeparator\', $scriptProperties, \',\');\r\n$sourceWhere = $modx->getOption(\'sourceWhere\', $scriptProperties, \'\');\r\n$ignoreRelationIfEmpty = $modx->getOption(\'ignoreRelationIfEmpty\', $scriptProperties, false);\r\n$inheritFromParents = $modx->getOption(\'inheritFromParents\', $scriptProperties, false);\r\n$parentIDs = $inheritFromParents ? array_merge(array($id), $modx->getParentIds($id)) : array($id);\r\n\r\n$packageName = \'resourcerelations\';\r\n\r\n$packagepath = $modx->getOption(\'core_path\') . \'components/\' . $packageName . \'/\';\r\n$modelpath = $packagepath . \'model/\';\r\n\r\n$modx->addPackage($packageName, $modelpath, $prefix);\r\n$classname = \'rrResourceRelation\';\r\n$output = \'\';\r\n\r\nforeach ($parentIDs as $id) {\r\n    if (!empty($id)) {\r\n        $output = \'\';\r\n                \r\n        $c = $modx->newQuery($classname, array(\'target_id\' => $id, \'published\' => \'1\'));\r\n        $c->select($modx->getSelectColumns($classname, $c->getAlias()));\r\n\r\n        if (!empty($sourceWhere)) {\r\n            $sourceWhere_ar = $modx->fromJson($sourceWhere);\r\n            if (is_array($sourceWhere_ar)) {\r\n                $where = array();\r\n                foreach ($sourceWhere_ar as $key => $value) {\r\n                    $where[\'Source.\' . $key] = $value;\r\n                }\r\n                $joinclass = \'modResource\';\r\n                $joinalias = \'Source\';\r\n                $selectfields = \'id\';\r\n                $selectfields = !empty($selectfields) ? explode(\',\', $selectfields) : null;\r\n                $c->leftjoin($joinclass, $joinalias);\r\n                $c->select($modx->getSelectColumns($joinclass, $joinalias, $joinalias . \'_\', $selectfields));\r\n                $c->where($where);\r\n            }\r\n        }\r\n\r\n        //$c->prepare(); echo $c->toSql();\r\n        if ($c->prepare() && $c->stmt->execute()) {\r\n            $collection = $c->stmt->fetchAll(PDO::FETCH_ASSOC);\r\n        }\r\n        \r\n        foreach ($collection as $row) {\r\n            $ids[] = $row[\'source_id\'];\r\n        }\r\n        $output = implode($outputSeparator, $ids);\r\n    }\r\n    if (!empty($output)){\r\n        break;\r\n    }\r\n}\r\n\r\n\r\nif (!empty($element)) {\r\n    if (empty($output) && $ignoreRelationIfEmpty) {\r\n        return $modx->runSnippet($element, $scriptProperties);\r\n    } else {\r\n        $scriptProperties[\'resources\'] = $output;\r\n        $scriptProperties[\'parents\'] = \'9999999\';\r\n        return $modx->runSnippet($element, $scriptProperties);\r\n    }\r\n\r\n\r\n}\r\n\r\nif (!empty($toPlaceholder)) {\r\n    $modx->setPlaceholder($toPlaceholder, $output);\r\n    return \'\';\r\n}\r\n\r\nreturn $output;', 0, 'a:0:{}', '', 0, ''),
(3, 0, 0, 'migx', '', 0, 1, 0, '$tvname = $modx->getOption(\'tvname\', $scriptProperties, \'\');\r\n$tpl = $modx->getOption(\'tpl\', $scriptProperties, \'\');\r\n$limit = $modx->getOption(\'limit\', $scriptProperties, \'0\');\r\n$offset = $modx->getOption(\'offset\', $scriptProperties, 0);\r\n$totalVar = $modx->getOption(\'totalVar\', $scriptProperties, \'total\');\r\n$randomize = $modx->getOption(\'randomize\', $scriptProperties, false);\r\n$preselectLimit = $modx->getOption(\'preselectLimit\', $scriptProperties, 0); // when random preselect important images\r\n$where = $modx->getOption(\'where\', $scriptProperties, \'\');\r\n$where = !empty($where) ? $modx->fromJSON($where) : array();\r\n$sortConfig = $modx->getOption(\'sortConfig\', $scriptProperties, \'\');\r\n$sortConfig = !empty($sortConfig) ? $modx->fromJSON($sortConfig) : array();\r\n$configs = $modx->getOption(\'configs\', $scriptProperties, \'\');\r\n$configs = !empty($configs) ? explode(\',\',$configs):array();\r\n$toSeparatePlaceholders = $modx->getOption(\'toSeparatePlaceholders\', $scriptProperties, false);\r\n$toPlaceholder = $modx->getOption(\'toPlaceholder\', $scriptProperties, false);\r\n$outputSeparator = $modx->getOption(\'outputSeparator\', $scriptProperties, \'\');\r\n//$placeholdersKeyField = $modx->getOption(\'placeholdersKeyField\', $scriptProperties, \'MIGX_id\');\r\n$placeholdersKeyField = $modx->getOption(\'placeholdersKeyField\', $scriptProperties, \'id\');\r\n$toJsonPlaceholder = $modx->getOption(\'toJsonPlaceholder\', $scriptProperties, false);\r\n$jsonVarKey = $modx->getOption(\'jsonVarKey\', $scriptProperties, \'migx_outputvalue\');\r\n$outputvalue = $modx->getOption(\'value\', $scriptProperties, \'\');\r\n$outputvalue = isset($_REQUEST[$jsonVarKey]) ? $_REQUEST[$jsonVarKey] : $outputvalue;\r\n$docidVarKey = $modx->getOption(\'docidVarKey\', $scriptProperties, \'migx_docid\');\r\n$docid = $modx->getOption(\'docid\', $scriptProperties, (isset($modx->resource) ? $modx->resource->get(\'id\') : 1));\r\n$docid = isset($_REQUEST[$docidVarKey]) ? $_REQUEST[$docidVarKey] : $docid;\r\n$processTVs = $modx->getOption(\'processTVs\', $scriptProperties, \'1\');\r\n\r\n$base_path = $modx->getOption(\'base_path\', null, MODX_BASE_PATH);\r\n$base_url = $modx->getOption(\'base_url\', null, MODX_BASE_URL);\r\n\r\n$migx = $modx->getService(\'migx\', \'Migx\', $modx->getOption(\'migx.core_path\', null, $modx->getOption(\'core_path\') . \'components/migx/\') . \'model/migx/\', $scriptProperties);\r\nif (!($migx instanceof Migx))\r\n    return \'\';\r\n//$modx->migx = &$migx;\r\n$defaultcontext = \'web\';\r\n$migx->working_context = isset($modx->resource) ? $modx->resource->get(\'context_key\') : $defaultcontext;\r\n\r\nif (!empty($tvname))\r\n{\r\n    if ($tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $tvname)))\r\n    {\r\n\r\n        /*\r\n        *   get inputProperties\r\n        */\r\n\r\n\r\n        $properties = $tv->get(\'input_properties\');\r\n        $properties = isset($properties[\'configs\']) ? $properties : $tv->getProperties();\r\n        $cfgs = $modx->getOption(\'configs\',$properties,\'\');\r\n        if (!empty($cfgs)){\r\n            $cfgs = explode(\',\',$cfgs);\r\n            $configs = array_merge($configs,$cfgs);\r\n           \r\n        }\r\n        \r\n    }\r\n}\r\n\r\n\r\n\r\n//$migx->config[\'configs\'] = implode(\',\',$configs);\r\n$migx->loadConfigs(false,true,array(\'configs\'=>implode(\',\',$configs)));\r\n$migx->customconfigs = array_merge($migx->customconfigs,$scriptProperties);\r\n\r\n\r\n\r\n// get tabs from file or migx-config-table\r\n$formtabs = $migx->getTabs();\r\nif (empty($formtabs))\r\n{\r\n    //try to get formtabs and its fields from properties\r\n    $formtabs = $modx->fromJSON($properties[\'formtabs\']);\r\n}\r\n\r\nif ($jsonVarKey == \'migx_outputvalue\' && !empty($properties[\'jsonvarkey\']))\r\n{\r\n    $jsonVarKey = $properties[\'jsonvarkey\'];\r\n    $outputvalue = isset($_REQUEST[$jsonVarKey]) ? $_REQUEST[$jsonVarKey] : $outputvalue;\r\n}\r\n\r\n$outputvalue = $tv && empty($outputvalue) ? $tv->renderOutput($docid) : $outputvalue;\r\n/*\r\n*   get inputTvs \r\n*/\r\n$inputTvs = array();\r\nif (is_array($formtabs))\r\n{\r\n\r\n    //multiple different Forms\r\n    // Note: use same field-names and inputTVs in all forms\r\n    $inputTvs = $migx->extractInputTvs($formtabs);\r\n}\r\n\r\nif ($tv)\r\n{\r\n    $migx->source = $tv->getSource($migx->working_context, false);\r\n}\r\n\r\n//$task = $modx->migx->getTask();\r\n$filename = \'getlist.php\';\r\n$processorspath = $migx->config[\'processorsPath\'] . \'mgr/\';\r\n$filenames = array();\r\n$scriptProperties[\'start\'] = $modx->getOption(\'offset\', $scriptProperties, 0);\r\nif ($processor_file = $migx->findProcessor($processorspath, $filename, $filenames))\r\n{\r\n    include ($processor_file);\r\n    //todo: add getlist-processor for default-MIGX-TV\r\n}\r\n\r\n$items = isset($rows) && is_array($rows) ? $rows : array();\r\n$modx->setPlaceholder($totalVar, isset($count) ? $count : 0);\r\n\r\n$properties = array();\r\nforeach ($scriptProperties as $property => $value)\r\n{\r\n    $properties[\'property.\' . $property] = $value;\r\n}\r\n\r\n$idx = 0;\r\n$output = array();\r\nforeach ($items as $key => $item)\r\n{\r\n\r\n    $fields = array();\r\n    foreach ($item as $field => $value)\r\n    {\r\n        $value = is_array($value) ? implode(\'||\', $value) : $value; //handle arrays (checkboxes, multiselects)\r\n        if ($processTVs && isset($inputTvs[$field]))\r\n        {\r\n            if ($tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $inputTvs[$field][\'inputTV\'])))\r\n            {\r\n\r\n            } else\r\n            {\r\n                $tv = $modx->newObject(\'modTemplateVar\');\r\n                $tv->set(\'type\', $inputTvs[$field][\'inputTVtype\']);\r\n            }\r\n            $inputTV = $inputTvs[$field];\r\n\r\n            $mTypes = $modx->getOption(\'manipulatable_url_tv_output_types\', null, \'image,file\');\r\n            //don\'t manipulate any urls here\r\n            $modx->setOption(\'manipulatable_url_tv_output_types\', \'\');\r\n            $tv->set(\'default_text\', $value);\r\n            $value = $tv->renderOutput($docid);\r\n            //set option back\r\n            $modx->setOption(\'manipulatable_url_tv_output_types\', $mTypes);\r\n            //now manipulate urls\r\n            if ($mediasource = $migx->getFieldSource($inputTV, $tv))\r\n            {\r\n                $mTypes = explode(\',\', $mTypes);\r\n                if (!empty($value) && in_array($tv->get(\'type\'), $mTypes))\r\n                {\r\n                    //$value = $mediasource->prepareOutputUrl($value);\r\n                    $value = str_replace(\'/./\', \'/\', $mediasource->prepareOutputUrl($value));\r\n                }\r\n            }\r\n\r\n        }\r\n        $fields[$field] = $value;\r\n\r\n    }\r\n    if ($toJsonPlaceholder)\r\n    {\r\n        $output[] = $fields;\r\n    } else\r\n    {\r\n        $fields[\'_alt\'] = $idx % 2;\r\n        $idx++;\r\n        $fields[\'_first\'] = $idx == 1 ? true : \'\';\r\n        $fields[\'_last\'] = $idx == $limit ? true : \'\';\r\n        $fields[\'idx\'] = $idx;\r\n        $rowtpl = $tpl;\r\n        //get changing tpls from field\r\n        if (substr($tpl, 0, 7) == \"@FIELD:\")\r\n        {\r\n            $tplField = substr($tpl, 7);\r\n            $rowtpl = $fields[$tplField];\r\n        }\r\n\r\n        if (!isset($template[$rowtpl]))\r\n        {\r\n            if (substr($rowtpl, 0, 6) == \"@FILE:\")\r\n            {\r\n                $template[$rowtpl] = file_get_contents($modx->config[\'base_path\'] . substr($rowtpl, 6));\r\n            } elseif (substr($rowtpl, 0, 6) == \"@CODE:\")\r\n            {\r\n                $template[$rowtpl] = substr($tpl, 6);\r\n            } elseif ($chunk = $modx->getObject(\'modChunk\', array(\'name\' => $rowtpl), true))\r\n            {\r\n                $template[$rowtpl] = $chunk->getContent();\r\n            } else\r\n            {\r\n                $template[$rowtpl] = false;\r\n            }\r\n        }\r\n\r\n        $fields = array_merge($fields, $properties);\r\n\r\n        if ($template[$rowtpl])\r\n        {\r\n            $chunk = $modx->newObject(\'modChunk\');\r\n            $chunk->setCacheable(false);\r\n            $chunk->setContent($template[$rowtpl]);\r\n            if (!empty($placeholdersKeyField) && isset($fields[$placeholdersKeyField]))\r\n            {\r\n                $output[$fields[$placeholdersKeyField]] = $chunk->process($fields);\r\n            } else\r\n            {\r\n                $output[] = $chunk->process($fields);\r\n            }\r\n        } else\r\n        {\r\n            if (!empty($placeholdersKeyField))\r\n            {\r\n                $output[$fields[$placeholdersKeyField]] = \'<pre>\' . print_r($fields, 1) . \'</pre>\';\r\n            } else\r\n            {\r\n                $output[] = \'<pre>\' . print_r($fields, 1) . \'</pre>\';\r\n            }\r\n        }\r\n    }\r\n\r\n\r\n}\r\n\r\n\r\nif ($toJsonPlaceholder)\r\n{\r\n    $modx->setPlaceholder($toJsonPlaceholder, $modx->toJson($output));\r\n    return \'\';\r\n}\r\n\r\nif (!empty($toSeparatePlaceholders))\r\n{\r\n    $modx->toPlaceholders($output, $toSeparatePlaceholders);\r\n    return \'\';\r\n}\r\n/*\r\nif (!empty($outerTpl))\r\n$o = parseTpl($outerTpl, array(\'output\'=>implode($outputSeparator, $output)));\r\nelse \r\n*/\r\nif (is_array($output))\r\n{\r\n    $o = implode($outputSeparator, $output);\r\n} else\r\n{\r\n    $o = $output;\r\n}\r\n\r\nif (!empty($toPlaceholder))\r\n{\r\n    $modx->setPlaceholder($toPlaceholder, $o);\r\n    return \'\';\r\n}\r\n\r\nreturn $o;', 0, 'a:0:{}', '', 0, ''),
(4, 0, 0, 'migxLoopCollection', '', 0, 1, 0, '/*\r\ngetXpdoInstanceAndAddPackage - properties\r\n\r\n$prefix\r\n$usecustomprefix\r\n$packageName\r\n\r\n\r\nprepareQuery - properties:\r\n\r\n$limit\r\n$offset\r\n$totalVar\r\n$where\r\n$queries\r\n$sortConfig\r\n$groupby\r\n$joins\r\n$selectfields\r\n$classname\r\n$debug\r\n\r\nrenderOutput - properties:\r\n\r\n$tpl\r\n$wrapperTpl\r\n$toSeparatePlaceholders\r\n$toPlaceholder\r\n$outputSeparator\r\n$placeholdersKeyField\r\n$toJsonPlaceholder\r\n$jsonVarKey\r\n$addfields\r\n\r\n*/\r\n\r\n\r\n$migx = $modx->getService(\'migx\', \'Migx\', $modx->getOption(\'migx.core_path\', null, $modx->getOption(\'core_path\') . \'components/migx/\') . \'model/migx/\', $scriptProperties);\r\nif (!($migx instanceof Migx))\r\n    return \'\';\r\n//$modx->migx = &$migx;\r\n\r\n$xpdo = $migx->getXpdoInstanceAndAddPackage($scriptProperties);\r\n\r\n$defaultcontext = \'web\';\r\n$migx->working_context = isset($modx->resource) ? $modx->resource->get(\'context_key\') : $defaultcontext;\r\n\r\n$c = $migx->prepareQuery($xpdo,$scriptProperties);\r\n$rows = $migx->getCollection($c);\r\n\r\n$output = $migx->renderOutput($rows,$scriptProperties);\r\n\r\nreturn $output;', 0, 'a:0:{}', '', 0, ''),
(5, 0, 0, 'migxResourceMediaPath', '', 0, 1, 0, '/**\r\n * @name migxResourceMediaPath\r\n * @description Dynamically calculates the upload path for a given resource\r\n * \r\n * This Snippet is meant to dynamically calculate your baseBath attribute\r\n * for custom Media Sources.  This is useful if you wish to shepard uploaded\r\n * images to a folder dedicated to a given resource.  E.g. page 123 would \r\n * have its own images that page 456 could not reference.\r\n *\r\n * USAGE:\r\n * [[migxResourceMediaPath? &pathTpl=`assets/businesses/{id}/`]]\r\n * [[migxResourceMediaPath? &pathTpl=`assets/resourceimages/{id}/` &checkTVs=`mymigxtv`]]\r\n * [[migxResourceMediaPath? &pathTpl=`assets/test/{breadcrumb}`]]\r\n * [[migxResourceMediaPath? &pathTpl=`assets/test/{breadcrumb}` &breadcrumbdepth=`2`]]\r\n *\r\n * PARAMETERS\r\n * &pathTpl string formatting string specifying the file path. \r\n *		Relative to MODX base_path\r\n *		Available placeholders: {id}, {pagetitle}, {parent}\r\n * &docid (optional) integer page id\r\n * &createFolder (optional) boolean whether or not to create directory\r\n * &checkTVs (optional) commaseperated list of TVs to check, before directory is created \r\n */\r\n$pathTpl = $modx->getOption(\'pathTpl\', $scriptProperties, \'\');\r\n$docid = $modx->getOption(\'docid\', $scriptProperties, \'\');\r\n$createfolder = $modx->getOption(\'createFolder\', $scriptProperties, false);\r\n$tvname = $modx->getOption(\'tvname\', $scriptProperties, \'\');\r\n$checktvs = $modx->getOption(\'checkTVs\', $scriptProperties, false);\r\n\r\n$path = \'\';\r\n$fullpath = \'\';\r\n$createpath = false;\r\n$fallbackpath = $modx->getOption(\'fallbackPath\', $scriptProperties, \'assets/migxfallback/\');\r\n\r\nif (empty($pathTpl)) {\r\n    $modx->log(MODX_LOG_LEVEL_DEBUG, \'[migxResourceMediaPath]: pathTpl not specified.\');\r\n}\r\n\r\nif (empty($docid) && $modx->getPlaceholder(\'mediasource_docid\')) {\r\n    // placeholder was set by some script\r\n    // warning: the parser may not render placeholders, e.g. &docid=`[[*parent]]` may fail\r\n    $docid = $modx->getPlaceholder(\'mediasource_docid\');\r\n}\r\n\r\nif (empty($docid) && $modx->getPlaceholder(\'docid\')) {\r\n    // placeholder was set by some script\r\n    // warning: the parser may not render placeholders, e.g. &docid=`[[*parent]]` may fail\r\n    $docid = $modx->getPlaceholder(\'docid\');\r\n}\r\nif (empty($docid)) {\r\n\r\n    //on frontend\r\n    if (is_object($modx->resource)) {\r\n        $docid = $modx->resource->get(\'id\');\r\n    }\r\n    //on manager resource/update page\r\n    else {\r\n        $createpath = $createfolder;\r\n        // We do this to read the &id param from an Ajax request\r\n        $parsedUrl = parse_url($_SERVER[\'HTTP_REFERER\']);\r\n        parse_str($parsedUrl[\'query\'], $parsedQuery);\r\n\r\n        $action = $parsedQuery[\'a\'] ?? \'\';\r\n        if ($action == \'resource/update\'){\r\n            $docid = (int)$parsedQuery[\'amp;id\'] ?? (int)$parsedQuery[\'id\'] ?? 0;\r\n        }\r\n    }\r\n}\r\n\r\nif (empty($docid)) {\r\n    $modx->log(MODX_LOG_LEVEL_DEBUG, \'[migxResourceMediaPath]: docid could not be determined.\');\r\n}\r\n\r\nif (empty($docid) || empty($pathTpl)) {\r\n    $path = $fallbackpath;\r\n    $fullpath = $modx->getOption(\'base_path\') . $fallbackpath;\r\n    $createpath = true;\r\n}\r\n\r\nif (empty($fullpath) && $resource = $modx->getObject(\'modResource\', $docid)) {\r\n    $path = $pathTpl;\r\n    $ultimateParent = \'\';\r\n    if (strstr($path, \'{breadcrumb}\') || strstr($path, \'{ultimateparent}\')) {\r\n        $depth = $modx->getOption(\'breadcrumbdepth\', $scriptProperties, 10);\r\n        $ctx = $resource->get(\'context_key\');\r\n        $parentids = $modx->getParentIds($docid, $depth, array(\'context\' => $ctx));\r\n        $breadcrumbdepth = $modx->getOption(\'breadcrumbdepth\', $scriptProperties, count($parentids));\r\n        $breadcrumbdepth = $breadcrumbdepth > count($parentids) ? count($parentids) : $breadcrumbdepth;\r\n        if (count($parentids) > 1) {\r\n            $parentids = array_reverse($parentids);\r\n            $parentids[] = $docid;\r\n            $ultimateParent = $parentids[1];\r\n        } else {\r\n            $ultimateParent = $docid;\r\n            $parentids = array();\r\n            $parentids[] = $docid;\r\n        }\r\n    }\r\n\r\n    if (strstr($path, \'{breadcrumb}\')) {\r\n        $breadcrumbpath = \'\';\r\n        for ($i = 1; $i <= $breadcrumbdepth; $i++) {\r\n            $breadcrumbpath .= $parentids[$i] . \'/\';\r\n        }\r\n        $path = str_replace(\'{breadcrumb}\', $breadcrumbpath, $path);\r\n    }\r\n    \r\n    if (!empty($tvname)){\r\n        $path = str_replace(\'{tv_value}\', $resource->getTVValue($tvname), $path);    \r\n    }\r\n    $path = str_replace(\'{id}\', $docid, $path);\r\n    $path = str_replace(\'{pagetitle}\', $resource->get(\'pagetitle\'), $path);\r\n    $path = str_replace(\'{alias}\', $resource->get(\'alias\'), $path);\r\n    $path = str_replace(\'{parent}\', $resource->get(\'parent\'), $path);\r\n    $path = str_replace(\'{context_key}\', $resource->get(\'context_key\'), $path);\r\n    $path = str_replace(\'{ultimateparent}\', $ultimateParent, $path);\r\n    if ($template = $resource->getOne(\'Template\')) {\r\n        $path = str_replace(\'{templatename}\', $template->get(\'templatename\'), $path);\r\n    }\r\n    if ($user = $modx->user) {\r\n        $path = str_replace(\'{username}\', $modx->user->get(\'username\'), $path);\r\n        $path = str_replace(\'{userid}\', $modx->user->get(\'id\'), $path);\r\n    }\r\n\r\n    $fullpath = $modx->getOption(\'base_path\') . $path;\r\n\r\n    if ($createpath && $checktvs){\r\n        $createpath = false;\r\n        if ($template) {\r\n            $tvs = explode(\',\',$checktvs);\r\n            foreach ($tvs as $tv){\r\n                if ($template->hasTemplateVar($tv)){\r\n                    $createpath = true;\r\n                }\r\n            }            \r\n        } \r\n\r\n    }\r\n\r\n} else {\r\n    $modx->log(MODX_LOG_LEVEL_DEBUG, sprintf(\'[migxResourceMediaPath]: resource not found (page id %s).\', $docid));\r\n}\r\n\r\nif ($createpath && !file_exists($fullpath)) {\r\n\r\n    $permissions = octdec(\'0\' . (int)($modx->getOption(\'new_folder_permissions\', null, \'755\', true)));\r\n    if (!@mkdir($fullpath, $permissions, true)) {\r\n        $modx->log(MODX_LOG_LEVEL_DEBUG, sprintf(\'[migxResourceMediaPath]: could not create directory %s).\', $fullpath));\r\n    } else {\r\n        chmod($fullpath, $permissions);\r\n    }\r\n}\r\n\r\nreturn $path;', 0, 'a:0:{}', '', 0, ''),
(6, 0, 0, 'migxImageUpload', '', 0, 1, 0, 'return include $modx->getOption(\'core_path\').\'components/migx/model/imageupload/imageupload.php\';', 0, 'a:0:{}', '', 0, ''),
(7, 0, 0, 'migxChunklistToJson', '', 0, 1, 0, '$category = $modx->getOption(\'category\', $scriptProperties, \'\');\r\n$format = $modx->getOption(\'format\', $scriptProperties, \'json\');\r\n\r\n$classname = \'modChunk\';\r\n$rows = array();\r\n$output = \'\';\r\n\r\n$c = $modx->newQuery($classname);\r\n$c->select($modx->getSelectColumns($classname, $c->getAlias(), \'\', array(\'id\', \'name\')));\r\n$c->sortby(\'name\');\r\n\r\nif (!empty($category)) {\r\n    $c->where(array(\'category\' => $category));\r\n}\r\n//$c->prepare();echo $c->toSql();\r\nif ($collection = $modx->getCollection($classname, $c)) {\r\n    $i = 0;\r\n\r\n    switch ($format) {\r\n        case \'json\':\r\n            foreach ($collection as $object) {\r\n                $row[\'MIGX_id\'] = (string )$i;\r\n                $row[\'name\'] = $object->get(\'name\');\r\n                $row[\'selected\'] = \'0\';\r\n                $rows[] = $row;\r\n                $i++;\r\n            }\r\n            $output = $modx->toJson($rows);\r\n            break;\r\n        \r\n        case \'optionlist\':\r\n            foreach ($collection as $object) {\r\n                $rows[] = $object->get(\'name\');\r\n                $i++;\r\n            }\r\n            $output = implode(\'||\',$rows);      \r\n        break;\r\n            \r\n    }\r\n\r\n\r\n}\r\n\r\nreturn $output;', 0, 'a:0:{}', '', 0, ''),
(8, 0, 0, 'migxSwitchDetailChunk', '', 0, 1, 0, '//[[migxSwitchDetailChunk? &detailChunk=`detailChunk` &listingChunk=`listingChunk`]]\r\n\r\n\r\n$properties[\'migx_id\'] = $modx->getOption(\'migx_id\',$_GET,\'\');\r\n\r\nif (!empty($properties[\'migx_id\'])){\r\n    $output = $modx->getChunk($detailChunk,$properties);\r\n}\r\nelse{\r\n    $output = $modx->getChunk($listingChunk);\r\n}\r\n\r\nreturn $output;', 0, 'a:0:{}', '', 0, ''),
(9, 0, 0, 'getSwitchColumnCol', '', 0, 1, 0, '$scriptProperties = $_REQUEST;\r\n$col = \'\';\r\n// special actions, for example the showSelector - action\r\n$tempParams = $modx->getOption(\'tempParams\', $scriptProperties, \'\');\r\n\r\nif (!empty($tempParams)) {\r\n    $tempParams = $modx->fromJson($tempParams);\r\n    $col = $modx->getOption(\'col\', $tempParams, \'\');\r\n}\r\n\r\nreturn $col;', 0, 'a:0:{}', '', 0, '');
INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(10, 0, 0, 'getDayliMIGXrecord', '', 0, 1, 0, '/**\r\n * getDayliMIGXrecord\r\n *\r\n * Copyright 2009-2011 by Bruno Perner <b.perner@gmx.de>\r\n *\r\n * getDayliMIGXrecord is free software; you can redistribute it and/or modify it\r\n * under the terms of the GNU General Public License as published by the Free\r\n * Software Foundation; either version 2 of the License, or (at your option) any\r\n * later version.\r\n *\r\n * getDayliMIGXrecord is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * getDayliMIGXrecord; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package migx\r\n */\r\n/**\r\n * getDayliMIGXrecord\r\n *\r\n * display Items from outputvalue of TV with custom-TV-input-type MIGX or from other JSON-string for MODx Revolution \r\n *\r\n * @version 1.0\r\n * @author Bruno Perner <b.perner@gmx.de>\r\n * @copyright Copyright &copy; 2012\r\n * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License\r\n * version 2 or (at your option) any later version.\r\n * @package migx\r\n */\r\n\r\n/*example: [[!getDayliMIGXrecord? &tvname=`myTV`&tpl=`@CODE:<img src=\"[[+image]]\"/>` &randomize=`1`]]*/\r\n/* get default properties */\r\n\r\n\r\n$tvname = $modx->getOption(\'tvname\', $scriptProperties, \'\');\r\n$tpl = $modx->getOption(\'tpl\', $scriptProperties, \'\');\r\n$randomize = $modx->getOption(\'randomize\', $scriptProperties, false);\r\n$where = $modx->getOption(\'where\', $scriptProperties, \'\');\r\n$where = !empty($where) ? $modx->fromJSON($where) : array();\r\n$sort = $modx->getOption(\'sort\', $scriptProperties, \'\');\r\n$sort = !empty($sort) ? $modx->fromJSON($sort) : array();\r\n$toPlaceholder = $modx->getOption(\'toPlaceholder\', $scriptProperties, false);\r\n$docid = $modx->getOption(\'docid\', $scriptProperties, (isset($modx->resource) ? $modx->resource->get(\'id\') : 1));\r\n$processTVs = $modx->getOption(\'processTVs\', $scriptProperties, \'1\');\r\n\r\n$migx = $modx->getService(\'migx\', \'Migx\', $modx->getOption(\'migx.core_path\', null, $modx->getOption(\'core_path\') . \'components/migx/\') . \'model/migx/\', $scriptProperties);\r\nif (!($migx instanceof Migx))\r\n    return \'\';\r\n$migx->working_context = $modx->resource->get(\'context_key\');\r\n\r\nif (!empty($tvname)) {\r\n    if ($tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $tvname))) {\r\n\r\n        /*\r\n        *   get inputProperties\r\n        */\r\n\r\n\r\n        $properties = $tv->get(\'input_properties\');\r\n        $properties = isset($properties[\'formtabs\']) ? $properties : $tv->getProperties();\r\n\r\n        $migx->config[\'configs\'] = $properties[\'configs\'];\r\n        $migx->loadConfigs();\r\n        // get tabs from file or migx-config-table\r\n        $formtabs = $migx->getTabs();\r\n        if (empty($formtabs)) {\r\n            //try to get formtabs and its fields from properties\r\n            $formtabs = $modx->fromJSON($properties[\'formtabs\']);\r\n        }\r\n\r\n        //$tv->setCacheable(false);\r\n        //$outputvalue = $tv->renderOutput($docid);\r\n        \r\n        $tvresource = $modx->getObject(\'modTemplateVarResource\', array(\r\n            \'tmplvarid\' => $tv->get(\'id\'),\r\n            \'contentid\' => $docid,\r\n            ));\r\n\r\n\r\n        $outputvalue = $tvresource->get(\'value\');\r\n        \r\n        /*\r\n        *   get inputTvs \r\n        */\r\n        $inputTvs = array();\r\n        if (is_array($formtabs)) {\r\n\r\n            //multiple different Forms\r\n            // Note: use same field-names and inputTVs in all forms\r\n            $inputTvs = $migx->extractInputTvs($formtabs);\r\n        }\r\n        $migx->source = $tv->getSource($migx->working_context, false);\r\n\r\n        if (empty($outputvalue)) {\r\n            return \'\';\r\n        }\r\n\r\n        $items = $modx->fromJSON($outputvalue);\r\n\r\n\r\n        //is there an active item for the current date?\r\n        $activedate = $modx->getOption(\'activedate\', $scriptProperties, strftime(\'%Y/%m/%d\'));\r\n        //$activedate = $modx->getOption(\'activedate\', $_GET, strftime(\'%Y/%m/%d\'));\r\n        $activewhere = array();\r\n        $activewhere[\'activedate\'] = $activedate;\r\n        $activewhere[\'activated\'] = \'1\';\r\n        $activeitems = $migx->filterItems($activewhere, $items);\r\n\r\n        if (count($activeitems) == 0) {\r\n\r\n            $activeitems = array();\r\n            // where filter\r\n            if (is_array($where) && count($where) > 0) {\r\n                $items = $migx->filterItems($where, $items);\r\n            }\r\n\r\n            $tempitems = array();\r\n            $count = count($items);\r\n            $emptycount = 0;\r\n            $latestdate = $activedate;\r\n            $nextdate = strtotime($latestdate);\r\n            foreach ($items as $item) {\r\n                //empty all dates and active-states which are older than today\r\n                if (!empty($item[\'activedate\']) && $item[\'activedate\'] < $activedate) {\r\n                    $item[\'activated\'] = \'0\';\r\n                    $item[\'activedate\'] = \'\';\r\n                }\r\n                if (empty($item[\'activedate\'])) {\r\n                    $emptycount++;\r\n                }\r\n                if ($item[\'activedate\'] > $latestdate) {\r\n                    $latestdate = $item[\'activedate\'];\r\n                    $nextdate = strtotime($latestdate) + (24 * 60 * 60);\r\n                }\r\n                if ($item[\'activedate\'] == $activedate) {\r\n                    $item[\'activated\'] = \'1\';\r\n                    $activeitems[] = $item;\r\n                }\r\n                $tempitems[] = $item;\r\n            }\r\n\r\n            //echo \'<pre>\' . print_r($tempitems, 1) . \'</pre>\';\r\n\r\n            $items = $tempitems;\r\n\r\n\r\n            //are there more than half of all items with empty activedates\r\n\r\n            if ($emptycount >= $count / 2) {\r\n\r\n                // sort items\r\n                if (is_array($sort) && count($sort) > 0) {\r\n                    $items = $migx->sortDbResult($items, $sort);\r\n                }\r\n                if (count($items) > 0) {\r\n                    //shuffle items\r\n                    if ($randomize) {\r\n                        shuffle($items);\r\n                    }\r\n                }\r\n\r\n                $tempitems = array();\r\n                foreach ($items as $item) {\r\n                    if (empty($item[\'activedate\'])) {\r\n                        $item[\'activedate\'] = strftime(\'%Y/%m/%d\', $nextdate);\r\n                        $nextdate = $nextdate + (24 * 60 * 60);\r\n                        if ($item[\'activedate\'] == $activedate) {\r\n                            $item[\'activated\'] = \'1\';\r\n                            $activeitems[] = $item;\r\n                        }\r\n                    }\r\n\r\n                    $tempitems[] = $item;\r\n                }\r\n\r\n                $items = $tempitems;\r\n            }\r\n\r\n            //$resource = $modx->getObject(\'modResource\', $docid);\r\n            //echo $modx->toJson($items);\r\n            $sort = \'[{\"sortby\":\"activedate\"}]\';\r\n            $items = $migx->sortDbResult($items, $modx->fromJson($sort));\r\n\r\n            //echo \'<pre>\' . print_r($items, 1) . \'</pre>\';\r\n\r\n            $tv->setValue($docid, $modx->toJson($items));\r\n            $tv->save();\r\n\r\n        }\r\n    }\r\n\r\n}\r\n\r\n\r\n$properties = array();\r\nforeach ($scriptProperties as $property => $value) {\r\n    $properties[\'property.\' . $property] = $value;\r\n}\r\n\r\n$output = \'\';\r\n\r\nforeach ($activeitems as $key => $item) {\r\n\r\n    $fields = array();\r\n    foreach ($item as $field => $value) {\r\n        $value = is_array($value) ? implode(\'||\', $value) : $value; //handle arrays (checkboxes, multiselects)\r\n        if ($processTVs && isset($inputTvs[$field])) {\r\n            if ($tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $inputTvs[$field][\'inputTV\']))) {\r\n\r\n            } else {\r\n                $tv = $modx->newObject(\'modTemplateVar\');\r\n                $tv->set(\'type\', $inputTvs[$field][\'inputTVtype\']);\r\n            }\r\n            $inputTV = $inputTvs[$field];\r\n\r\n            $mTypes = $modx->getOption(\'manipulatable_url_tv_output_types\', null, \'image,file\');\r\n            //don\'t manipulate any urls here\r\n            $modx->setOption(\'manipulatable_url_tv_output_types\', \'\');\r\n            $tv->set(\'default_text\', $value);\r\n            $value = $tv->renderOutput($docid);\r\n            //set option back\r\n            $modx->setOption(\'manipulatable_url_tv_output_types\', $mTypes);\r\n            //now manipulate urls\r\n            if ($mediasource = $migx->getFieldSource($inputTV, $tv)) {\r\n                $mTypes = explode(\',\', $mTypes);\r\n                if (!empty($value) && in_array($tv->get(\'type\'), $mTypes)) {\r\n                    //$value = $mediasource->prepareOutputUrl($value);\r\n                    $value = str_replace(\'/./\', \'/\', $mediasource->prepareOutputUrl($value));\r\n                }\r\n            }\r\n\r\n        }\r\n        $fields[$field] = $value;\r\n\r\n    }\r\n\r\n    $rowtpl = $tpl;\r\n    //get changing tpls from field\r\n    if (substr($tpl, 0, 7) == \"@FIELD:\") {\r\n        $tplField = substr($tpl, 7);\r\n        $rowtpl = $fields[$tplField];\r\n    }\r\n\r\n    if (!isset($template[$rowtpl])) {\r\n        if (substr($rowtpl, 0, 6) == \"@FILE:\") {\r\n            $template[$rowtpl] = file_get_contents($modx->config[\'base_path\'] . substr($rowtpl, 6));\r\n        } elseif (substr($rowtpl, 0, 6) == \"@CODE:\") {\r\n            $template[$rowtpl] = substr($tpl, 6);\r\n        } elseif ($chunk = $modx->getObject(\'modChunk\', array(\'name\' => $rowtpl), true)) {\r\n            $template[$rowtpl] = $chunk->getContent();\r\n        } else {\r\n            $template[$rowtpl] = false;\r\n        }\r\n    }\r\n\r\n    $fields = array_merge($fields, $properties);\r\n\r\n    if ($template[$rowtpl]) {\r\n        $chunk = $modx->newObject(\'modChunk\');\r\n        $chunk->setCacheable(false);\r\n        $chunk->setContent($template[$rowtpl]);\r\n        $output .= $chunk->process($fields);\r\n\r\n    } else {\r\n        $output .= \'<pre>\' . print_r($fields, 1) . \'</pre>\';\r\n\r\n    }\r\n\r\n\r\n}\r\n\r\n\r\nif (!empty($toPlaceholder)) {\r\n    $modx->setPlaceholder($toPlaceholder, $output);\r\n    return \'\';\r\n}\r\n\r\nreturn $output;', 0, 'a:0:{}', '', 0, ''),
(11, 0, 0, 'filterbytag', '', 0, 1, 0, 'if (!is_array($subject)) {\r\n    $subject = explode(\',\',str_replace(array(\'||\',\' \'),array(\',\',\'\'),$subject));\r\n}\r\n\r\nreturn (in_array($operand,$subject));', 0, 'a:0:{}', '', 0, ''),
(12, 0, 0, 'migxObjectMediaPath', '', 0, 1, 0, '$pathTpl = $modx->getOption(\'pathTpl\', $scriptProperties, \'\');\r\n$objectid = $modx->getOption(\'objectid\', $scriptProperties, \'\');\r\n$createfolder = $modx->getOption(\'createFolder\', $scriptProperties, \'1\');\r\n$path = \'\';\r\n$createpath = false;\r\nif (empty($objectid) && $modx->getPlaceholder(\'objectid\')) {\r\n    // placeholder was set by some script on frontend for example\r\n    $objectid = $modx->getPlaceholder(\'objectid\');\r\n}\r\nif (empty($objectid) && isset($_REQUEST[\'object_id\'])) {\r\n    $objectid = $_REQUEST[\'object_id\'];\r\n}\r\n\r\n\r\n\r\nif (empty($objectid)) {\r\n\r\n    //set Session - var in fields.php - processor\r\n    if (isset($_SESSION[\'migxWorkingObjectid\'])) {\r\n        $objectid = $_SESSION[\'migxWorkingObjectid\'];\r\n        $createpath = !empty($createfolder);\r\n    }\r\n\r\n}\r\n\r\n\r\n$path = str_replace(\'{id}\', $objectid, $pathTpl);\r\n\r\n$fullpath = $modx->getOption(\'base_path\') . $path;\r\n\r\nif ($createpath && !file_exists($fullpath)) {\r\n        $permissions = octdec(\'0\' . (int)($modx->getOption(\'new_folder_permissions\', null, \'755\', true)));\r\n        if (!@mkdir($fullpath, $permissions, true)) {\r\n            $modx->log(MODX_LOG_LEVEL_ERROR, sprintf(\'[migxResourceMediaPath]: could not create directory %s).\', $fullpath));\r\n        }\r\n        else{\r\n            chmod($fullpath, $permissions); \r\n        }\r\n}\r\n\r\nreturn $path;', 0, 'a:0:{}', '', 0, ''),
(13, 0, 0, 'exportMIGX2db', '', 0, 1, 0, '/**\r\n * exportMIGX2db\r\n *\r\n * Copyright 2014 by Bruno Perner <b.perner@gmx.de>\r\n * \r\n * Sponsored by Simon Wurster <info@wurster-medien.de>\r\n *\r\n * exportMIGX2db is free software; you can redistribute it and/or modify it\r\n * under the terms of the GNU General Public License as published by the Free\r\n * Software Foundation; either version 2 of the License, or (at your option) any\r\n * later version.\r\n *\r\n * exportMIGX2db is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * exportMIGX2db; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package migx\r\n */\r\n/**\r\n * exportMIGX2db\r\n *\r\n * export Items from outputvalue of TV with custom-TV-input-type MIGX or from other JSON-string to db-table \r\n *\r\n * @version 1.0\r\n * @author Bruno Perner <b.perner@gmx.de>\r\n * @copyright Copyright &copy; 2014\r\n * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License\r\n * version 2 or (at your option) any later version.\r\n * @package migx\r\n */\r\n\r\n/*\r\n[[!exportMIGX2db? \r\n&tvname=`references` \r\n&resources=`25` \r\n&packageName=`projekte`\r\n&classname=`Projekt` \r\n&migx_id_field=`migx_id` \r\n&renamed_fields=`{\"Firmen-URL\":\"Firmen_url\",\"Projekt-URL\":\"Projekt_URL\",\"main-image\":\"main_image\"}`\r\n]]\r\n*/\r\n\r\n\r\n$tvname = $modx->getOption(\'tvname\', $scriptProperties, \'\');\r\n$resources = $modx->getOption(\'resources\', $scriptProperties, (isset($modx->resource) ? $modx->resource->get(\'id\') : \'\'));\r\n$resources = explode(\',\', $resources);\r\n$prefix = isset($scriptProperties[\'prefix\']) ? $scriptProperties[\'prefix\'] : null;\r\n$packageName = $modx->getOption(\'packageName\', $scriptProperties, \'\');\r\n$classname = $modx->getOption(\'classname\', $scriptProperties, \'\');\r\n$value = $modx->getOption(\'value\', $scriptProperties, \'\');\r\n$migx_id_field = $modx->getOption(\'migx_id_field\', $scriptProperties, \'\');\r\n$pos_field = $modx->getOption(\'pos_field\', $scriptProperties, \'\');\r\n$renamed_fields = $modx->getOption(\'renamed_fields\', $scriptProperties, \'\');\r\n\r\n$packagepath = $modx->getOption(\'core_path\') . \'components/\' . $packageName .\r\n    \'/\';\r\n$modelpath = $packagepath . \'model/\';\r\n\r\n$modx->addPackage($packageName, $modelpath, $prefix);\r\n$added = 0;\r\n$modified = 0;\r\n\r\nforeach ($resources as $docid) {\r\n    \r\n    $outputvalue = \'\';\r\n    if (count($resources)==1){\r\n        $outputvalue = $value;    \r\n    }\r\n    \r\n    if (!empty($tvname)) {\r\n        if ($tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $tvname))) {\r\n\r\n            $outputvalue = empty($outputvalue) ? $tv->renderOutput($docid) : $outputvalue;\r\n        }\r\n    }\r\n\r\n    if (!empty($outputvalue)) {\r\n        $renamed = !empty($renamed_fields) ? $modx->fromJson($renamed_fields) : array();\r\n\r\n        $items = $modx->fromJSON($outputvalue);\r\n        $pos = 1;\r\n        $searchfields = array();\r\n        if (is_array($items)) {\r\n            foreach ($items as $fields) {\r\n                $search = array();\r\n                if (!empty($migx_id_field)) {\r\n                    $search[$migx_id_field] = $fields[\'MIGX_id\'];\r\n                }\r\n                if (!empty($resource_id_field)) {\r\n                    $search[$resource_id_field] = $docid;\r\n                }\r\n                if (!empty($migx_id_field) && $object = $modx->getObject($classname, $search)) {\r\n                    $mode = \'mod\';\r\n                } else {\r\n                    $object = $modx->newObject($classname);\r\n                    $object->fromArray($search);\r\n                    $mode = \'add\';\r\n                }\r\n                foreach ($fields as $field => $value) {\r\n                    $fieldname = array_key_exists($field, $renamed) ? $renamed[$field] : $field;\r\n                    $object->set($fieldname, $value);\r\n                }\r\n                if (!empty($pos_field)) {\r\n                    $object->set($pos_field,$pos) ;\r\n                }                \r\n                if ($object->save()) {\r\n                    if ($mode == \'add\') {\r\n                        $added++;\r\n                    } else {\r\n                        $modified++;\r\n                    }\r\n                }\r\n                $pos++;\r\n            }\r\n            \r\n        }\r\n    }\r\n}\r\n\r\n\r\nreturn $added . \' rows added to db, \' . $modified . \' existing rows actualized\';', 0, 'a:0:{}', '', 0, ''),
(14, 0, 0, 'preparedatewhere', '', 0, 1, 0, '$name = $modx->getOption(\'name\', $scriptProperties, \'\');\r\n$date = $modx->getOption($name . \'_date\', $_REQUEST, \'\');\r\n$dir = str_replace(\'T\', \' \', $modx->getOption($name . \'_dir\', $_REQUEST, \'\'));\r\n\r\nif (!empty($date) && !empty($dir) && $dir != \'all\') {\r\n    switch ($dir) {\r\n        case \'=\':\r\n            $where = array(\r\n            \'enddate:>=\' => strftime(\'%Y-%m-%d 00:00:00\',strtotime($date)),\r\n            \'startdate:<=\' => strftime(\'%Y-%m-%d 23:59:59\',strtotime($date))\r\n            );\r\n            break;\r\n        case \'>=\':\r\n            $where = array(\r\n            \'enddate:>=\' => strftime(\'%Y-%m-%d 00:00:00\',strtotime($date))\r\n            );\r\n            break;\r\n        case \'<=\':\r\n            $where = array(\r\n            \'startdate:<=\' => strftime(\'%Y-%m-%d 23:59:59\',strtotime($date))\r\n            );            \r\n            break;\r\n\r\n    }\r\n\r\n    return $modx->toJson($where);\r\n}', 0, 'a:0:{}', '', 0, ''),
(15, 0, 0, 'migxJsonToPlaceholders', '', 0, 1, 0, '$value = $modx->getOption(\'value\',$scriptProperties,\'\');\r\n$prefix = $modx->getOption(\'prefix\',$scriptProperties,\'\');\r\n\r\n//$modx->setPlaceholders($modx->fromJson($value),$prefix,\'\',true);\r\n\r\n$values = json_decode($value, true);\r\n\r\n$it = new RecursiveIteratorIterator(new RecursiveArrayIterator($values));\r\n\r\nif (is_array($values)){\r\n    foreach ($it as $key => $value){\r\n        $value = $value == null ? \'\' : $value;\r\n        $modx->setPlaceholder($prefix . $key, $value);\r\n    }\r\n}', 0, 'a:0:{}', '', 0, ''),
(16, 0, 0, 'migxGetCollectionTree', '', 0, 1, 0, '/**\r\n * migxGetCollectionTree\r\n *\r\n * Copyright 2014 by Bruno Perner <b.perner@gmx.de>\r\n *\r\n * migxGetCollectionTree is free software; you can redistribute it and/or modify it\r\n * under the terms of the GNU General Public License as published by the Free\r\n * Software Foundation; either version 2 of the License, or (at your option) any\r\n * later version.\r\n *\r\n * migxGetCollectionTree is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * migxGetCollectionTree; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package migx\r\n */\r\n/**\r\n * migxGetCollectionTree\r\n *\r\n *          display nested items from different objects. The tree-schema is defined by a json-property. \r\n *\r\n * @version 1.0.0\r\n * @author Bruno Perner <b.perner@gmx.de>\r\n * @copyright Copyright &copy; 2014\r\n * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License\r\n * version 2 or (at your option) any later version.\r\n * @package migx\r\n */\r\n\r\n$treeSchema = $modx->getOption(\'treeSchema\', $scriptProperties, \'\');\r\n$treeSchema = $modx->fromJson($treeSchema);\r\n\r\n$scriptProperties[\'current\'] = $modx->getOption(\'current\', $scriptProperties, \'\');\r\n$scriptProperties[\'currentClassname\'] = $modx->getOption(\'currentClassname\', $scriptProperties, \'\');\r\n$scriptProperties[\'currentKeyField\'] = $modx->getOption(\'currentKeyField\', $scriptProperties, \'id\');\r\n$return = $modx->getOption(\'return\', $scriptProperties, \'parsed\'); //parsed,json,arrayprint\r\n\r\n/*\r\nExamples:\r\n\r\nGet Resource-Tree, 4 levels deep\r\n\r\n[[!migxGetCollectionTree?\r\n&current=`57`\r\n&currentClassname=`modResource`\r\n&treeSchema=`\r\n{\r\n\"classname\": \"modResource\",\r\n\"debug\": \"1\",\r\n\"tpl\": \"mgctResourceTree\",\r\n\"wrapperTpl\": \"@CODE:<ul>[[+output]]</ul>\",\r\n\"selectfields\": \"id,pagetitle\",\r\n\"where\": {\r\n\"parent\": \"0\",\r\n\"published\": \"1\",\r\n\"deleted\": \"0\"\r\n},\r\n\"_branches\": [{\r\n\"alias\": \"children\",\r\n\"classname\": \"modResource\",\r\n\"local\": \"parent\",\r\n\"foreign\": \"id\",\r\n\"tpl\": \"mgctResourceTree\",\r\n\"debug\": \"1\",\r\n\"selectfields\": \"id,pagetitle,parent\",\r\n\"_branches\": [{\r\n\"alias\": \"children\",\r\n\"classname\": \"modResource\",\r\n\"local\": \"parent\",\r\n\"foreign\": \"id\",\r\n\"tpl\": \"mgctResourceTree\",\r\n\"debug\": \"1\",\r\n\"selectfields\": \"id,pagetitle,parent\",\r\n\"where\": {\r\n\"published\": \"1\",\r\n\"deleted\": \"0\"\r\n},\r\n\"_branches\": [{\r\n\"alias\": \"children\",\r\n\"classname\": \"modResource\",\r\n\"local\": \"parent\",\r\n\"foreign\": \"id\",\r\n\"tpl\": \"mgctResourceTree\",\r\n\"debug\": \"1\",\r\n\"selectfields\": \"id,pagetitle,parent\",\r\n\"where\": {\r\n\"published\": \"1\",\r\n\"deleted\": \"0\"\r\n}\r\n}]\r\n}]\r\n}]\r\n}\r\n`]]\r\n\r\nthe chunk mgctResourceTree:\r\n<li class=\"[[+_activelabel]] [[+_currentlabel]]\" ><a href=\"[[~[[+id]]]]\">[[+pagetitle]]([[+id]])</a></li>\r\n[[+innercounts.children:gt=`0`:then=`\r\n<ul>[[+innerrows.children]]</ul>\r\n`:else=``]]\r\n\r\nget all Templates and its Resources:\r\n\r\n[[!migxGetCollectionTree?\r\n&treeSchema=`\r\n{\r\n\"classname\": \"modTemplate\",\r\n\"debug\": \"1\",\r\n\"tpl\": \"@CODE:<h3>[[+templatename]]</h3><ul>[[+innerrows.resource]]</ul>\",\r\n\"selectfields\": \"id,templatename\",\r\n\"_branches\": [{\r\n\"alias\": \"resource\",\r\n\"classname\": \"modResource\",\r\n\"local\": \"template\",\r\n\"foreign\": \"id\",\r\n\"tpl\": \"@CODE:<li>[[+pagetitle]]([[+id]])</li>\",\r\n\"debug\": \"1\",\r\n\"selectfields\": \"id,pagetitle,template\"\r\n}]\r\n}\r\n`]]\r\n*/\r\n\r\nif (!class_exists(\'MigxGetCollectionTree\')) {\r\n    class MigxGetCollectionTree\r\n    {\r\n        function __construct(modX & $modx, array $config = array())\r\n        {\r\n            $this->modx = &$modx;\r\n            $this->config = $config;\r\n        }\r\n\r\n        function getBranch($branch, $foreigns = array(), $level = 1)\r\n        {\r\n\r\n            $rows = array();\r\n\r\n            if (count($foreigns) > 0) {\r\n                $modx = &$this->modx;\r\n\r\n                $local = $modx->getOption(\'local\', $branch, \'\');\r\n                $where = $modx->getOption(\'where\', $branch, array());\r\n                $where = !empty($where) && !is_array($where) ? $modx->fromJSON($where) : $where;\r\n                $where[] = array($local . \':IN\' => $foreigns);\r\n\r\n                $branch[\'where\'] = $modx->toJson($where);\r\n\r\n                $level++;\r\n                /*\r\n                if ($levelFromCurrent > 0){\r\n                $levelFromCurrent++;    \r\n                }\r\n                */\r\n\r\n                $rows = $this->getRows($branch, $level);\r\n            }\r\n\r\n            return $rows;\r\n        }\r\n\r\n        function getRows($scriptProperties, $level)\r\n        {\r\n            $migx = &$this->migx;\r\n            $modx = &$this->modx;\r\n\r\n            $current = $modx->getOption(\'current\', $this->config, \'\');\r\n            $currentKeyField = $modx->getOption(\'currentKeyField\', $this->config, \'id\');\r\n            $currentlabel = $modx->getOption(\'currentlabel\', $this->config, \'current\');\r\n            $classname = $modx->getOption(\'classname\', $scriptProperties, \'\');\r\n			$sortResult = $modx->getOption(\'sortResult\', $scriptProperties, \'\');\r\n            $currentClassname = !empty($this->config[\'currentClassname\']) ? $this->config[\'currentClassname\'] : $classname;\r\n\r\n            $activelabel = $modx->getOption(\'activelabel\', $this->config, \'active\');\r\n            $return = $modx->getOption(\'return\', $this->config, \'parsed\');\r\n\r\n            $xpdo = $migx->getXpdoInstanceAndAddPackage($scriptProperties);\r\n            $c = $migx->prepareQuery($xpdo, $scriptProperties);\r\n            $rows = $migx->getCollection($c);\r\n\r\n            $branches = $modx->getOption(\'_branches\', $scriptProperties, array());\r\n\r\n            $collectedSubrows = array();\r\n            foreach ($branches as $branch) {\r\n                $foreign = $modx->getOption(\'foreign\', $branch, \'\');\r\n                $local = $modx->getOption(\'local\', $branch, \'\');\r\n                $alias = $modx->getOption(\'alias\', $branch, \'\');\r\n                //$activeonly = $modx->getOption(\'activeonly\', $branch, \'\');\r\n                $foreigns = array();\r\n                foreach ($rows as $row) {\r\n                    $foreigns[] = $row[$foreign];\r\n                }\r\n\r\n                $subrows = $this->getBranch($branch, $foreigns, $level);\r\n                foreach ($subrows as $subrow) {\r\n\r\n                    $collectedSubrows[$subrow[$local]][] = $subrow;\r\n                    $subrow[\'_active\'] = $modx->getOption(\'_active\', $subrow, \'0\');\r\n                    /*\r\n                    if (!empty($activeonly) && $subrow[\'_active\'] != \'1\') {\r\n                    $output = \'\';\r\n                    } else {\r\n                    $collectedSubrows[$subrow[$local]][] = $subrow;\r\n                    }\r\n                    */\r\n                    if ($subrow[\'_active\'] == \'1\') {\r\n                        //echo \'active subrow:<pre>\' . print_r($subrow,1) . \'</pre>\';\r\n                        $activesubrow[$subrow[$local]] = true;\r\n                    }\r\n                    if ($subrow[\'_current\'] == \'1\') {\r\n                        //echo \'active subrow:<pre>\' . print_r($subrow,1) . \'</pre>\';\r\n                        $currentsubrow[$subrow[$local]] = true;\r\n                    }\r\n\r\n\r\n                }\r\n                //insert subrows\r\n                $temprows = $rows;\r\n                $rows = array();\r\n                foreach ($temprows as $row) {\r\n                    if (isset($collectedSubrows[$row[$foreign]])) {\r\n                        $row[\'_active\'] = \'0\';\r\n                        $row[\'_currentparent\'] = \'0\';\r\n                        if (isset($activesubrow[$row[$foreign]]) && $activesubrow[$row[$foreign]]) {\r\n                            $row[\'_active\'] = \'1\';\r\n                            //echo \'active row:<pre>\' . print_r($row,1) . \'</pre>\';\r\n                        }\r\n                        if (isset($currentsubrow[$row[$foreign]]) && $currentsubrow[$row[$foreign]]) {\r\n                            $row[\'_currentparent\'] = \'1\';\r\n                            //echo \'active row:<pre>\' . print_r($row,1) . \'</pre>\';\r\n                        }\r\n\r\n                        //render innerrows\r\n                        //$output = $migx->renderOutput($collectedSubrows[$row[$foreign]],$scriptProperties);\r\n                        //$output = $collectedSubrows[$row[$foreign]];\r\n\r\n                        $row[\'innercounts.\' . $alias] = count($collectedSubrows[$row[$foreign]]);\r\n                        $row[\'_scriptProperties\'][$alias] = $branch;\r\n                        /*\r\n                        switch ($return) {\r\n                        case \'parsed\':\r\n                        $output = $migx->renderOutput($collectedSubrows[$row[$foreign]], $branch);\r\n                        //$subbranches = $modx->getOption(\'_branches\', $branch, array());\r\n                        //if there are any placeholders left with the same alias from subbranch, remove them\r\n                        $output = str_replace(\'[[+innerrows.\' . $alias . \']]\', \'\', $output);\r\n                        break;\r\n                        case \'json\':\r\n                        case \'arrayprint\':\r\n                        $output = $collectedSubrows[$row[$foreign]];\r\n                        break;\r\n                        }\r\n                        */\r\n                        $output = $collectedSubrows[$row[$foreign]];\r\n\r\n                        $row[\'innerrows.\' . $alias] = $output;\r\n\r\n                    }\r\n                    $rows[] = $row;\r\n                }\r\n\r\n            }\r\n\r\n            $temprows = $rows;\r\n            $rows = array();\r\n            foreach ($temprows as $row) {\r\n                //add additional placeholders\r\n                $row[\'_level\'] = $level;\r\n                $row[\'_active\'] = $modx->getOption(\'_active\', $row, \'0\');\r\n                if ($currentClassname == $classname && $row[$currentKeyField] == $current) {\r\n                    $row[\'_current\'] = \'1\';\r\n                    $row[\'_currentlabel\'] = $currentlabel;\r\n                    $row[\'_active\'] = \'1\';\r\n                } else {\r\n                    $row[\'_current\'] = \'0\';\r\n                    $row[\'_currentlabel\'] = \'\';\r\n                }\r\n                if ($row[\'_active\'] == \'1\') {\r\n                    $row[\'_activelabel\'] = $activelabel;\r\n                } else {\r\n                    $row[\'_activelabel\'] = \'\';\r\n                }\r\n                $rows[] = $row;\r\n            }\r\n\r\n            if (!empty($sortResult) && is_array($sortResult)){\r\n                $rows = $migx->sortDbResult($rows, $sortResult);\r\n			}\r\n\r\n            return $rows;\r\n        }\r\n\r\n        function renderRow($row, $levelFromCurrent = 0)\r\n        {\r\n            $migx = &$this->migx;\r\n            $modx = &$this->modx;\r\n            $return = $modx->getOption(\'return\', $this->config, \'parsed\');\r\n            $branchProperties = $modx->getOption(\'_scriptProperties\', $row, array());\r\n            $current = $modx->getOption(\'_current\', $row, \'0\');\r\n            $currentparent = $modx->getOption(\'_currentparent\', $row, \'0\');\r\n            $levelFromCurrent = $current == \'1\' ? 1 : $levelFromCurrent;\r\n            $row[\'_levelFromCurrent\'] = $levelFromCurrent;\r\n            foreach ($branchProperties as $alias => $properties) {\r\n                $innerrows = $modx->getOption(\'innerrows.\' . $alias, $row, array());\r\n                $subrows = $this->renderRows($innerrows, $properties, $levelFromCurrent, $currentparent);\r\n                if ($return == \'parsed\') {\r\n                    $subrows = $migx->renderOutput($subrows, $properties);\r\n                }\r\n                $row[\'innerrows.\' . $alias] = $subrows;\r\n            }\r\n\r\n            return $row;\r\n        }\r\n\r\n        function renderRows($rows, $scriptProperties, $levelFromCurrent = 0, $siblingOfCurrent = \'0\')\r\n        {\r\n\r\n            $modx = &$this->modx;\r\n            $temprows = $rows;\r\n            $rows = array();\r\n            if ($levelFromCurrent > 0) {\r\n                $levelFromCurrent++;\r\n            }\r\n            foreach ($temprows as $row) {\r\n                $row[\'_siblingOfCurrent\'] = $siblingOfCurrent;\r\n                $row = $this->renderRow($row, $levelFromCurrent);\r\n                $rows[] = $row;\r\n            }\r\n            return $rows;\r\n        }\r\n    }\r\n}\r\n\r\n$instance = new MigxGetCollectionTree($modx, $scriptProperties);\r\n\r\nif (is_array($treeSchema)) {\r\n    $scriptProperties = $treeSchema;\r\n\r\n    $migx = $modx->getService(\'migx\', \'Migx\', $modx->getOption(\'migx.core_path\', null, $modx->getOption(\'core_path\') . \'components/migx/\') . \'model/migx/\', $scriptProperties);\r\n    if (!($migx instanceof Migx))\r\n        return \'\';\r\n\r\n    $defaultcontext = \'web\';\r\n    $migx->working_context = isset($modx->resource) ? $modx->resource->get(\'context_key\') : $defaultcontext;\r\n    $instance->migx = &$migx;\r\n\r\n    $level = 1;\r\n    $scriptProperties[\'alias\'] = \'row\';\r\n    $rows = $instance->getRows($scriptProperties, $level);\r\n\r\n    $row = array();\r\n    $row[\'innercounts.row\'] = count($rows);\r\n    $row[\'innerrows.row\'] = $rows;\r\n    $row[\'_scriptProperties\'][\'row\'] = $scriptProperties;\r\n\r\n    $rows = $instance->renderRow($row);\r\n\r\n    $output = \'\';\r\n    switch ($return) {\r\n        case \'parsed\':\r\n            $output = $modx->getOption(\'innerrows.row\', $rows, \'\');\r\n            break;\r\n        case \'json\':\r\n            $output = $modx->toJson($rows);\r\n            break;\r\n        case \'arrayprint\':\r\n            $output = \'<pre>\' . print_r($rows, 1) . \'</pre>\';\r\n            break;\r\n    }\r\n\r\n    return $output;\r\n\r\n}', 0, 'a:0:{}', '', 0, ''),
(17, 0, 0, 'migxIsNewObject', '', 0, 1, 0, 'if (isset($_REQUEST[\'object_id\']) && $_REQUEST[\'object_id\']==\'new\'){\r\n    return 1;\r\n}', 0, 'a:0:{}', '', 0, ''),
(18, 0, 0, 'migx_example_validate', '', 0, 1, 0, '$properties = &$modx->getOption(\'scriptProperties\', $scriptProperties, array());\r\n$object = &$modx->getOption(\'object\', $scriptProperties, null);\r\n$postvalues = &$modx->getOption(\'postvalues\', $scriptProperties, array());\r\n$form_field = $modx->getOption(\'form_field\', $scriptProperties, array());\r\n$value = $modx->getOption(\'value\', $scriptProperties, \'\');\r\n$validation_type = $modx->getOption(\'validation_type\', $scriptProperties, \'\');\r\n$result = \'\';\r\nswitch ($validation_type) {\r\n    case \'gt25\':\r\n        if ((int) $value > 25) {\r\n        } else {\r\n            $error_message = $validation_type; // may be custom validation message\r\n            $error[\'caption\'] = $form_field;\r\n            $error[\'validation_type\'] = $error_message;\r\n            $result[\'error\'] = $error;\r\n            $result = $modx->toJson($result);\r\n        }\r\n        break;\r\n}\r\nreturn $result;', 0, 'a:0:{}', '', 0, ''),
(19, 0, 0, 'migxHookAftercollectmigxitems', '', 0, 1, 0, '$configs = $modx->getOption(\'configs\', $_REQUEST, \'\');\r\n\r\n$rows = $modx->getOption(\'rows\', $scriptProperties, array());\r\n$newrows = array();\r\n\r\n\r\nif (is_array($rows)) {\r\n    $max_id = 0;\r\n    $dbfields = array();\r\n    $existing_dbfields = array();\r\n    foreach ($rows as $key => $row) {\r\n        if (isset($row[\'MIGX_id\']) && $row[\'MIGX_id\'] > $max_id) {\r\n            $max_id = $row[\'MIGX_id\'];\r\n        }\r\n        if (isset($row[\'selected_dbfields\']) && isset($row[\'existing_dbfields\'])) {\r\n            $dbfields = is_array($row[\'selected_dbfields\']) ? $row[\'selected_dbfields\'] : array($row[\'selected_dbfields\']);\r\n            \r\n            $existing_dbfields = explode(\'||\', $row[\'existing_dbfields\']);\r\n            //echo \'<pre>\' . print_r($existing_dbfields,1) . \'</pre>\';die();\r\n\r\n        } else {\r\n            $newrows[] = $row;\r\n        }\r\n\r\n    }\r\n\r\n    foreach ($dbfields as $dbfield) {\r\n        if (!empty($dbfield) && !in_array($dbfield, $existing_dbfields)) {\r\n            $max_id++;\r\n            $newrow = array();\r\n            $newrow[\'MIGX_id\'] = $max_id;\r\n\r\n            switch ($configs) {\r\n                case \'migxformtabfields\':\r\n                    $newrow[\'field\'] = $dbfield;\r\n                    $newrow[\'caption\'] = $dbfield;\r\n                    break;\r\n                case \'migxcolumns\':\r\n                    $newrow[\'dataIndex\'] = $dbfield;\r\n                    $newrow[\'header\'] = $dbfield;\r\n                    break;                    \r\n            }\r\n\r\n\r\n            $newrows[] = $newrow;\r\n        }\r\n    }\r\n\r\n\r\n}\r\n\r\n\r\nreturn json_encode($newrows);', 0, 'a:0:{}', '', 0, ''),
(20, 0, 0, 'migxAutoPublish', '', 0, 1, 0, '$classnames = explode(\',\', $modx->getOption(\'classnames\',$scriptProperties,\'\'));\r\n$packageName = $modx->getOption(\'packageName\',$scriptProperties,\'\');\r\n\r\nswitch ($mode) {\r\n    case \'datetime\' :\r\n        $timeNow = strftime(\'%Y-%m-%d %H:%M:%S\');\r\n        break;\r\n    case \'unixtime\' :\r\n        $timeNow = time();\r\n        break;\r\n    default :\r\n        $timeNow = strftime(\'%Y-%m-%d %H:%M:%S\');\r\n        break;\r\n}\r\n\r\n$modx->addPackage($packageName, $modx->getOption(\'core_path\') . \'components/\' . $packageName . \'/model/\');\r\n\r\nforeach ($classnames as $classname) {\r\n    if (!empty($classname)) {\r\n        $tblResource = $modx->getTableName($classname);\r\n        if (!$result = $modx->exec(\"UPDATE {$tblResource} SET published=1,publishedon=pub_date,pub_date=null WHERE pub_date < \'{$timeNow}\' AND pub_date > 0 AND published=0\")) {\r\n            $modx->log(modX::LOG_LEVEL_ERROR, \'Error while refreshing resource publishing data: \' . print_r($modx->errorInfo(), true));\r\n        }\r\n        if (!$result = $modx->exec(\"UPDATE $tblResource SET published=0,unpub_date=null WHERE unpub_date < \'{$timeNow}\' AND unpub_date IS NOT NULL AND unpub_date > 0 AND published=1\")) {\r\n            $modx->log(modX::LOG_LEVEL_ERROR, \'Error while refreshing resource unpublishing data: \' . print_r($modx->errorInfo(), true));\r\n        }\r\n    }\r\n\r\n}\r\n$modx->cacheManager->refresh();', 0, 'a:0:{}', '', 0, ''),
(21, 0, 0, 'migxGetObject', '', 0, 1, 0, '/*\r\ngetXpdoInstanceAndAddPackage - properties\r\n\r\n$prefix\r\n$usecustomprefix\r\n$packageName\r\n\r\n\r\nprepareQuery - properties:\r\n\r\n$limit\r\n$offset\r\n$totalVar\r\n$where\r\n$queries\r\n$sortConfig\r\n$groupby\r\n$joins\r\n$selectfields\r\n$classname\r\n$debug\r\n\r\nrenderOutput - properties:\r\n\r\n$tpl\r\n$wrapperTpl\r\n$toSeparatePlaceholders\r\n$toPlaceholder\r\n$outputSeparator\r\n$placeholdersKeyField\r\n$toJsonPlaceholder\r\n$jsonVarKey\r\n$addfields\r\n\r\nmigxGetObject - properties\r\n\r\n$id\r\n$toPlaceholders - if not empty, output to placeholders with specified prefix or print the array, if \'print_r\' is the property-value\r\n\r\n*/\r\n\r\n$id = $modx->getOption(\'id\',$scriptProperties,\'\');\r\n$scriptProperties[\'limit\'] = 1;\r\n\r\n$migx = $modx->getService(\'migx\', \'Migx\', $modx->getOption(\'migx.core_path\', null, $modx->getOption(\'core_path\') . \'components/migx/\') . \'model/migx/\', $scriptProperties);\r\nif (!($migx instanceof Migx))\r\n    return \'\';\r\n//$modx->migx = &$migx;\r\n\r\n$xpdo = $migx->getXpdoInstanceAndAddPackage($scriptProperties);\r\n\r\n$defaultcontext = \'web\';\r\n$migx->working_context = isset($modx->resource) ? $modx->resource->get(\'context_key\') : $defaultcontext;\r\n\r\n$c = $migx->prepareQuery($xpdo,$scriptProperties);\r\nif (!empty($id)){\r\n    $c->where(array(\'id\'=>$id));\r\n	$c->prepare();\r\n}	\r\n$rows = $migx->getCollection($c);\r\n\r\n$output = $migx->renderOutput($rows,$scriptProperties);\r\n\r\nreturn $output;', 0, 'a:0:{}', '', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_templates`
--

CREATE TABLE `modx_site_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `templatename` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `template_type` int(11) NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT '',
  `preview_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_templates`
--

INSERT INTO `modx_site_templates` (`id`, `source`, `property_preprocess`, `templatename`, `description`, `editor_type`, `category`, `icon`, `template_type`, `content`, `locked`, `properties`, `static`, `static_file`, `preview_file`) VALUES
(1, 0, 0, 'Шаблон главной', '', 0, 0, '', 0, '<!doctype html>\n<html lang=\"en\">\n<head>\n    [[$head]]\n</head>\n<body>\n    [[$header]]\n    <main>\n        [[!getImageList?\n            &tvname=`sections`\n            &tpl=`sections`\n        ]]\n    </main>\n    [[$footer]]\n    <script src=\"/assets/js/master.js\"></script>\n</body>\n</html>', 0, 'a:0:{}', 0, '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_tmplvars`
--

CREATE TABLE `modx_site_tmplvars` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `caption` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `elements` text,
  `rank` int(11) NOT NULL DEFAULT '0',
  `display` varchar(20) NOT NULL DEFAULT '',
  `default_text` mediumtext,
  `properties` text,
  `input_properties` text,
  `output_properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_tmplvars`
--

INSERT INTO `modx_site_tmplvars` (`id`, `source`, `property_preprocess`, `type`, `name`, `caption`, `description`, `editor_type`, `category`, `locked`, `elements`, `rank`, `display`, `default_text`, `properties`, `input_properties`, `output_properties`, `static`, `static_file`) VALUES
(1, 1, 0, 'migx', 'sections', 'Секции', '', 0, 0, 0, '', 0, 'default', '', 'a:0:{}', 'a:7:{s:7:\"configs\";s:14:\"sectionContent\";s:8:\"formtabs\";s:0:\"\";s:7:\"columns\";s:0:\"\";s:7:\"btntext\";s:0:\"\";s:10:\"previewurl\";s:0:\"\";s:10:\"jsonvarkey\";s:0:\"\";s:19:\"autoResourceFolders\";s:5:\"false\";}', 'a:0:{}', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_tmplvar_access`
--

CREATE TABLE `modx_site_tmplvar_access` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `documentgroup` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_tmplvar_contentvalues`
--

CREATE TABLE `modx_site_tmplvar_contentvalues` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `contentid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `value` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_tmplvar_contentvalues`
--

INSERT INTO `modx_site_tmplvar_contentvalues` (`id`, `tmplvarid`, `contentid`, `value`) VALUES
(1, 1, 1, '[{\"MIGX_id\":\"1\",\"header\":\"29\\/09\\/2025\",\"intro\":\"\\u0424\\u043e\\u0440\\u0443\\u043c \\u043f\\u0440\\u043e \\u0446\\u0438\\u0444\\u0440\\u043e\\u0432\\u044b\\u0435 \\u0442\\u0435\\u0445\\u043d\\u043e\\u043b\\u043e\\u0433\\u0438\\u0438 \\u043d\\u0430 \\u0441\\u043b\\u0443\\u0436\\u0431\\u0435 \\u043e\\u0431\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0438 \\u043f\\u0440\\u043e \\u0438\\u0437\\u043c\\u0435\\u0440\\u0438\\u043c\\u044b\\u0439 \\u0441\\u043e\\u0446\\u0438\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439 \\u044d\\u0444\\u0444\\u0435\\u043a\\u0442, \\u0434\\u043e\\u0441\\u0442\\u0438\\u0433\\u0430\\u0435\\u043c\\u044b\\u0439 \\u0447\\u0435\\u0440\\u0435\\u0437 \\u0432\\u0437\\u0430\\u0438\\u043c\\u043e\\u0432\\u044b\\u0433\\u043e\\u0434\\u043d\\u044b\\u0435 \\u043a\\u043e\\u043b\\u043b\\u0430\\u0431\\u043e\\u0440\\u0430\\u0446\\u0438\\u0438\",\"points\":\"\",\"anchor\":\"hero\",\"chunk\":\"hero\",\"menutitle\":\"\\u0413\\u0435\\u0440\\u043e\\u0439\",\"show-in-navi\":\"\"},{\"MIGX_id\":\"2\",\"anchor\":\"about\",\"chunk\":\"about\",\"header\":\"Smart Social 2.0 \\u2014 \\u044d\\u0442\\u043e\\u2026\",\"menutitle\":\"\\u041e \\u0444\\u043e\\u0440\\u0443\\u043c\\u0435\",\"show-in-navi\":\"1\",\"intro\":\"\",\"points\":\"[{\\\"MIGX_id\\\":\\\"1\\\",\\\"header\\\":\\\"\\\\u041f\\\\u0435\\\\u0440\\\\u0432\\\\u044b\\\\u0439\\\",\\\"intro\\\":\\\"\\\\u0432 \\\\u0420\\\\u043e\\\\u0441\\\\u0441\\\\u0438\\\\u0438 \\\\u043e\\\\u0431\\\\u0440\\\\u0430\\\\u0437\\\\u043e\\\\u0432\\\\u0430\\\\u0442\\\\u0435\\\\u043b\\\\u044c\\\\u043d\\\\u043e-\\\\u0434\\\\u0435\\\\u043b\\\\u043e\\\\u0432\\\\u043e\\\\u0439 \\\\u0444\\\\u043e\\\\u0440\\\\u0443\\\\u043c \\\\u043f\\\\u0440\\\\u043e IT \\\\u0438 \\\\u0443\\\\u0441\\\\u0442\\\\u043e\\\\u0439\\\\u0447\\\\u0438\\\\u0432\\\\u043e\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0432\\\\u0438\\\\u0442\\\\u0438\\\\u0435. \\\\u0417\\\\u0434\\\\u0435\\\\u0441\\\\u044c \\\\u041a\\\\u0421\\\\u041e \\\\u043d\\\\u0435\\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u044b\\\\u0432\\\\u043d\\\\u043e \\\\u0441\\\\u0432\\\\u044f\\\\u0437\\\\u0430\\\\u043d\\\\u0430 \\\\u0441 \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0439 \\\\u043e\\\\u0442\\\\u0432\\\\u0435\\\\u0442\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c\\\\u044e \\\\u0442\\\\u0435\\\\u0445\\\\u043d\\\\u043e\\\\u043b\\\\u043e\\\\u0433\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0445 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0439, \\\\u0430 \\\\u0440\\\\u0435\\\\u0437\\\\u0443\\\\u043b\\\\u044c\\\\u0442\\\\u0430\\\\u0442\\\\u0430\\\\u043c\\\\u0438 \\\\u0441\\\\u043e\\\\u0442\\\\u0440\\\\u0443\\\\u0434\\\\u043d\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u0442\\\\u0432\\\\u0430 \\\\u0441\\\\u0442\\\\u0430\\\\u043d\\\\u043e\\\\u0432\\\\u044f\\\\u0442\\\\u0441\\\\u044f \\\\u0440\\\\u0435\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e \\\\u043f\\\\u043e\\\\u043b\\\\u0435\\\\u0437\\\\u043d\\\\u044b\\\\u0435 \\\\u043f\\\\u0440\\\\u043e\\\\u0435\\\\u043a\\\\u0442\\\\u044b.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"2\\\",\\\"header\\\":\\\"\\\\u042d\\\\u043a\\\\u0441\\\\u043a\\\\u043b\\\\u044e\\\\u0437\\\\u0438\\\\u0432\\\\u043d\\\\u0430\\\\u044f\\\",\\\"intro\\\":\\\"\\\\u0432\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0432\\\\u044b\\\\u0440\\\\u0430\\\\u0431\\\\u043e\\\\u0442\\\\u0430\\\\u0442\\\\u044c \\\\u0438 \\\\u043d\\\\u0430\\\\u0447\\\\u0430\\\\u0442\\\\u044c \\\\u0434\\\\u0432\\\\u0438\\\\u0433\\\\u0430\\\\u0442\\\\u044c\\\\u0441\\\\u044f \\\\u043f\\\\u043e \\\\u0442\\\\u0440\\\\u0435\\\\u043a\\\\u0443 \\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0442\\\\u0435\\\\u0433\\\\u0438\\\\u0438 \\\\u0432\\\\u0437\\\\u0430\\\\u0438\\\\u043c\\\\u043e\\\\u0432\\\\u044b\\\\u0433\\\\u043e\\\\u0434\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u0441\\\\u043e\\\\u0442\\\\u0440\\\\u0443\\\\u0434\\\\u043d\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u0442\\\\u0432\\\\u0430. \\\\u041f\\\\u043e\\\\u043b\\\\u0435\\\\u0437\\\\u043d\\\\u044b\\\\u0439 \\\\u043e\\\\u043f\\\\u044b\\\\u0442 \\\\u0438 \\\\u0447\\\\u0435\\\\u043b\\\\u043e\\\\u0432\\\\u0435\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u043e\\\\u0435 \\\\u043e\\\\u0431\\\\u0443\\\\u0447\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u2014 \\\\u0431\\\\u0430\\\\u0437\\\\u0438\\\\u0441\\\\u044b.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"3\\\",\\\"header\\\":\\\"\\\\u0413\\\\u043b\\\\u043e\\\\u0431\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u0430\\\\u044f\\\",\\\"intro\\\":\\\"\\\\u043a\\\\u043e\\\\u043c\\\\u043c\\\\u0443\\\\u043d\\\\u0438\\\\u043a\\\\u0430\\\\u0446\\\\u0438\\\\u043e\\\\u043d\\\\u043d\\\\u0430\\\\u044f \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0430 \\\\u0434\\\\u043b\\\\u044f \\\\u0434\\\\u0438\\\\u0441\\\\u043a\\\\u0443\\\\u0441\\\\u0441\\\\u0438\\\\u0439, \\\\u043a\\\\u043e\\\\u043b\\\\u043b\\\\u0430\\\\u0431\\\\u043e\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u0439 \\\\u0438 \\\\u043d\\\\u0435\\\\u0442\\\\u0432\\\\u043e\\\\u0440\\\\u043a\\\\u0438\\\\u043d\\\\u0433\\\\u0430 \\\\u043a\\\\u0440\\\\u0443\\\\u043f\\\\u043d\\\\u0435\\\\u0439\\\\u0448\\\\u0438\\\\u0445 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0439 \\\\u0438 \\\\u043e\\\\u043f\\\\u044b\\\\u0442\\\\u043d\\\\u044b\\\\u0445 \\\\u041d\\\\u041a\\\\u041e. \\\\u0417\\\\u0434\\\\u0435\\\\u0441\\\\u044c \\\\u043f\\\\u0440\\\\u0435\\\\u0434\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d \\\\u0432\\\\u0435\\\\u0441\\\\u044c \\\\u0441\\\\u043f\\\\u0435\\\\u043a\\\\u0442\\\\u0440 \\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0442\\\\u0435\\\\u0433\\\\u0438\\\\u0439 \\\\u0438 \\\\u043f\\\\u0440\\\\u0430\\\\u043a\\\\u0442\\\\u0438\\\\u043a \\\\u0441\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0445 \\\\u0438\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0446\\\\u0438\\\\u0439 IT-\\\\u043e\\\\u0442\\\\u0440\\\\u0430\\\\u0441\\\\u043b\\\\u0438 \\\\u0432 \\\\u043a\\\\u043e\\\\u043d\\\\u0442\\\\u0435\\\\u043a\\\\u0441\\\\u0442\\\\u0435 \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0439 \\\\u043e\\\\u0442\\\\u0432\\\\u0435\\\\u0442\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u0438.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"4\\\",\\\"header\\\":\\\"\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c\\\",\\\"intro\\\":\\\"\\\\u0441\\\\u0442\\\\u0430\\\\u0442\\\\u044c \\\\u043f\\\\u0438\\\\u043e\\\\u043d\\\\u0435\\\\u0440\\\\u043e\\\\u043c \\\\u0441\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u0438\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u0438\\\\u044f \\\\u0432 \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0439 \\\\u0441\\\\u0440\\\\u0435\\\\u0434\\\\u0435: \\\\u0437\\\\u0430\\\\u0434\\\\u0430\\\\u0442\\\\u044c \\\\u0442\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u044b, \\\\u0432\\\\u044b\\\\u0440\\\\u0430\\\\u0431\\\\u043e\\\\u0442\\\\u0430\\\\u0442\\\\u044c \\\\u043a\\\\u043b\\\\u044e\\\\u0447\\\\u0435\\\\u0432\\\\u044b\\\\u0435 \\\\u043f\\\\u0440\\\\u0438\\\\u043d\\\\u0446\\\\u0438\\\\u043f\\\\u044b \\\\u043d\\\\u0430 \\\\u0433\\\\u043e\\\\u0434\\\\u044b \\\\u0432\\\\u043f\\\\u0435\\\\u0440\\\\u0451\\\\u0434.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"}]\"},{\"MIGX_id\":\"3\",\"header\":\"\\u0414\\u043b\\u044f \\u043a\\u043e\\u0433\\u043e \\u0444\\u043e\\u0440\\u0443\\u043c\",\"intro\":\"\",\"points\":\"[{\\\"MIGX_id\\\":\\\"1\\\",\\\"header\\\":\\\"IT-\\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438\\\",\\\"intro\\\":\\\"\\\\u041a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438, \\\\u0440\\\\u0430\\\\u0431\\\\u043e\\\\u0442\\\\u0430\\\\u044e\\\\u0449\\\\u0438\\\\u0435 \\\\u0432 \\\\u0441\\\\u0444\\\\u0435\\\\u0440\\\\u0435 \\\\u0438\\\\u043d\\\\u0444\\\\u043e\\\\u0440\\\\u043c\\\\u0430\\\\u0446\\\\u0438\\\\u043e\\\\u043d\\\\u043d\\\\u044b\\\\u0445 \\\\u0442\\\\u0435\\\\u0445\\\\u043d\\\\u043e\\\\u043b\\\\u043e\\\\u0433\\\\u0438\\\\u0439, \\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u044f\\\\u044e\\\\u0449\\\\u0438\\\\u0435 \\\\u043f\\\\u0440\\\\u0438\\\\u043d\\\\u0446\\\\u0438\\\\u043f\\\\u044b \\\\u0441\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0439 \\\\u043e\\\\u0442\\\\u0432\\\\u0435\\\\u0442\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u0438 \\\\u0438 \\\\u0437\\\\u0430\\\\u0438\\\\u043d\\\\u0442\\\\u0435\\\\u0440\\\\u0435\\\\u0441\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u043d\\\\u044b\\\\u0435 \\\\u0432 \\\\u043f\\\\u043e\\\\u043b\\\\u0443\\\\u0447\\\\u0435\\\\u043d\\\\u0438\\\\u0438 \\\\u043e\\\\u0449\\\\u0443\\\\u0442\\\\u0438\\\\u043c\\\\u044b\\\\u0445 \\\\u0438 \\\\u0438\\\\u0437\\\\u043c\\\\u0435\\\\u0440\\\\u0438\\\\u043c\\\\u044b\\\\u0445 \\\\u0440\\\\u0435\\\\u0437\\\\u0443\\\\u043b\\\\u044c\\\\u0442\\\\u0430\\\\u0442\\\\u043e\\\\u0432 \\\\u043e\\\\u0442 \\\\u0441\\\\u0432\\\\u043e\\\\u0438\\\\u0445 \\\\u0438\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0446\\\\u0438\\\\u0439 \\\\u0432 \\\\u0441\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u0443\\\\u044e \\\\u0441\\\\u0444\\\\u0435\\\\u0440\\\\u0443.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"2\\\",\\\"header\\\":\\\"\\\\u0422\\\\u0435\\\\u0445\\\\u043d\\\\u043e\\\\u043b\\\\u043e\\\\u0433\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0435 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438\\\",\\\"intro\\\":\\\"\\\\u041a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438, \\\\u0440\\\\u0430\\\\u0431\\\\u043e\\\\u0442\\\\u0430\\\\u044e\\\\u0449\\\\u0438\\\\u0435 \\\\u0432 \\\\u0442\\\\u0435\\\\u0445\\\\u043d\\\\u043e\\\\u043b\\\\u043e\\\\u0433\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u043e\\\\u0439 \\\\u043e\\\\u0442\\\\u0440\\\\u0430\\\\u0441\\\\u043b\\\\u0438, \\\\u043e\\\\u043a\\\\u0430\\\\u0437\\\\u044b\\\\u0432\\\\u0430\\\\u044e\\\\u0449\\\\u0438\\\\u0435 \\\\u043f\\\\u043e\\\\u0434\\\\u0434\\\\u0435\\\\u0440\\\\u0436\\\\u043a\\\\u0443 \\\\u043d\\\\u0435\\\\u043a\\\\u043e\\\\u043c\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u043c \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u0438\\\\u0437\\\\u0430\\\\u0446\\\\u0438\\\\u044f\\\\u043c \\\\u0438 \\\\u043e\\\\u0440\\\\u0438\\\\u0435\\\\u043d\\\\u0442\\\\u0438\\\\u0440\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u043d\\\\u044b\\\\u0435 \\\\u043d\\\\u0430 \\\\u0443\\\\u0441\\\\u0442\\\\u043e\\\\u0439\\\\u0447\\\\u0438\\\\u0432\\\\u043e\\\\u0435 \\\\u0440\\\\u0430\\\\u0437\\\\u0432\\\\u0438\\\\u0442\\\\u0438\\\\u0435\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"3\\\",\\\"header\\\":\\\"\\\\u041e\\\\u0431\\\\u0440\\\\u0430\\\\u0437\\\\u043e\\\\u0432\\\\u0430\\\\u0442\\\\u0435\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0435 \\\\u0441\\\\u043e\\\\u043e\\\\u0431\\\\u0449\\\\u0435\\\\u0441\\\\u0442\\\\u0432\\\\u043e\\\",\\\"intro\\\":\\\"\\\\u0420\\\\u0443\\\\u043a\\\\u043e\\\\u0432\\\\u043e\\\\u0434\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u0438 \\\\u0438 \\\\u043f\\\\u0440\\\\u0435\\\\u043f\\\\u043e\\\\u0434\\\\u0430\\\\u0432\\\\u0430\\\\u0442\\\\u0435\\\\u043b\\\\u0438 \\\\u0412\\\\u0423\\\\u0417\\\\u043e\\\\u0432 \\\\u0438 \\\\u043a\\\\u043e\\\\u043b\\\\u043b\\\\u0435\\\\u0434\\\\u0436\\\\u0435\\\\u0439; \\\\u041c\\\\u0435\\\\u0442\\\\u043e\\\\u0434\\\\u0438\\\\u0441\\\\u0442\\\\u044b \\\\u0438 \\\\u0440\\\\u0430\\\\u0437\\\\u0440\\\\u0430\\\\u0431\\\\u043e\\\\u0442\\\\u0447\\\\u0438\\\\u043a\\\\u0438 \\\\u043f\\\\u0440\\\\u043e\\\\u0433\\\\u0440\\\\u0430\\\\u043c\\\\u043c \\\\u043f\\\\u043e\\\\u0432\\\\u044b\\\\u0448\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u043f\\\\u0440\\\\u043e\\\\u0444\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u043e\\\\u043d\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0439 \\\\u043a\\\\u0432\\\\u0430\\\\u043b\\\\u0438\\\\u0444\\\\u0438\\\\u043a\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u0438 \\\\u0434\\\\u043e\\\\u043f\\\\u043e\\\\u043b\\\\u043d\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043e\\\\u0431\\\\u0440\\\\u0430\\\\u0437\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u0438\\\\u044f; \\\\u0420\\\\u0430\\\\u0431\\\\u043e\\\\u0442\\\\u043e\\\\u0434\\\\u0430\\\\u0442\\\\u0435\\\\u043b\\\\u0438, \\\\u0437\\\\u0430\\\\u0438\\\\u043d\\\\u0442\\\\u0435\\\\u0440\\\\u0435\\\\u0441\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u043d\\\\u044b\\\\u0435 \\\\u0432 \\\\u043f\\\\u043e\\\\u0434\\\\u0433\\\\u043e\\\\u0442\\\\u043e\\\\u0432\\\\u043a\\\\u0435 \\\\u043a\\\\u0432\\\\u0430\\\\u043b\\\\u0438\\\\u0444\\\\u0438\\\\u0446\\\\u0438\\\\u0440\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u043d\\\\u044b\\\\u0445 \\\\u043a\\\\u0430\\\\u0434\\\\u0440\\\\u043e\\\\u0432; \\\\u0418\\\\u0441\\\\u0441\\\\u043b\\\\u0435\\\\u0434\\\\u043e\\\\u0432\\\\u0430\\\\u0442\\\\u0435\\\\u043b\\\\u0438 \\\\u0438 \\\\u044d\\\\u043a\\\\u0441\\\\u043f\\\\u0435\\\\u0440\\\\u0442\\\\u044b \\\\u043e\\\\u0431\\\\u0440\\\\u0430\\\\u0437\\\\u043e\\\\u0432\\\\u0430\\\\u0442\\\\u0435\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0439 \\\\u0441\\\\u0444\\\\u0435\\\\u0440\\\\u044b\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"4\\\",\\\"header\\\":\\\"\\\\u041d\\\\u0435\\\\u043a\\\\u043e\\\\u043c\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0435 \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u0438\\\\u0437\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u0438 \\\\u0444\\\\u043e\\\\u043d\\\\u0434\\\\u044b\\\",\\\"intro\\\":\\\"\\\\u0420\\\\u0443\\\\u043a\\\\u043e\\\\u0432\\\\u043e\\\\u0434\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u0438 \\\\u0438 \\\\u0441\\\\u043e\\\\u0442\\\\u0440\\\\u0443\\\\u0434\\\\u043d\\\\u0438\\\\u043a\\\\u0438 \\\\u043d\\\\u0435\\\\u043a\\\\u043e\\\\u043c\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0445 \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u0438\\\\u0437\\\\u0430\\\\u0446\\\\u0438\\\\u0439 (\\\\u041d\\\\u041a\\\\u041e), \\\\u043f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u044f\\\\u044e\\\\u0449\\\\u0438\\\\u0445 \\\\u0441\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e-\\\\u0437\\\\u043d\\\\u0430\\\\u0447\\\\u0438\\\\u043c\\\\u044b\\\\u0435 \\\\u0443\\\\u0441\\\\u043b\\\\u0443\\\\u0433\\\\u0438, \\\\u0438 \\\\u0431\\\\u043b\\\\u0430\\\\u0433\\\\u043e\\\\u0442\\\\u0432\\\\u043e\\\\u0440\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0445 \\\\u0444\\\\u043e\\\\u043d\\\\u0434\\\\u043e\\\\u0432, \\\\u0437\\\\u0430\\\\u0438\\\\u043d\\\\u0442\\\\u0435\\\\u0440\\\\u0435\\\\u0441\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u043d\\\\u044b\\\\u0435 \\\\u0432 \\\\u043d\\\\u0430\\\\u0440\\\\u0430\\\\u0449\\\\u0438\\\\u0432\\\\u0430\\\\u043d\\\\u0438\\\\u0438 \\\\u0441\\\\u0432\\\\u043e\\\\u0435\\\\u0433\\\\u043e \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0433\\\\u043e \\\\u043f\\\\u043e\\\\u0442\\\\u0435\\\\u043d\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"5\\\",\\\"header\\\":\\\"\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u0438 \\\\u0433\\\\u043e\\\\u0441\\\\u0441\\\\u0435\\\\u043a\\\\u0442\\\\u043e\\\\u0440\\\\u0430\\\",\\\"intro\\\":\\\"\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u0438 \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u043e\\\\u0432 \\\\u0433\\\\u043e\\\\u0441\\\\u0443\\\\u0434\\\\u0430\\\\u0440\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u043e\\\\u0439 \\\\u0432\\\\u043b\\\\u0430\\\\u0441\\\\u0442\\\\u0438, \\\\u043a\\\\u0443\\\\u0440\\\\u0430\\\\u0442\\\\u043e\\\\u0440\\\\u044b \\\\u0438 \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b \\\\u043d\\\\u0435\\\\u043a\\\\u043e\\\\u043c\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0445 \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u0438\\\\u0437\\\\u0430\\\\u0446\\\\u0438\\\\u0439, \\\\u0443\\\\u0432\\\\u043b\\\\u0435\\\\u0447\\\\u0451\\\\u043d\\\\u043d\\\\u044b\\\\u0435 \\\\u0442\\\\u0435\\\\u043c\\\\u043e\\\\u0439 \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0433\\\\u043e \\\\u0440\\\\u0430\\\\u0437\\\\u0432\\\\u0438\\\\u0442\\\\u0438\\\\u044f\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"}]\",\"anchor\":\"purpose\",\"chunk\":\"purpose\",\"menutitle\":\"\\u0414\\u043b\\u044f \\u043a\\u043e\\u0433\\u043e\",\"show-in-navi\":\"1\"},{\"MIGX_id\":\"4\",\"header\":\"\\u0427\\u0442\\u043e \\u0431\\u0443\\u0434\\u0435\\u0442\",\"intro\":\"\\u0427\\u0442\\u043e \\u0431\\u0443\\u0434\\u0435\\u0442\",\"points\":\"[{\\\"MIGX_id\\\":\\\"1\\\",\\\"header\\\":\\\"\\u041f\\u043b\\u0435\\u043d\\u0430\\u0440\\u043d\\u044b\\u0435 \\u0441\\u0435\\u0441\\u0441\\u0438\\u0438\\\",\\\"anchor\\\":\\\"\\\",\\\"intro\\\":\\\"\\u0417\\u043d\\u0430\\u043a\\u043e\\u043c\\u0441\\u0442\\u0432\\u0430 \\u0441\\u00a0\\u0432\\u0435\\u0434\\u0443\\u0449\\u0438\\u043c\\u0438 \\u044d\\u043a\\u0441\\u043f\\u0435\\u0440\\u0442\\u0430\\u043c\\u0438 \\u043e\\u0442\\u0440\\u0430\\u0441\\u043b\\u0438\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"2\\\",\\\"header\\\":\\\"\\u041c\\u0430\\u0441\\u0442\\u0435\\u0440-\\u043a\\u043b\\u0430\\u0441\\u0441\\u044b\\\",\\\"intro\\\":\\\"\\u0418\\u043d\\u0442\\u0435\\u043d\\u0441\\u0438\\u0432\\u043d\\u043e\\u0435 \\u0440\\u0430\\u0437\\u0432\\u0438\\u0442\\u0438\\u0435 \\u0432\\u00a0\\u0440\\u0430\\u043c\\u043a\\u0430\\u0445 \\u0432\\u044b\\u0431\\u0440\\u0430\\u043d\\u043d\\u043e\\u0439 \\u0442\\u0435\\u043c\\u044b \\u0438\\u00a0\\u043f\\u0440\\u0438\\u043e\\u0431\\u0440\\u0435\\u0442\\u0435\\u043d\\u0438\\u0435 \\u043d\\u043e\\u0432\\u044b\\u0445 \\u043d\\u0430\\u0432\\u044b\\u043a\\u043e\\u0432\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"3\\\",\\\"header\\\":\\\"\\u041f\\u0430\\u043d\\u0435\\u043b\\u044c\\u043d\\u044b\\u0435 \\u0434\\u0438\\u0441\\u043a\\u0443\\u0441\\u0441\\u0438\\u0438\\\",\\\"intro\\\":\\\"\\u041e\\u0431\\u0441\\u0443\\u0436\\u0434\\u0435\\u043d\\u0438\\u0435 \\u0430\\u043a\\u0442\\u0443\\u0430\\u043b\\u044c\\u043d\\u044b\\u0445 \\u0442\\u0435\\u043c \\u0438 \\u043e\\u043f\\u0440\\u0435\\u0434\\u0435\\u043b\\u0435\\u043d\\u0438\\u0435 \\u0441\\u0442\\u0440\\u0430\\u0442\\u0435\\u0433\\u0438\\u0439 \\u0440\\u0430\\u0437\\u0432\\u0438\\u0442\\u0438\\u044f\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"4\\\",\\\"header\\\":\\\"\\u041d\\u0435\\u0442\\u0432\\u043e\\u0440\\u043a\\u0438\\u043d\\u0433-\\u0441\\u0435\\u0441\\u0441\\u0438\\u0438\\\",\\\"intro\\\":\\\"\\u041a\\u043e\\u043c\\u0444\\u043e\\u0440\\u0442\\u043d\\u043e\\u0435 \\u043e\\u0431\\u0449\\u0435\\u043d\\u0438\\u0435 \\u0438 \\u0432\\u044b\\u0441\\u0442\\u0440\\u0430\\u0438\\u0432\\u0430\\u043d\\u0438\\u0435 \\u043a\\u043e\\u043b\\u043b\\u0430\\u0431\\u043e\\u0440\\u0430\\u0446\\u0438\\u0439\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"5\\\",\\\"header\\\":\\\"\\u041a\\u0440\\u0443\\u0433\\u043b\\u044b\\u0435 \\u0441\\u0442\\u043e\\u043b\\u044b\\\",\\\"intro\\\":\\\"\\u041e\\u0431\\u043c\\u0435\\u043d \\u043e\\u043f\\u044b\\u0442\\u043e\\u043c \\u043c\\u0435\\u0436\\u0434\\u0443 \\u043a\\u043e\\u043b\\u043b\\u0435\\u0433\\u0430\\u043c\\u0438\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"6\\\",\\\"header\\\":\\\"\\u0411\\u043b\\u0438\\u0446-\\u0434\\u043e\\u043a\\u043b\\u0430\\u0434\\u044b\\\",\\\"intro\\\":\\\"\\u041f\\u0440\\u0435\\u0437\\u0435\\u043d\\u0442\\u0430\\u0446\\u0438\\u044f \\u0441\\u043e\\u0431\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u044b\\u0445 \\u043f\\u0440\\u0430\\u043a\\u0442\\u0438\\u043a, \\u043a\\u043e\\u043d\\u0446\\u0435\\u043d\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f \\u0443\\u043d\\u0438\\u043a\\u0430\\u043b\\u044c\\u043d\\u043e\\u0433\\u043e \\u043e\\u043f\\u044b\\u0442\\u0430\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"}]\",\"anchor\":\"\",\"chunk\":\"included\",\"menutitle\":\"\\u0427\\u0442\\u043e \\u0431\\u0443\\u0434\\u0435\\u0442\",\"show-in-navi\":\"\"},{\"MIGX_id\":\"5\",\"header\":\"\\u041d\\u0430 \\u0444\\u043e\\u0440\\u0443\\u043c\\u0435 \\u043e\\u0431\\u0441\\u0443\\u0434\\u0438\\u043c\",\"intro\":\"\",\"points\":\"[{\\\"MIGX_id\\\":\\\"1\\\",\\\"header\\\":\\\"\\\\u0418\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u0443\\\\u0435\\\\u043c \\\\u0432 \\\\u043a\\\\u043e\\\\u043b\\\\u043b\\\\u0430\\\\u0431\\\\u043e\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u0438\\\",\\\"intro\\\":\\\"\\\\u0421\\\\u0442\\\\u0440\\\\u0430\\\\u0442\\\\u0435\\\\u0433\\\\u0438\\\\u044f \\\\u0432\\\\u0437\\\\u0430\\\\u0438\\\\u043c\\\\u043e\\\\u0432\\\\u044b\\\\u0433\\\\u043e\\\\u0434\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u0441\\\\u0442\\\\u0432\\\\u0430 \\\\u0447\\\\u0435\\\\u0440\\\\u0435\\\\u0437 \\\\u043f\\\\u0440\\\\u0438\\\\u0437\\\\u043c\\\\u0443 \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0439 \\\\u043e\\\\u0442\\\\u0432\\\\u0435\\\\u0442\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u0438\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"2\\\",\\\"header\\\":\\\"\\\\u0418\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u0443\\\\u0435\\\\u043c \\\\u0432 \\\\u043e\\\\u0431\\\\u0440\\\\u0430\\\\u0437\\\\u043e\\\\u0432\\\\u0430\\\\u043d\\\\u0438\\\\u0435\\\",\\\"intro\\\":\\\"\\\\u041a\\\\u043e\\\\u043d\\\\u043a\\\\u0443\\\\u0440\\\\u0435\\\\u043d\\\\u0442\\\\u043e\\\\u0441\\\\u043f\\\\u043e\\\\u0441\\\\u043e\\\\u0431\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c vs \\\\u043a\\\\u043e\\\\u043d\\\\u043a\\\\u0443\\\\u0440\\\\u0435\\\\u043d\\\\u0442\\\\u043e\\\\u043f\\\\u0435\\\\u0440\\\\u0435\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u0435: \\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0442\\\\u0435\\\\u0433\\\\u0438\\\\u044f, \\\\u043a\\\\u043e\\\\u0442\\\\u043e\\\\u0440\\\\u0443\\\\u044e \\\\u0432\\\\u044b\\\\u0431\\\\u0438\\\\u0440\\\\u0430\\\\u0435\\\\u043c\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"3\\\",\\\"header\\\":\\\"\\\\u0418\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u0443\\\\u0435\\\\u043c \\\\u0432 \\\\u0441\\\\u043e\\\\u0442\\\\u0440\\\\u0443\\\\u0434\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432\\\",\\\"intro\\\":\\\"\\\\u0421\\\\u0440\\\\u0435\\\\u0434\\\\u0430, \\\\u043e\\\\u0442\\\\u043a\\\\u0440\\\\u044b\\\\u0442\\\\u0430\\\\u044f \\\\u043a \\\\u0438\\\\u043d\\\\u043d\\\\u043e\\\\u0432\\\\u0430\\\\u0446\\\\u0438\\\\u044f\\\\u043c \\\\u0438 \\\\u043f\\\\u0440\\\\u043e\\\\u0444\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u043e\\\\u043d\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u043c\\\\u0443 \\\\u0440\\\\u0430\\\\u0437\\\\u0432\\\\u0438\\\\u0442\\\\u0438\\\\u044e\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"4\\\",\\\"header\\\":\\\"\\\\u0418\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u0443\\\\u0435\\\\u043c \\\\u0432 \\\\u043e\\\\u0431\\\\u0449\\\\u0435\\\\u0441\\\\u0442\\\\u0432\\\\u043e\\\",\\\"intro\\\":\\\"\\\\u041f\\\\u0440\\\\u0438\\\\u043d\\\\u0446\\\\u0438\\\\u043f\\\\u044b \\\\u0438 \\\\u043f\\\\u0440\\\\u0430\\\\u043a\\\\u0442\\\\u0438\\\\u043a\\\\u0438 \\\\u043d\\\\u0430\\\\u0440\\\\u0430\\\\u0449\\\\u0438\\\\u0432\\\\u0430\\\\u043d\\\\u0438\\\\u044f \\\\u0446\\\\u0438\\\\u0444\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0433\\\\u043e \\\\u043f\\\\u043e\\\\u0442\\\\u0435\\\\u043d\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u0430 \\\\u0422\\\\u0440\\\\u0435\\\\u0442\\\\u044c\\\\u0435\\\\u0433\\\\u043e \\\\u0441\\\\u0435\\\\u043a\\\\u0442\\\\u043e\\\\u0440\\\\u0430 \\\\u0438 \\\\u0443\\\\u0441\\\\u043b\\\\u043e\\\\u0432\\\\u0438\\\\u044f \\\\u0432\\\\u043e\\\\u0437\\\\u0432\\\\u0440\\\\u0430\\\\u0442\\\\u0430 \\\\u043d\\\\u0430 \\\\u0441\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0435 \\\\u0438\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0446\\\\u0438\\\\u0438\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"5\\\",\\\"header\\\":\\\"\\\\u0418\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u0443\\\\u0435\\\\u043c \\\\u0432 \\\\u043a\\\\u043e\\\\u0440\\\\u043f\\\\u043e\\\\u0440\\\\u0430\\\\u0442\\\\u0438\\\\u0432\\\\u043d\\\\u0443\\\\u044e \\\\u043a\\\\u0443\\\\u043b\\\\u044c\\\\u0442\\\\u0443\\\\u0440\\\\u0443\\\",\\\"intro\\\":\\\"\\\\u0426\\\\u0435\\\\u043d\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u0438, \\\\u043f\\\\u0440\\\\u0438\\\\u043d\\\\u0446\\\\u0438\\\\u043f\\\\u044b \\\\u0438 \\\\u0438\\\\u0445 \\\\u043f\\\\u0440\\\\u0430\\\\u043a\\\\u0442\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u043e\\\\u0435 \\\\u0432\\\\u043e\\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u0434\\\\u043b\\\\u044f \\\\u0443\\\\u0441\\\\u0442\\\\u043e\\\\u0439\\\\u0447\\\\u0438\\\\u0432\\\\u043e\\\\u0433\\\\u043e \\\\u0440\\\\u0430\\\\u0437\\\\u0432\\\\u0438\\\\u0442\\\\u0438\\\\u044f \\\\u0431\\\\u0438\\\\u0437\\\\u043d\\\\u0435\\\\u0441\\\\u0430\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"6\\\",\\\"header\\\":\\\"\\\\u0418\\\\u043d\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0440\\\\u0443\\\\u0435\\\\u043c \\\\u0432 \\\\u0434\\\\u043e\\\\u0432\\\\u0435\\\\u0440\\\\u0438\\\\u0435\\\",\\\"intro\\\":\\\"\\\\u041f\\\\u0440\\\\u0430\\\\u043a\\\\u0442\\\\u0438\\\\u043a\\\\u0438 \\\\u0441\\\\u043e\\\\u0437\\\\u0434\\\\u0430\\\\u043d\\\\u0438\\\\u044f \\\\u043a\\\\u0440\\\\u0435\\\\u043f\\\\u043a\\\\u043e\\\\u0433\\\\u043e \\\\u0431\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u0430 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438 \\\\u043d\\\\u0430 \\\\u043a\\\\u043e\\\\u0440\\\\u043f\\\\u043e\\\\u0440\\\\u0430\\\\u0442\\\\u0438\\\\u0432\\\\u043d\\\\u043e\\\\u043c, \\\\u0442\\\\u043e\\\\u0432\\\\u0430\\\\u0440\\\\u043d\\\\u043e\\\\u043c \\\\u0438 HR \\\\u0443\\\\u0440\\\\u043e\\\\u0432\\\\u043d\\\\u044f\\\\u0445. \\\\u0421\\\\u043e\\\\u0446\\\\u0438\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0439 \\\\u0431\\\\u0440\\\\u0435\\\\u043d\\\\u0434\\\\u0438\\\\u043d\\\\u0433 \\\\u043a\\\\u0430\\\\u043a \\\\u043d\\\\u043e\\\\u0432\\\\u044b\\\\u0439 \\\\u0438\\\\u043d\\\\u0441\\\\u0442\\\\u0440\\\\u0443\\\\u043c\\\\u0435\\\\u043d\\\\u0442 \\\\u043f\\\\u0440\\\\u043e\\\\u0434\\\\u0432\\\\u0438\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"\\\"}]\",\"anchor\":\"\",\"chunk\":\"discuss\",\"menutitle\":\"\\u041d\\u0430 \\u0444\\u043e\\u0440\\u0443\\u043c\\u0435 \\u043e\\u0431\\u0441\\u0443\\u0434\\u0438\\u043c\",\"show-in-navi\":\"\"},{\"MIGX_id\":\"6\",\"header\":\"\\u0424\\u043e\\u0440\\u043c\\u0438\\u0440\\u0443\\u0439\\u0442\\u0435 \\u0441\\u0442\\u0440\\u0430\\u0442\\u0435\\u0433\\u0438\\u0438 \\u0441\\u043e\\u0446\\u0438\\u0430\\u043b\\u044c\\u043d\\u043e\\u0439 \\u0446\\u0438\\u0444\\u0440\\u043e\\u0432\\u043e\\u0439 \\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0441\\u0442\\u0438 \\u043e\\u0442\\u0435\\u0447\\u0435\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0439 IT \\u043e\\u0442\\u0440\\u0430\\u0441\\u043b\\u0438\",\"intro\":\"\",\"points\":\"[{\\\"MIGX_id\\\":\\\"1\\\",\\\"header\\\":\\\"\\u041e\\u043a\\u0430\\u0436\\u0438\\u0442\\u0435 \\u0432\\u043b\\u0438\\u044f\\u043d\\u0438\\u0435\\\",\\\"intro\\\":\\\"\\u0417\\u0430\\u043b\\u043e\\u0436\\u0438\\u0442\\u0435 \\u043e\\u0441\\u043d\\u043e\\u0432\\u044b \\u043d\\u043e\\u0432\\u043e\\u0433\\u043e \\u043a\\u043e\\u043d\\u0446\\u0435\\u043f\\u0442\\u0430 \\u0432 \\u0442\\u0435\\u0445\\u043d\\u043e\\u043b\\u043e\\u0433\\u0438\\u0447\\u0435\\u0441\\u043a\\u043e\\u043c \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0435\\\",\\\"icon\\\":\\\"\\/assets\\/img\\/icons\\/influence.svg\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"2\\\",\\\"header\\\":\\\"\\u041f\\u043e\\u0434\\u0435\\u043b\\u0438\\u0442\\u0435\\u0441\\u044c \\u043e\\u043f\\u044b\\u0442\\u043e\\u043c \\u0438 \\u0437\\u043d\\u0430\\u043d\\u0438\\u044f\\u043c\\u0438\\\",\\\"intro\\\":\\\"\\u041f\\u043e\\u043c\\u043e\\u0433\\u0438\\u0442\\u0435 \\u0438\\u043d\\u0434\\u0443\\u0441\\u0442\\u0440\\u0438\\u0438 \\u0438\\u0437\\u043c\\u0435\\u043d\\u0438\\u0442\\u044c\\u0441\\u044f \\u043a \\u043b\\u0443\\u0447\\u0448\\u0435\\u043c\\u0443\\\",\\\"icon\\\":\\\"\\/assets\\/img\\/icons\\/share.svg\\\",\\\"content\\\":\\\"\\\"},{\\\"MIGX_id\\\":\\\"3\\\",\\\"header\\\":\\\"\\u0421\\u0442\\u0430\\u043d\\u044c\\u0442\\u0435 \\u0442\\u0440\\u0435\\u043d\\u0434\\u0441\\u0435\\u0442\\u0442\\u0435\\u0440\\u043e\\u043c\\\",\\\"intro\\\":\\\"\\u041f\\u0440\\u043e\\u044f\\u0432\\u0438\\u0442\\u0435 \\u0441\\u0435\\u0431\\u044f \\u2014 \\u0443\\u0447\\u0430\\u0441\\u0442\\u0432\\u0443\\u0439\\u0442\\u0435 \\u0432 \\u043a\\u043e\\u043b\\u043b\\u0430\\u0431\\u043e\\u0440\\u0430\\u0446\\u0438\\u044f\\u0445 \\u043a\\u0430\\u043a \\u044d\\u043a\\u0441\\u043f\\u0435\\u0440\\u0442\\\\n\\\",\\\"icon\\\":\\\"\\/assets\\/img\\/icons\\/lead.svg\\\",\\\"content\\\":\\\"\\\"}]\",\"anchor\":\"invitation\",\"chunk\":\"invitation\",\"menutitle\":\"\\u041f\\u0440\\u0438\\u0433\\u043b\\u0430\\u0448\\u0435\\u043d\\u0438\\u0435\",\"show-in-navi\":\"1\"},{\"MIGX_id\":\"7\",\"header\":\"\\u0417\\u0430\\u044f\\u0432\\u043a\\u0430 \\u043d\\u0430 \\u0432\\u044b\\u0441\\u0442\\u0443\\u043f\\u043b\\u0435\\u043d\\u0438\\u0435\",\"intro\":\"\",\"points\":\"\",\"anchor\":\"\",\"chunk\":\"speaker-form\",\"menutitle\":\"\\u0417\\u0430\\u044f\\u0432\\u043a\\u0430 \\u043d\\u0430 \\u0432\\u044b\\u0441\\u0442\\u0443\\u043f\\u043b\\u0435\\u043d\\u0438\\u0435\",\"show-in-navi\":\"\"},{\"MIGX_id\":\"8\",\"header\":\"\\u0421\\u0442\\u0430\\u043d\\u044c\\u0442\\u0435 \\u043f\\u0430\\u0440\\u0442\\u043d\\u0451\\u0440\\u043e\\u043c \\u0438 \\u0444\\u043e\\u0440\\u043c\\u0438\\u0440\\u0443\\u0439\\u0442\\u0435 \\u043f\\u043e\\u0432\\u0435\\u0441\\u0442\\u043a\\u0443\",\"intro\":\"\",\"points\":\"[{\\\"MIGX_id\\\":\\\"1\\\",\\\"header\\\":\\\"\\\\u0413\\\\u0435\\\\u043d\\\\u0435\\\\u0440\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0439 \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\",\\\"anchor\\\":\\\"general\\\",\\\"intro\\\":\\\"\\\\u0421\\\\u043e\\\\u0437\\\\u0434\\\\u0430\\\\u0451\\\\u0442 \\\\u043a\\\\u043b\\\\u044e\\\\u0447\\\\u0435\\\\u0432\\\\u043e\\\\u0439 \\\\u0442\\\\u0440\\\\u0435\\\\u043a, \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u0432\\\\u0443\\\\u0435\\\\u0442 \\\\u0432 \\\\u043f\\\\u043b\\\\u0435\\\\u043d\\\\u0430\\\\u0440\\\\u043d\\\\u043e\\\\u0439 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438 - \\\\u0432\\\\u0441\\\\u0435\\\\u0433\\\\u0434\\\\u0430 \\\\u0438 \\\\u0432\\\\u0435\\\\u0437\\\\u0434\\\\u0435 \\\\u043d\\\\u0430 \\\\u043f\\\\u0435\\\\u0440\\\\u0432\\\\u044b\\\\u0445 \\\\u0440\\\\u043e\\\\u043b\\\\u044f\\\\u0445!\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"<div class=\\\\\\\"possibilities\\\\\\\">\\\\n<div class=\\\\\\\"tab-content general active\\\\\\\">\\\\n<ul>\\\\n<li>\\\\u0412\\\\u043b\\\\u043e\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0432&nbsp;Welcome Pack \\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430 \\\\u0438&nbsp;\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0430 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0437\\\\u0430\\\\u043f\\\\u0443\\\\u0441\\\\u043a\\\\u0430\\\\u0442\\\\u044c \\\\u043d\\\\u0430&nbsp;\\\\u043c\\\\u0435\\\\u0434\\\\u0438\\\\u0430 \\\\u044d\\\\u043a\\\\u0440\\\\u0430\\\\u043d\\\\u0430\\\\u0445 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438 \\\\u0441\\\\u0432\\\\u043e\\\\u0438 \\\\u0432\\\\u0438\\\\u0434\\\\u0435\\\\u043e \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u044b \\\\u043f\\\\u043e&nbsp;\\\\u0442\\\\u0435\\\\u043c\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0441\\\\u0444\\\\u043e\\\\u0440\\\\u043c\\\\u0438\\\\u0440\\\\u043e\\\\u0432\\\\u0430\\\\u0442\\\\u044c \\\\u0441\\\\u043e\\\\u0431\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u044b\\\\u0439 \\\\u0442\\\\u0435\\\\u043c\\\\u0430\\\\u0442\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0439 \\\\u0442\\\\u0440\\\\u0435\\\\u043a \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u043c\\\\u043a\\\\u0430\\\\u0445 \\\\u043f\\\\u043e\\\\u0432\\\\u0435\\\\u0441\\\\u0442\\\\u043a\\\\u0438 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0443\\\\u0441\\\\u0442\\\\u0430\\\\u043d\\\\u043e\\\\u0432\\\\u0438\\\\u0442\\\\u044c \\\\u043d\\\\u0430&nbsp;\\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0435 \\\\u0441\\\\u0442\\\\u0435\\\\u043d\\\\u0434 4\\\\u04452&nbsp;\\\\u043c\\\\u0435\\\\u0442\\\\u0440\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0414\\\\u043e\\\\u0441\\\\u0442\\\\u0443\\\\u043f \\\\u043a&nbsp;\\\\u0432\\\\u0438\\\\u0434\\\\u0435\\\\u043e-\\\\u0437\\\\u0430\\\\u043f\\\\u0438\\\\u0441\\\\u044f\\\\u043c \\\\u043c\\\\u0435\\\\u0440\\\\u043e\\\\u043f\\\\u0440\\\\u0438\\\\u044f\\\\u0442\\\\u0438\\\\u0439 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0418\\\\u043d\\\\u0434\\\\u0438\\\\u0432\\\\u0438\\\\u0434\\\\u0443\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0435 \\\\u043f\\\\u0440\\\\u0438\\\\u0433\\\\u043b\\\\u0430\\\\u0448\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u043d\\\\u0430&nbsp;\\\\u043b\\\\u0435\\\\u043a\\\\u0446\\\\u0438\\\\u044e \\\\u0410\\\\u043b\\\\u0435\\\\u043a\\\\u0441\\\\u0435\\\\u044f \\\\u0421\\\\u0435\\\\u043c\\\\u0438\\\\u0445\\\\u0430\\\\u0442\\\\u043e\\\\u0432\\\\u0430 (\\\\u043d\\\\u0430&nbsp;20&nbsp;\\\\u043f\\\\u0435\\\\u0440\\\\u0441\\\\u043e\\\\u043d)<\\\\\\/li>\\\\n<li>\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u0434\\\\u0432\\\\u0443\\\\u0445 \\\\u043f\\\\u0430\\\\u0440\\\\u043a\\\\u043e\\\\u0432\\\\u043e\\\\u0447\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0435\\\\u0441\\\\u0442<\\\\\\/li>\\\\n<li>\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 VIP \\\\u043f\\\\u0435\\\\u0440\\\\u0435\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440\\\\u043d\\\\u043e\\\\u0439 \\\\u0441&nbsp;\\\\u0444\\\\u0443\\\\u0440\\\\u0448\\\\u0435\\\\u0442\\\\u043e\\\\u043c<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0431\\\\u0435\\\\u0439\\\\u0434\\\\u0436\\\\u0435 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0433\\\\u043b\\\\u0430\\\\u0432\\\\u043d\\\\u043e\\\\u043c \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u043e\\\\u043c Press Wall \\\\u0432&nbsp;\\\\u0444\\\\u043e\\\\u0442\\\\u043e \\\\u0437\\\\u043e\\\\u043d\\\\u0435<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u043c\\\\u0435\\\\u0434\\\\u0438\\\\u0430 \\\\u044d\\\\u043a\\\\u0440\\\\u0430\\\\u043d\\\\u0430\\\\u0445 \\\\u0432\\\\u043d\\\\u0443\\\\u0442\\\\u0440\\\\u0438 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u043d\\\\u0438\\\\u0446\\\\u0435 \\\\u0440\\\\u0435\\\\u0433\\\\u0438\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043f\\\\u0443\\\\u0431\\\\u043b\\\\u0438\\\\u043a\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 (\\\\u0434\\\\u043e&nbsp;1500&nbsp;\\\\u0437\\\\u043d\\\\u0430\\\\u043a\\\\u043e\\\\u0432) \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041d\\\\u043e\\\\u0432\\\\u043e\\\\u0441\\\\u0442\\\\u0438&raquo; \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u043f\\\\u043e\\\\u043c\\\\u0438\\\\u043d\\\\u0430\\\\u043d\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u044b\\\\u0445 \\\\u0438&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\\u0445<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0413\\\\u0430\\\\u043b\\\\u0430-\\\\u0444\\\\u0443\\\\u0440\\\\u0448\\\\u0435\\\\u0442\\\\u0435<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u0438\\\\u0435 \\\\u043f\\\\u0440\\\\u0435\\\\u0434\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u0438\\\\u0442\\\\u0435\\\\u043b\\\\u044f \\\\u0433\\\\u0435\\\\u043d\\\\u0435\\\\u0440\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u0430 \\\\u0432&nbsp;\\\\u043f\\\\u043b\\\\u0435\\\\u043d\\\\u0430\\\\u0440\\\\u043d\\\\u043e\\\\u0439 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<\\\\\\/ul>\\\\n<\\\\\\/div>\\\\n<\\\\\\/div>\\\"},{\\\"MIGX_id\\\":\\\"2\\\",\\\"header\\\":\\\"\\\\u0421\\\\u0442\\\\u0440\\\\u0430\\\\u0442\\\\u0435\\\\u0433\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u0438\\\\u0439 \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\",\\\"anchor\\\":\\\"strategic\\\",\\\"intro\\\":\\\"\\\\u041f\\\\u0440\\\\u043e\\\\u0432\\\\u043e\\\\u0434\\\\u0438\\\\u0442 \\\\u0441\\\\u043e\\\\u0431\\\\u0441\\\\u0442\\\\u0432\\\\u0435\\\\u043d\\\\u043d\\\\u0443\\\\u044e \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u044e, \\\\u043f\\\\u043e\\\\u044f\\\\u0432\\\\u043b\\\\u044f\\\\u0435\\\\u0442\\\\u0441\\\\u044f \\\\u043d\\\\u0430 \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\\u0445 \\\\u0438 \\\\u0432\\\\u0441\\\\u0435\\\\u0433\\\\u0434\\\\u0430 \\\\u0443\\\\u043f\\\\u043e\\\\u043c\\\\u0438\\\\u043d\\\\u0430\\\\u0435\\\\u0442\\\\u0441\\\\u044f \\\\u0432 \\\\u043a\\\\u043e\\\\u043d\\\\u0442\\\\u0435\\\\u043a\\\\u0441\\\\u0442\\\\u0435 \\\\u043a\\\\u043e\\\\u043d\\\\u0444\\\\u0435\\\\u0440\\\\u0435\\\\u043d\\\\u0446\\\\u0438\\\\u0438!\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"<ul>\\\\n<li>\\\\u0412\\\\u043b\\\\u043e\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0432&nbsp;Welcome Pack \\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430 \\\\u0438&nbsp;\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0430 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0437\\\\u0430\\\\u043f\\\\u0443\\\\u0441\\\\u043a\\\\u0430\\\\u0442\\\\u044c \\\\u043d\\\\u0430&nbsp;\\\\u043c\\\\u0435\\\\u0434\\\\u0438\\\\u0430 \\\\u044d\\\\u043a\\\\u0440\\\\u0430\\\\u043d\\\\u0430\\\\u0445 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438 \\\\u0441\\\\u0432\\\\u043e\\\\u0438 \\\\u0432\\\\u0438\\\\u0434\\\\u0435\\\\u043e \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u044b \\\\u043f\\\\u043e&nbsp;\\\\u0442\\\\u0435\\\\u043c\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0443\\\\u0441\\\\u0442\\\\u0430\\\\u043d\\\\u043e\\\\u0432\\\\u0438\\\\u0442\\\\u044c \\\\u043d\\\\u0430 &nbsp;\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0435 \\\\u0441\\\\u0442\\\\u0435\\\\u043d\\\\u0434 3\\\\u04452&nbsp;\\\\u043c\\\\u0435\\\\u0442\\\\u0440\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0414\\\\u043e\\\\u0441\\\\u0442\\\\u0443\\\\u043f \\\\u043a&nbsp;\\\\u0432\\\\u0438\\\\u0434\\\\u0435\\\\u043e-\\\\u0437\\\\u0430\\\\u043f\\\\u0438\\\\u0441\\\\u044f\\\\u043c \\\\u043c\\\\u0435\\\\u0440\\\\u043e\\\\u043f\\\\u0440\\\\u0438\\\\u044f\\\\u0442\\\\u0438\\\\u0439 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0418\\\\u043d\\\\u0434\\\\u0438\\\\u0432\\\\u0438\\\\u0434\\\\u0443\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0435 \\\\u043f\\\\u0440\\\\u0438\\\\u0433\\\\u043b\\\\u0430\\\\u0448\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u043d\\\\u0430&nbsp;\\\\u043b\\\\u0435\\\\u043a\\\\u0446\\\\u0438\\\\u044e \\\\u0410\\\\u043b\\\\u0435\\\\u043a\\\\u0441\\\\u0435\\\\u044f \\\\u0421\\\\u0435\\\\u043c\\\\u0438\\\\u0445\\\\u0430\\\\u0442\\\\u043e\\\\u0432\\\\u0430 (\\\\u043d\\\\u0430&nbsp;10&nbsp;\\\\u043f\\\\u0435\\\\u0440\\\\u0441\\\\u043e\\\\u043d)<\\\\\\/li>\\\\n<li>\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u0437\\\\u0430\\\\u043b\\\\u0430 \\\\u0434\\\\u043b\\\\u044f \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u0438\\\\u0437\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u043e\\\\u0434\\\\u043d\\\\u043e\\\\u0439 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u043c\\\\u043a\\\\u0430\\\\u0445 \\\\u0442\\\\u0435\\\\u043c\\\\u0430\\\\u0442\\\\u0438\\\\u0447\\\\u0435\\\\u0441\\\\u043a\\\\u043e\\\\u0433\\\\u043e \\\\u0442\\\\u0440\\\\u0435\\\\u043a\\\\u0430 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043e\\\\u0434\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043f\\\\u0430\\\\u0440\\\\u043a\\\\u043e\\\\u0432\\\\u043e\\\\u0447\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043c\\\\u0435\\\\u0441\\\\u0442\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 VIP \\\\u043f\\\\u0435\\\\u0440\\\\u0435\\\\u0433\\\\u043e\\\\u0432\\\\u043e\\\\u0440\\\\u043d\\\\u043e\\\\u0439 \\\\u0441&nbsp;\\\\u0444\\\\u0443\\\\u0440\\\\u0448\\\\u0435\\\\u0442\\\\u043e\\\\u043c<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0431\\\\u0435\\\\u0439\\\\u0434\\\\u0436\\\\u0435 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0433\\\\u043b\\\\u0430\\\\u0432\\\\u043d\\\\u043e\\\\u043c \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u043e\\\\u043c Press Wall \\\\u0432&nbsp;\\\\u0444\\\\u043e\\\\u0442\\\\u043e \\\\u0437\\\\u043e\\\\u043d\\\\u0435<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u043c\\\\u0435\\\\u0434\\\\u0438\\\\u0430 \\\\u044d\\\\u043a\\\\u0440\\\\u0430\\\\u043d\\\\u0430\\\\u0445 \\\\u0432\\\\u043d\\\\u0443\\\\u0442\\\\u0440\\\\u0438 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u043d\\\\u0438\\\\u0446\\\\u0435 \\\\u0440\\\\u0435\\\\u0433\\\\u0438\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043f\\\\u0443\\\\u0431\\\\u043b\\\\u0438\\\\u043a\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 (\\\\u0434\\\\u043e&nbsp;1000&nbsp;\\\\u0437\\\\u043d\\\\u0430\\\\u043a\\\\u043e\\\\u0432) \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041d\\\\u043e\\\\u0432\\\\u043e\\\\u0441\\\\u0442\\\\u0438&raquo; \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u0440\\\\u043e\\\\u043b\\\\u0430\\\\u043f\\\\u0430 \\\\u0432&nbsp;\\\\u0437\\\\u0430\\\\u043b\\\\u0435 \\\\u0434\\\\u043b\\\\u044f \\\\u043f\\\\u0440\\\\u043e\\\\u0432\\\\u0435\\\\u0434\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0441\\\\u0435\\\\u043a\\\\u0446\\\\u0438\\\\u0438 (\\\\u043f\\\\u043e&nbsp;\\\\u0433\\\\u043e\\\\u0442\\\\u043e\\\\u0432\\\\u043e\\\\u043c\\\\u0443 \\\\u043c\\\\u0430\\\\u043a\\\\u0435\\\\u0442\\\\u0443)<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u043f\\\\u043e\\\\u043c\\\\u0438\\\\u043d\\\\u0430\\\\u043d\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u044b\\\\u0445 \\\\u0438&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\\u0445 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0413\\\\u0430\\\\u043b\\\\u0430-\\\\u0444\\\\u0443\\\\u0440\\\\u0448\\\\u0435\\\\u0442\\\\u0435<\\\\\\/li>\\\\n<\\\\\\/ul>\\\"},{\\\"MIGX_id\\\":\\\"3\\\",\\\"header\\\":\\\"\\\\u0412\\\\u0435\\\\u0434\\\\u0443\\\\u0449\\\\u0438\\\\u0439 \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\",\\\"anchor\\\":\\\"leading\\\",\\\"intro\\\":\\\"\\\\u0412\\\\u044b\\\\u0441\\\\u0442\\\\u0443\\\\u043f\\\\u0430\\\\u0435\\\\u0442 \\\\u0432 \\\\u0440\\\\u0430\\\\u043c\\\\u043a\\\\u0430\\\\u0445 \\\\u043b\\\\u044e\\\\u0431\\\\u043e\\\\u0439 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438, \\\\u0440\\\\u0435\\\\u043a\\\\u043e\\\\u043c\\\\u0435\\\\u043d\\\\u0434\\\\u0443\\\\u0435\\\\u0442 \\\\u0441\\\\u043f\\\\u0438\\\\u043a\\\\u0435\\\\u0440\\\\u043e\\\\u0432, \\\\u043f\\\\u043e\\\\u043b\\\\u0443\\\\u0447\\\\u0430\\\\u0435\\\\u0442\\\\u0441\\\\u044f \\\\u043c\\\\u0435\\\\u0441\\\\u0442\\\\u0430 \\\\u043f\\\\u043e\\\\u0434 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u044b \\\\u0438 \\\\u0437\\\\u0430\\\\u043d\\\\u0438\\\\u043c\\\\u0430\\\\u0435\\\\u0442 \\\\u0432\\\\u0430\\\\u0436\\\\u043d\\\\u043e\\\\u0435 \\\\u043c\\\\u0435\\\\u0441\\\\u0442\\\\u043e \\\\u0441\\\\u0440\\\\u0435\\\\u0434\\\\u0438 \\\\u0433\\\\u043b\\\\u0430\\\\u0432\\\\u043d\\\\u044b\\\\u0445 \\\\u0434\\\\u0435\\\\u0439\\\\u0441\\\\u0442\\\\u0432\\\\u0443\\\\u044e\\\\u0449\\\\u0438\\\\u0445 \\\\u043b\\\\u0438\\\\u0446.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"<ul>\\\\n<li>\\\\u0412\\\\u043b\\\\u043e\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0432&nbsp;Welcome Pack \\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430 \\\\u0438&nbsp;\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0430 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0432\\\\u044b\\\\u0441\\\\u0442\\\\u0443\\\\u043f\\\\u0438\\\\u0442\\\\u044c \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u043c\\\\u043a\\\\u0430\\\\u0445 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438 \\\\u043f\\\\u043e&nbsp;\\\\u0432\\\\u044b\\\\u0431\\\\u043e\\\\u0440\\\\u0443 \\\\u043f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0440\\\\u0435\\\\u043a\\\\u043e\\\\u043c\\\\u0435\\\\u043d\\\\u0434\\\\u043e\\\\u0432\\\\u0430\\\\u0442\\\\u044c \\\\u0441\\\\u043f\\\\u0438\\\\u043a\\\\u0435\\\\u0440\\\\u043e\\\\u0432 \\\\u0434\\\\u043b\\\\u044f \\\\u0432\\\\u044b\\\\u0441\\\\u0442\\\\u0443\\\\u043f\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0432&nbsp;\\\\u043f\\\\u0440\\\\u043e\\\\u0433\\\\u0440\\\\u0430\\\\u043c\\\\u043c\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0443\\\\u0441\\\\u0442\\\\u0430\\\\u043d\\\\u043e\\\\u0432\\\\u0438\\\\u0442\\\\u044c \\\\u043d\\\\u0430&nbsp;\\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0435 \\\\u0441\\\\u0442\\\\u0435\\\\u043d\\\\u0434 2\\\\u04452&nbsp;\\\\u043c\\\\u0435\\\\u0442\\\\u0440\\\\u0430 \\\\u0434\\\\u043b\\\\u044f \\\\u043f\\\\u0440\\\\u043e\\\\u0434\\\\u0432\\\\u0438\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0441\\\\u0432\\\\u043e\\\\u0435\\\\u0439 \\\\u0442\\\\u0435\\\\u0445\\\\u043d\\\\u0438\\\\u043a\\\\u0438 \\\\u0438\\\\u043b\\\\u0438 \\\\u043f\\\\u0440\\\\u043e\\\\u0434\\\\u0443\\\\u043a\\\\u0442\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0414\\\\u043e\\\\u0441\\\\u0442\\\\u0443\\\\u043f \\\\u043a&nbsp;\\\\u0432\\\\u0438\\\\u0434\\\\u0435\\\\u043e-\\\\u0437\\\\u0430\\\\u043f\\\\u0438\\\\u0441\\\\u044f\\\\u043c \\\\u043c\\\\u0435\\\\u0440\\\\u043e\\\\u043f\\\\u0440\\\\u0438\\\\u044f\\\\u0442\\\\u0438\\\\u0439 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0418\\\\u043d\\\\u0434\\\\u0438\\\\u0432\\\\u0438\\\\u0434\\\\u0443\\\\u0430\\\\u043b\\\\u044c\\\\u043d\\\\u044b\\\\u0435 \\\\u043f\\\\u0440\\\\u0438\\\\u0433\\\\u043b\\\\u0430\\\\u0448\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u043d\\\\u0430&nbsp;\\\\u043b\\\\u0435\\\\u043a\\\\u0446\\\\u0438\\\\u044e \\\\u0410\\\\u043b\\\\u0435\\\\u043a\\\\u0441\\\\u0435\\\\u044f \\\\u0421\\\\u0435\\\\u043c\\\\u0438\\\\u0445\\\\u0430\\\\u0442\\\\u043e\\\\u0432\\\\u0430 (\\\\u043d\\\\u0430&nbsp;5&nbsp;\\\\u043f\\\\u0435\\\\u0440\\\\u0441\\\\u043e\\\\u043d)<\\\\\\/li>\\\\n<li>\\\\u041f\\\\u0440\\\\u0435\\\\u0434\\\\u043e\\\\u0441\\\\u0442\\\\u0430\\\\u0432\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043e\\\\u0434\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043f\\\\u0430\\\\u0440\\\\u043a\\\\u043e\\\\u0432\\\\u043e\\\\u0447\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043c\\\\u0435\\\\u0441\\\\u0442\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0431\\\\u0435\\\\u0439\\\\u0434\\\\u0436\\\\u0435 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0433\\\\u043b\\\\u0430\\\\u0432\\\\u043d\\\\u043e\\\\u043c \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u043e\\\\u043c Press Wall \\\\u0432&nbsp;\\\\u0444\\\\u043e\\\\u0442\\\\u043e \\\\u0437\\\\u043e\\\\u043d\\\\u0435<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u043c\\\\u0435\\\\u0434\\\\u0438\\\\u0430 \\\\u044d\\\\u043a\\\\u0440\\\\u0430\\\\u043d\\\\u0430\\\\u0445 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438 \\\\u0432\\\\u043d\\\\u0443\\\\u0442\\\\u0440\\\\u0438 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u043d\\\\u0438\\\\u0446\\\\u0435 \\\\u0440\\\\u0435\\\\u0433\\\\u0438\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043f\\\\u0443\\\\u0431\\\\u043b\\\\u0438\\\\u043a\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 (\\\\u0434\\\\u043e&nbsp;500&nbsp;\\\\u0437\\\\u043d\\\\u0430\\\\u043a\\\\u043e\\\\u0432) \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041d\\\\u043e\\\\u0432\\\\u043e\\\\u0441\\\\u0442\\\\u0438&raquo; \\\\u0444\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u043f\\\\u043e\\\\u043c\\\\u0438\\\\u043d\\\\u0430\\\\u043d\\\\u0438\\\\u0435 \\\\u0432 \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u044b\\\\u0445 \\\\u0438&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\\u0445 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0413\\\\u0430\\\\u043b\\\\u0430-\\\\u0444\\\\u0443\\\\u0440\\\\u0448\\\\u0435\\\\u0442\\\\u0435<\\\\\\/li>\\\\n<\\\\\\/ul>\\\"},{\\\"MIGX_id\\\":\\\"4\\\",\\\"header\\\":\\\"\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\",\\\"anchor\\\":\\\"regular\\\",\\\"intro\\\":\\\"\\\\u0412\\\\u0430\\\\u0436\\\\u043d\\\\u044b\\\\u0439 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a \\\\u043e\\\\u0440\\\\u0433\\\\u0430\\\\u043d\\\\u0438\\\\u0437\\\\u0430\\\\u0446\\\\u0438\\\\u043e\\\\u043d\\\\u043d\\\\u043e\\\\u0439 \\\\u043a\\\\u043e\\\\u043c\\\\u0430\\\\u043d\\\\u0434\\\\u044b \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430: \\\\u0432\\\\u043b\\\\u0438\\\\u044f\\\\u0435\\\\u0442 \\\\u043d\\\\u0430 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438, \\\\u043f\\\\u043e\\\\u044f\\\\u0432\\\\u043b\\\\u044f\\\\u0435\\\\u0442\\\\u0441\\\\u044f \\\\u043d\\\\u0430 \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\\u0445 \\\\u0438 \\\\u043f\\\\u0440\\\\u0438\\\\u0441\\\\u0443\\\\u0442\\\\u0441\\\\u0442\\\\u0432\\\\u0443\\\\u0435\\\\u0442 \\\\u043d\\\\u0430 \\\\u0431\\\\u0430\\\\u043d\\\\u043d\\\\u0435\\\\u0440\\\\u0430\\\\u0445 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438.\\\",\\\"icon\\\":\\\"\\\",\\\"content\\\":\\\"<ul>\\\\n<li>\\\\u0412\\\\u043b\\\\u043e\\\\u0436\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0432 Welcome Pack \\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u043e\\\\u0433\\\\u043e \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430 \\\\u0438&nbsp;\\\\u043c\\\\u0435\\\\u0440\\\\u0447\\\\u0430 \\\\u043a\\\\u043e\\\\u043c\\\\u043f\\\\u0430\\\\u043d\\\\u0438\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u043e\\\\u0437\\\\u043c\\\\u043e\\\\u0436\\\\u043d\\\\u043e\\\\u0441\\\\u0442\\\\u044c \\\\u0440\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0441\\\\u0442\\\\u0438\\\\u0442\\\\u044c \\\\u0441\\\\u0432\\\\u043e\\\\u0439 \\\\u0431\\\\u0430\\\\u043d\\\\u043d\\\\u0435\\\\u0440 \\\\u0432&nbsp;\\\\u0437\\\\u0430\\\\u043b\\\\u0435 \\\\u043f\\\\u0440\\\\u043e\\\\u0432\\\\u0435\\\\u0434\\\\u0435\\\\u043d\\\\u0438\\\\u044f \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0412\\\\u044b\\\\u0441\\\\u0442\\\\u0443\\\\u043f\\\\u043b\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043d\\\\u0430 \\\\u0441\\\\u0435\\\\u0441\\\\u0441\\\\u0438\\\\u0438 \\\\u0438\\\\\\/\\\\u0438\\\\u043b\\\\u0438 \\\\u0435\\\\u0451 \\\\u043c\\\\u043e\\\\u0434\\\\u0435\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u044f<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0431\\\\u0435\\\\u0439\\\\u0434\\\\u0436\\\\u0435 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0433\\\\u043b\\\\u0430\\\\u0432\\\\u043d\\\\u043e\\\\u043c \\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u043e\\\\u043c Press Wall \\\\u0432&nbsp;\\\\u0444\\\\u043e\\\\u0442\\\\u043e \\\\u0437\\\\u043e\\\\u043d\\\\u0435<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u043c\\\\u0435\\\\u0434\\\\u0438\\\\u0430 \\\\u044d\\\\u043a\\\\u0440\\\\u0430\\\\u043d\\\\u0430\\\\u0445 \\\\u0432\\\\u043d\\\\u0443\\\\u0442\\\\u0440\\\\u0438 \\\\u043f\\\\u043b\\\\u043e\\\\u0449\\\\u0430\\\\u0434\\\\u043a\\\\u0438<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0430\\\\u0439\\\\u0442\\\\u0435 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0420\\\\u0430\\\\u0437\\\\u043c\\\\u0435\\\\u0449\\\\u0435\\\\u043d\\\\u0438\\\\u0435 \\\\u043b\\\\u043e\\\\u0433\\\\u043e\\\\u0442\\\\u0438\\\\u043f\\\\u0430 \\\\u043d\\\\u0430&nbsp;\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u043d\\\\u0438\\\\u0446\\\\u0435 \\\\u0440\\\\u0435\\\\u0433\\\\u0438\\\\u0441\\\\u0442\\\\u0440\\\\u0430\\\\u0446\\\\u0438\\\\u0438 \\\\u0443\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u043d\\\\u0438\\\\u043a\\\\u043e\\\\u0432 \\\\u0432&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0435\\\\u043b\\\\u0435 &laquo;\\\\u041f\\\\u0430\\\\u0440\\\\u0442\\\\u043d\\\\u0451\\\\u0440\\\\u044b&raquo;<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u043f\\\\u043e\\\\u043c\\\\u0438\\\\u043d\\\\u0430\\\\u043d\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0440\\\\u0435\\\\u043a\\\\u043b\\\\u0430\\\\u043c\\\\u043d\\\\u044b\\\\u0445 \\\\u0438&nbsp;\\\\u0440\\\\u0430\\\\u0437\\\\u0434\\\\u0430\\\\u0442\\\\u043e\\\\u0447\\\\u043d\\\\u044b\\\\u0445 \\\\u043c\\\\u0430\\\\u0442\\\\u0435\\\\u0440\\\\u0438\\\\u0430\\\\u043b\\\\u0430\\\\u0445 \\\\u0424\\\\u043e\\\\u0440\\\\u0443\\\\u043c\\\\u0430<\\\\\\/li>\\\\n<li>\\\\u0423\\\\u0447\\\\u0430\\\\u0441\\\\u0442\\\\u0438\\\\u0435 \\\\u0432&nbsp;\\\\u0413\\\\u0430\\\\u043b\\\\u0430-\\\\u0444\\\\u0443\\\\u0440\\\\u0448\\\\u0435\\\\u0442\\\\u0435<\\\\\\/li>\\\\n<\\\\\\/ul>\\\"}]\",\"anchor\":\"partnership\",\"chunk\":\"partnership\",\"menutitle\":\"\\u041f\\u0430\\u0440\\u0442\\u043d\\u0451\\u0440\\u0441\\u0442\\u0432\\u043e\",\"show-in-navi\":\"1\"},{\"MIGX_id\":\"9\",\"header\":\"\\u0420\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f \\u043f\\u0430\\u0440\\u0442\\u043d\\u0451\\u0440\\u0430\",\"intro\":\"\",\"points\":\"\",\"anchor\":\"\",\"chunk\":\"register-partner\",\"menutitle\":\"\\u0420\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f \\u043f\\u0430\\u0440\\u0442\\u043d\\u0451\\u0440\\u0430\",\"show-in-navi\":\"\"}]');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_site_tmplvar_templates`
--

CREATE TABLE `modx_site_tmplvar_templates` (
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `templateid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_site_tmplvar_templates`
--

INSERT INTO `modx_site_tmplvar_templates` (`tmplvarid`, `templateid`, `rank`) VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_system_eventnames`
--

CREATE TABLE `modx_system_eventnames` (
  `name` varchar(50) NOT NULL,
  `service` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `groupname` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_system_eventnames`
--

INSERT INTO `modx_system_eventnames` (`name`, `service`, `groupname`) VALUES
('OnBeforeCacheUpdate', 4, 'System'),
('OnBeforeChunkFormDelete', 1, 'Chunks'),
('OnBeforeChunkFormSave', 1, 'Chunks'),
('OnBeforeDocFormDelete', 1, 'Resources'),
('OnBeforeDocFormSave', 1, 'Resources'),
('OnBeforeEmptyTrash', 1, 'Resources'),
('OnBeforeManagerLogin', 2, 'Security'),
('OnBeforeManagerLogout', 2, 'Security'),
('OnBeforeManagerPageInit', 2, 'System'),
('OnBeforePluginFormDelete', 1, 'Plugins'),
('OnBeforePluginFormSave', 1, 'Plugins'),
('OnBeforeRegisterClientScripts', 5, 'System'),
('OnBeforeSaveWebPageCache', 4, 'System'),
('OnBeforeSnipFormDelete', 1, 'Snippets'),
('OnBeforeSnipFormSave', 1, 'Snippets'),
('OnBeforeTempFormDelete', 1, 'Templates'),
('OnBeforeTempFormSave', 1, 'Templates'),
('OnBeforeTVFormDelete', 1, 'Template Variables'),
('OnBeforeTVFormSave', 1, 'Template Variables'),
('OnBeforeUserActivate', 1, 'Users'),
('OnBeforeUserDeactivate', 1, 'Users'),
('OnBeforeUserDuplicate', 1, 'Users'),
('OnBeforeUserFormDelete', 1, 'Users'),
('OnBeforeUserFormSave', 1, 'Users'),
('OnBeforeUserGroupFormRemove', 1, 'User Groups'),
('OnBeforeUserGroupFormSave', 1, 'User Groups'),
('OnBeforeWebLogin', 3, 'Security'),
('OnBeforeWebLogout', 3, 'Security'),
('OnCacheUpdate', 4, 'System'),
('OnCategoryBeforeRemove', 1, 'Categories'),
('OnCategoryBeforeSave', 1, 'Categories'),
('OnCategoryRemove', 1, 'Categories'),
('OnCategorySave', 1, 'Categories'),
('OnChunkBeforeRemove', 1, 'Chunks'),
('OnChunkBeforeSave', 1, 'Chunks'),
('OnChunkFormDelete', 1, 'Chunks'),
('OnChunkFormPrerender', 1, 'Chunks'),
('OnChunkFormRender', 1, 'Chunks'),
('OnChunkFormSave', 1, 'Chunks'),
('OnChunkRemove', 1, 'Chunks'),
('OnChunkSave', 1, 'Chunks'),
('OnContextBeforeRemove', 1, 'Contexts'),
('OnContextBeforeSave', 1, 'Contexts'),
('OnContextFormPrerender', 2, 'Contexts'),
('OnContextFormRender', 2, 'Contexts'),
('OnContextInit', 1, 'Contexts'),
('OnContextRemove', 1, 'Contexts'),
('OnContextSave', 1, 'Contexts'),
('OnDocFormDelete', 1, 'Resources'),
('OnDocFormPrerender', 1, 'Resources'),
('OnDocFormRender', 1, 'Resources'),
('OnDocFormSave', 1, 'Resources'),
('OnDocPublished', 5, 'Resources'),
('OnDocUnPublished', 5, 'Resources'),
('OnElementNotFound', 1, 'System'),
('OnEmptyTrash', 1, 'Resources'),
('OnFileCreateFormPrerender', 1, 'System'),
('OnFileEditFormPrerender', 1, 'System'),
('OnFileManagerBeforeUpload', 1, 'System'),
('OnFileManagerDirCreate', 1, 'System'),
('OnFileManagerDirRemove', 1, 'System'),
('OnFileManagerDirRename', 1, 'System'),
('OnFileManagerFileCreate', 1, 'System'),
('OnFileManagerFileRemove', 1, 'System'),
('OnFileManagerFileRename', 1, 'System'),
('OnFileManagerFileUpdate', 1, 'System'),
('OnFileManagerMoveObject', 1, 'System'),
('OnFileManagerUpload', 1, 'System'),
('OnHandleRequest', 5, 'System'),
('OnInitCulture', 1, 'Internationalization'),
('OnLoadWebDocument', 5, 'System'),
('OnLoadWebPageCache', 4, 'System'),
('OnManagerAuthentication', 2, 'Security'),
('OnManagerLogin', 2, 'Security'),
('OnManagerLoginFormPrerender', 2, 'Security'),
('OnManagerLoginFormRender', 2, 'Security'),
('OnManagerLogout', 2, 'Security'),
('OnManagerPageAfterRender', 2, 'System'),
('OnManagerPageBeforeRender', 2, 'System'),
('OnManagerPageInit', 2, 'System'),
('OnMediaSourceBeforeFormDelete', 1, 'Media Sources'),
('OnMediaSourceBeforeFormSave', 1, 'Media Sources'),
('OnMediaSourceDuplicate', 1, 'Media Sources'),
('OnMediaSourceFormDelete', 1, 'Media Sources'),
('OnMediaSourceFormSave', 1, 'Media Sources'),
('OnMediaSourceGetProperties', 1, 'Media Sources'),
('OnMODXInit', 5, 'System'),
('OnPackageInstall', 2, 'Package Manager'),
('OnPackageRemove', 2, 'Package Manager'),
('OnPackageUninstall', 2, 'Package Manager'),
('OnPageNotFound', 1, 'System'),
('OnPageUnauthorized', 1, 'Security'),
('OnParseDocument', 5, 'System'),
('OnPluginBeforeRemove', 1, 'Plugins'),
('OnPluginBeforeSave', 1, 'Plugins'),
('OnPluginEventBeforeRemove', 1, 'Plugin Events'),
('OnPluginEventBeforeSave', 1, 'Plugin Events'),
('OnPluginEventRemove', 1, 'Plugin Events'),
('OnPluginEventSave', 1, 'Plugin Events'),
('OnPluginFormDelete', 1, 'Plugins'),
('OnPluginFormPrerender', 1, 'Plugins'),
('OnPluginFormRender', 1, 'Plugins'),
('OnPluginFormSave', 1, 'Plugins'),
('OnPluginRemove', 1, 'Plugins'),
('OnPluginSave', 1, 'Plugins'),
('OnPropertySetBeforeRemove', 1, 'Property Sets'),
('OnPropertySetBeforeSave', 1, 'Property Sets'),
('OnPropertySetRemove', 1, 'Property Sets'),
('OnPropertySetSave', 1, 'Property Sets'),
('OnResourceAddToResourceGroup', 1, 'Resources'),
('OnResourceAutoPublish', 1, 'Resources'),
('OnResourceBeforeSort', 1, 'Resources'),
('OnResourceCacheUpdate', 1, 'Resources'),
('OnResourceDelete', 1, 'Resources'),
('OnResourceDuplicate', 1, 'Resources'),
('OnResourceGroupBeforeRemove', 1, 'Security'),
('OnResourceGroupBeforeSave', 1, 'Security'),
('OnResourceGroupRemove', 1, 'Security'),
('OnResourceGroupSave', 1, 'Security'),
('OnResourceRemoveFromResourceGroup', 1, 'Resources'),
('OnResourceSort', 1, 'Resources'),
('OnResourceToolbarLoad', 1, 'Resources'),
('OnResourceTVFormPrerender', 1, 'Resources'),
('OnResourceTVFormRender', 1, 'Resources'),
('OnResourceUndelete', 1, 'Resources'),
('OnRichTextBrowserInit', 1, 'RichText Editor'),
('OnRichTextEditorInit', 1, 'RichText Editor'),
('OnRichTextEditorRegister', 1, 'RichText Editor'),
('OnSiteRefresh', 1, 'System'),
('OnSiteSettingsRender', 1, 'Settings'),
('OnSnipFormDelete', 1, 'Snippets'),
('OnSnipFormPrerender', 1, 'Snippets'),
('OnSnipFormRender', 1, 'Snippets'),
('OnSnipFormSave', 1, 'Snippets'),
('OnSnippetBeforeRemove', 1, 'Snippets'),
('OnSnippetBeforeSave', 1, 'Snippets'),
('OnSnippetRemove', 1, 'Snippets'),
('OnSnippetSave', 1, 'Snippets'),
('OnTempFormDelete', 1, 'Templates'),
('OnTempFormPrerender', 1, 'Templates'),
('OnTempFormRender', 1, 'Templates'),
('OnTempFormSave', 1, 'Templates'),
('OnTemplateBeforeRemove', 1, 'Templates'),
('OnTemplateBeforeSave', 1, 'Templates'),
('OnTemplateRemove', 1, 'Templates'),
('OnTemplateSave', 1, 'Templates'),
('OnTemplateVarBeforeRemove', 1, 'Template Variables'),
('OnTemplateVarBeforeSave', 1, 'Template Variables'),
('OnTemplateVarRemove', 1, 'Template Variables'),
('OnTemplateVarSave', 1, 'Template Variables'),
('OnTVFormDelete', 1, 'Template Variables'),
('OnTVFormPrerender', 1, 'Template Variables'),
('OnTVFormRender', 1, 'Template Variables'),
('OnTVFormSave', 1, 'Template Variables'),
('OnTVInputPropertiesList', 1, 'Template Variables'),
('OnTVInputRenderList', 1, 'Template Variables'),
('OnTVOutputRenderList', 1, 'Template Variables'),
('OnTVOutputRenderPropertiesList', 1, 'Template Variables'),
('OnUserActivate', 1, 'Users'),
('OnUserAddToGroup', 1, 'User Groups'),
('OnUserBeforeAddToGroup', 1, 'User Groups'),
('OnUserBeforeRemove', 1, 'Users'),
('OnUserBeforeRemoveFromGroup', 1, 'User Groups'),
('OnUserBeforeSave', 1, 'Users'),
('OnUserChangePassword', 1, 'Users'),
('OnUserDeactivate', 1, 'Users'),
('OnUserDuplicate', 1, 'Users'),
('OnUserFormDelete', 1, 'Users'),
('OnUserFormPrerender', 1, 'Users'),
('OnUserFormRender', 1, 'Users'),
('OnUserFormSave', 1, 'Users'),
('OnUserGroupBeforeRemove', 1, 'User Groups'),
('OnUserGroupBeforeSave', 1, 'User Groups'),
('OnUserGroupFormSave', 1, 'User Groups'),
('OnUserGroupRemove', 1, 'User Groups'),
('OnUserGroupSave', 1, 'User Groups'),
('OnUserNotFound', 1, 'Users'),
('OnUserProfileBeforeRemove', 1, 'User Profiles'),
('OnUserProfileBeforeSave', 1, 'User Profiles'),
('OnUserProfileRemove', 1, 'User Profiles'),
('OnUserProfileSave', 1, 'User Profiles'),
('OnUserRemove', 1, 'Users'),
('OnUserRemoveFromGroup', 1, 'User Groups'),
('OnUserSave', 1, 'Users'),
('OnWebAuthentication', 3, 'Security'),
('OnWebLogin', 3, 'Security'),
('OnWebLogout', 3, 'Security'),
('OnWebPageComplete', 5, 'System'),
('OnWebPageInit', 5, 'System'),
('OnWebPagePrerender', 5, 'System');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_system_settings`
--

CREATE TABLE `modx_system_settings` (
  `key` varchar(50) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_system_settings`
--

INSERT INTO `modx_system_settings` (`key`, `value`, `xtype`, `namespace`, `area`, `editedon`) VALUES
('access_category_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('access_context_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('access_resource_group_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('ace.fold_widgets', '1', 'combo-boolean', 'ace', 'general', NULL),
('ace.font_size', '13px', 'textfield', 'ace', 'general', NULL),
('ace.grow', '', 'textfield', 'ace', 'general', NULL),
('ace.height', '', 'textfield', 'ace', 'general', NULL),
('ace.html_elements_mime', '', 'textfield', 'ace', 'general', NULL),
('ace.show_invisibles', '0', 'combo-boolean', 'ace', 'general', NULL),
('ace.snippets', '', 'textarea', 'ace', 'general', NULL),
('ace.soft_tabs', '1', 'combo-boolean', 'ace', 'general', NULL),
('ace.tab_size', '4', 'textfield', 'ace', 'general', NULL),
('ace.theme', 'chrome', 'textfield', 'ace', 'general', NULL),
('ace.word_wrap', '', 'combo-boolean', 'ace', 'general', NULL),
('address', 'г. Москва, ул. Покровка, д. 47, ЦДП', 'textfield', 'core', 'Контакты', '2025-07-18 06:30:21'),
('allow_forward_across_contexts', '', 'combo-boolean', 'core', 'system', NULL),
('allow_manager_login_forgot_password', '1', 'combo-boolean', 'core', 'authentication', NULL),
('allow_multiple_emails', '1', 'combo-boolean', 'core', 'authentication', NULL),
('allow_tags_in_post', '', 'combo-boolean', 'core', 'system', NULL),
('anonymous_sessions', '1', 'combo-boolean', 'core', 'session', NULL),
('archive_with', '', 'combo-boolean', 'core', 'system', NULL),
('automatic_alias', '1', 'combo-boolean', 'core', 'furls', NULL),
('automatic_template_assignment', 'sibling', 'textfield', 'core', 'site', NULL),
('auto_check_pkg_updates', '1', 'combo-boolean', 'core', 'system', NULL),
('auto_check_pkg_updates_cache_expire', '15', 'numberfield', 'core', 'system', NULL),
('auto_isfolder', '1', 'combo-boolean', 'core', 'site', NULL),
('auto_menuindex', '1', 'combo-boolean', 'core', 'site', NULL),
('base_help_url', '//docs.modx.com/help/', 'textfield', 'core', 'manager', NULL),
('blocked_minutes', '60', 'numberfield', 'core', 'authentication', NULL),
('cache_alias_map', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_context_settings', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_db', '', 'combo-boolean', 'core', 'caching', NULL),
('cache_db_expires', '0', 'numberfield', 'core', 'caching', NULL),
('cache_db_session', '', 'combo-boolean', 'core', 'caching', NULL),
('cache_db_session_lifetime', '', 'numberfield', 'core', 'caching', NULL),
('cache_default', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_expires', '0', 'numberfield', 'core', 'caching', NULL),
('cache_format', '0', 'numberfield', 'core', 'caching', NULL),
('cache_handler', 'xPDO\\Cache\\xPDOFileCache', 'textfield', 'core', 'caching', NULL),
('cache_lang_js', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_lexicon_topics', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_noncore_lexicon_topics', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource_clear_partial', '', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource_expires', '0', 'numberfield', 'core', 'caching', NULL),
('cache_scripts', '1', 'combo-boolean', 'core', 'caching', NULL),
('clear_cache_refresh_trees', '', 'combo-boolean', 'core', 'caching', NULL),
('compress_css', '1', 'combo-boolean', 'core', 'manager', NULL),
('compress_js', '1', 'combo-boolean', 'core', 'manager', NULL),
('confirm_navigation', '1', 'combo-boolean', 'core', 'manager', NULL),
('contact', 'Наталья Романова', 'textfield', 'core', 'Контакты', NULL),
('container_suffix', '/', 'textfield', 'core', 'furls', NULL),
('context_tree_sort', '1', 'combo-boolean', 'core', 'manager', NULL),
('context_tree_sortby', 'rank', 'textfield', 'core', 'manager', NULL),
('context_tree_sortdir', 'ASC', 'textfield', 'core', 'manager', NULL),
('cultureKey', 'ru', 'modx-combo-language', 'core', 'language', '2025-07-17 10:29:56'),
('date_timezone', '', 'textfield', 'core', 'system', NULL),
('debug', '', 'numberfield', 'core', 'system', NULL),
('default_content_type', '1', 'modx-combo-content-type', 'core', 'site', NULL),
('default_context', 'web', 'modx-combo-context', 'core', 'site', NULL),
('default_duplicate_publish_option', 'preserve', 'textfield', 'core', 'manager', NULL),
('default_media_source', '1', 'modx-combo-source', 'core', 'manager', NULL),
('default_media_source_type', 'MODX\\Revolution\\Sources\\modFileMediaSource', 'modx-combo-source-type', 'core', 'manager', NULL),
('default_per_page', '20', 'textfield', 'core', 'manager', NULL),
('default_template', '1', 'modx-combo-template', 'core', 'site', NULL),
('default_username', '(anonymous)', 'textfield', 'core', 'session', NULL),
('email', 'info@smart-social.org', 'textfield', 'core', 'Контакты', NULL),
('emailsender', 'masterkadaj@gmail.com', 'textfield', 'core', 'authentication', '2025-07-17 10:29:56'),
('enable_dragdrop', '1', 'combo-boolean', 'core', 'manager', NULL),
('enable_gravatar', '', 'combo-boolean', 'core', 'manager', NULL),
('enable_template_picker_in_tree', '1', 'combo-boolean', 'core', 'manager', NULL),
('error_log_filename', 'error.log', 'textfield', 'core', 'system', NULL),
('error_log_filepath', '', 'textfield', 'core', 'system', NULL),
('error_page', '1', 'numberfield', 'core', 'site', NULL),
('failed_login_attempts', '5', 'numberfield', 'core', 'authentication', NULL),
('feed_modx_news', 'https://feeds.feedburner.com/modx-announce', 'textfield', 'core', 'system', NULL),
('feed_modx_news_enabled', '1', 'combo-boolean', 'core', 'system', NULL),
('feed_modx_security', 'https://forums.modx.com/board.xml?board=294', 'textfield', 'core', 'system', NULL),
('feed_modx_security_enabled', '1', 'combo-boolean', 'core', 'system', NULL),
('form_customization_use_all_groups', '', 'combo-boolean', 'core', 'manager', NULL),
('forward_merge_excludes', 'type,published,class_key', 'textfield', 'core', 'system', NULL),
('friendly_alias_lowercase_only', '1', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_max_length', '0', 'numberfield', 'core', 'furls', NULL),
('friendly_alias_realtime', '', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_restrict_chars', 'pattern', 'textfield', 'core', 'furls', NULL),
('friendly_alias_restrict_chars_pattern', '/[\\0\\x0B\\t\\n\\r\\f\\a&=+%#<>\"~:`@\\?\\[\\]\\{\\}\\|\\^\'\\\\]/', 'textfield', 'core', 'furls', NULL),
('friendly_alias_strip_element_tags', '1', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_translit', 'none', 'textfield', 'core', 'furls', NULL),
('friendly_alias_translit_class', 'translit.modTransliterate', 'textfield', 'core', 'furls', NULL),
('friendly_alias_translit_class_path', '{core_path}components/', 'textfield', 'core', 'furls', NULL),
('friendly_alias_trim_chars', '/.-_', 'textfield', 'core', 'furls', NULL),
('friendly_alias_word_delimiter', '-', 'textfield', 'core', 'furls', NULL),
('friendly_alias_word_delimiters', '-_', 'textfield', 'core', 'furls', NULL),
('friendly_urls', '', 'combo-boolean', 'core', 'furls', NULL),
('friendly_urls_strict', '', 'combo-boolean', 'core', 'furls', NULL),
('global_duplicate_uri_check', '', 'combo-boolean', 'core', 'furls', NULL),
('hidemenu_default', '', 'combo-boolean', 'core', 'site', NULL),
('inline_help', '1', 'combo-boolean', 'core', 'manager', NULL),
('link_tag_scheme', '-1', 'textfield', 'core', 'site', NULL),
('locale', '', 'textfield', 'core', 'language', NULL),
('lock_ttl', '360', 'numberfield', 'core', 'system', NULL),
('login_background_image', '', 'textfield', 'core', 'authentication', NULL),
('login_help_button', '', 'combo-boolean', 'core', 'authentication', NULL),
('login_logo', '', 'textfield', 'core', 'authentication', NULL),
('log_deprecated', '1', 'combo-boolean', 'core', 'system', NULL),
('log_level', '1', 'numberfield', 'core', 'system', NULL),
('log_snippet_not_found', '1', 'combo-boolean', 'core', 'site', NULL),
('log_target', 'FILE', 'textfield', 'core', 'system', NULL),
('mail_charset', 'UTF-8', 'modx-combo-charset', 'core', 'mail', NULL),
('mail_dkim_domain', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_identity', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_passphrase', '', 'text-password', 'core', 'mail', NULL),
('mail_dkim_privatekeyfile', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_privatekeystring', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_selector', '', 'textfield', 'core', 'mail', NULL),
('mail_encoding', '8bit', 'textfield', 'core', 'mail', NULL),
('mail_smtp_auth', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_autotls', '1', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_helo', '', 'textfield', 'core', 'mail', NULL),
('mail_smtp_hosts', 'localhost', 'textfield', 'core', 'mail', NULL),
('mail_smtp_keepalive', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_pass', '', 'text-password', 'core', 'mail', NULL),
('mail_smtp_port', '587', 'numberfield', 'core', 'mail', NULL),
('mail_smtp_secure', '', 'textfield', 'core', 'mail', NULL),
('mail_smtp_single_to', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_timeout', '10', 'numberfield', 'core', 'mail', NULL),
('mail_smtp_user', '', 'textfield', 'core', 'mail', NULL),
('mail_use_smtp', '', 'combo-boolean', 'core', 'mail', NULL),
('main_nav_parent', 'topnav', 'textfield', 'core', 'manager', NULL),
('manager_datetime_empty_value', '—', 'textfield', 'core', 'manager', NULL),
('manager_datetime_separator', ', ', 'textfield', 'core', 'manager', NULL),
('manager_date_format', 'Y-m-d', 'textfield', 'core', 'manager', NULL),
('manager_direction', 'ltr', 'textfield', 'core', 'language', NULL),
('manager_favicon_url', 'favicon.ico', 'textfield', 'core', 'manager', NULL),
('manager_login_url_alternate', '', 'textfield', 'core', 'authentication', NULL),
('manager_logo', '', 'textfield', 'core', 'manager', NULL),
('manager_theme', 'default', 'modx-combo-manager-theme', 'core', 'manager', NULL),
('manager_time_format', 'H:i', 'textfield', 'core', 'manager', NULL),
('manager_tooltip_delay', '2300', 'numberfield', 'core', 'manager', NULL),
('manager_tooltip_enable', '1', 'combo-boolean', 'core', 'manager', NULL),
('manager_use_fullname', '', 'combo-boolean', 'core', 'manager', NULL),
('manager_week_start', '0', 'numberfield', 'core', 'manager', NULL),
('mgr_source_icon', 'icon-folder-open-o', 'textfield', 'core', 'manager', NULL),
('mgr_tree_icon_context', 'tree-context', 'textfield', 'core', 'manager', NULL),
('modx_browser_default_sort', 'name', 'textfield', 'core', 'manager', NULL),
('modx_browser_default_viewmode', 'grid', 'textfield', 'core', 'manager', NULL),
('modx_browser_tree_hide_files', '1', 'combo-boolean', 'core', 'manager', NULL),
('modx_browser_tree_hide_tooltips', '1', 'combo-boolean', 'core', 'manager', NULL),
('modx_charset', 'UTF-8', 'modx-combo-charset', 'core', 'language', NULL),
('package_installer_at_top', '1', 'combo-boolean', 'core', 'manager', NULL),
('parser_recurse_uncacheable', '1', 'combo-boolean', 'core', 'system', NULL),
('passwordless_activated', '', 'combo-boolean', 'core', 'authentication', NULL),
('passwordless_expiration', '3600', 'textfield', 'core', 'authentication', NULL),
('password_generated_length', '10', 'numberfield', 'core', 'authentication', NULL),
('password_min_length', '8', 'numberfield', 'core', 'authentication', NULL),
('phone-link', '+79819414145', 'textfield', 'core', 'Контакты', NULL),
('phone-text', '+7 981 941-4145', 'textfield', 'core', 'Контакты', '2025-07-17 12:56:23'),
('phpthumb_allow_src_above_docroot', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxage', '30', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxfiles', '10000', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxsize', '100', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_source_enabled', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_document_root', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_bgcolor', 'CCCCFF', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_fontsize', '1', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_error_textcolor', 'FF0000', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_far', 'C', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_imagemagick_path', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_enabled', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_erase_image', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_text_message', 'Off-server thumbnailing is not allowed', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_valid_domains', '{http_host}', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_enabled', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_erase_image', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_require_refer', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_text_message', 'Off-server linking is not allowed', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_valid_domains', '{http_host}', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_watermark_src', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_zoomcrop', '0', 'textfield', 'core', 'phpthumb', NULL),
('preserve_menuindex', '', 'combo-boolean', 'core', 'manager', NULL),
('principal_targets', 'MODX\\Revolution\\modAccessContext,MODX\\Revolution\\modAccessResourceGroup,MODX\\Revolution\\modAccessCategory,MODX\\Revolution\\Sources\\modAccessMediaSource,MODX\\Revolution\\modAccessNamespace', 'textfield', 'core', 'authentication', NULL),
('proxy_auth_type', 'BASIC', 'textfield', 'core', 'proxy', NULL),
('proxy_host', '', 'textfield', 'core', 'proxy', NULL),
('proxy_password', '', 'text-password', 'core', 'proxy', NULL),
('proxy_port', '', 'numberfield', 'core', 'proxy', NULL),
('proxy_username', '', 'textfield', 'core', 'proxy', NULL),
('publish_default', '', 'combo-boolean', 'core', 'site', NULL),
('quick_search_in_content', '1', 'combo-boolean', 'core', 'manager', NULL),
('quick_search_result_max', '10', 'numberfield', 'core', 'manager', NULL),
('request_controller', 'index.php', 'textfield', 'core', 'gateway', NULL),
('request_method_strict', '', 'combo-boolean', 'core', 'gateway', NULL),
('request_param_alias', 'q', 'textfield', 'core', 'gateway', NULL),
('request_param_id', 'id', 'textfield', 'core', 'gateway', NULL),
('resource_static_allow_absolute', '0', 'combo-boolean', 'core', 'static_resources', NULL),
('resource_static_path', '{assets_path}', 'textfield', 'core', 'static_resources', NULL),
('resource_tree_node_name', 'pagetitle', 'textfield', 'core', 'manager', NULL),
('resource_tree_node_name_fallback', 'alias', 'textfield', 'core', 'manager', NULL),
('resource_tree_node_tooltip', '', 'textfield', 'core', 'manager', NULL),
('richtext_default', '1', 'combo-boolean', 'core', 'manager', NULL),
('search_default', '1', 'combo-boolean', 'core', 'site', NULL),
('send_poweredby_header', '', 'combo-boolean', 'core', 'system', NULL),
('server_offset_time', '0', 'numberfield', 'core', 'system', NULL),
('session_cookie_domain', '', 'textfield', 'core', 'session', NULL),
('session_cookie_httponly', '1', 'combo-boolean', 'core', 'session', NULL),
('session_cookie_lifetime', '604800', 'numberfield', 'core', 'session', NULL),
('session_cookie_path', '', 'textfield', 'core', 'session', NULL),
('session_cookie_samesite', '', 'textfield', 'core', 'session', NULL),
('session_cookie_secure', '', 'combo-boolean', 'core', 'session', NULL),
('session_gc_maxlifetime', '604800', 'textfield', 'core', 'session', NULL),
('session_handler_class', 'MODX\\Revolution\\modSessionHandler', 'textfield', 'core', 'session', NULL),
('session_name', '', 'textfield', 'core', 'session', NULL),
('settings_distro', 'traditional', 'textfield', 'core', 'system', NULL),
('settings_version', '3.1.2-pl', 'textfield', 'core', 'system', NULL),
('set_header', '1', 'combo-boolean', 'core', 'system', NULL),
('show_tv_categories_header', '1', 'combo-boolean', 'core', 'manager', NULL),
('site_name', 'Smart Social 2.0', 'textfield', 'core', 'site', '2025-07-17 12:19:05'),
('site_start', '1', 'numberfield', 'core', 'site', NULL),
('site_status', '1', 'combo-boolean', 'core', 'site', NULL),
('site_unavailable_message', '[[%site_unavailable_message]]', 'textfield', 'core', 'site', NULL),
('site_unavailable_page', '0', 'numberfield', 'core', 'site', NULL),
('static_elements_automate_chunks', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_plugins', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_snippets', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_templates', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_tvs', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_basepath', '', 'textfield', 'core', 'static_elements', NULL),
('static_elements_default_category', '0', 'modx-combo-category', 'core', 'static_elements', NULL),
('static_elements_default_mediasource', '0', 'modx-combo-source', 'core', 'static_elements', NULL),
('static_elements_html_extension', '.tpl', 'textfield', 'core', 'static_elements', NULL),
('symlink_merge_fields', '1', 'combo-boolean', 'core', 'site', NULL),
('syncsite_default', '1', 'combo-boolean', 'core', 'caching', NULL),
('telegram-link', 'https://t.me/smartsocialorg', 'textfield', 'core', 'Контакты', NULL),
('telegram-name', 'smartsocialorg', 'textfield', 'core', 'Контакты', NULL),
('tinymcerte.alignment_format', '[{\"title\": \"Left\", \"icon\": \"align-left\", \"format\": \"alignleft\"},{\"title\": \"Center\", \"icon\": \"align-center\", \"format\": \"aligncenter\"},{\"title\": \"Right\", \"icon\": \"align-right\", \"format\": \"alignright\"},{\"title\": \"Justify\", \"icon\": \"align-justify\", \"format\": \"alignjustify\"}]', 'textarea', 'tinymcerte', 'tinymcerte.style_formats', NULL),
('tinymcerte.blocks_format', '[{\"title\": \"Paragraph\", \"format\": \"p\"},{\"title\": \"Blockquote\", \"format\": \"blockquote\"},{\"title\": \"Div\", \"format\": \"div\"},{\"title\": \"Pre\", \"format\": \"pre\"}]', 'textarea', 'tinymcerte', 'tinymcerte.style_formats', NULL),
('tinymcerte.browser_spellcheck', '', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.content_css', '', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.enable_link_list', '1', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.external_config', '', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.headers_format', '[{\"title\": \"Header 1\", \"format\": \"h1\"},{\"title\": \"Header 2\", \"format\": \"h2\"},{\"title\": \"Header 3\", \"format\": \"h3\"},{\"title\": \"Header 4\", \"format\": \"h4\"},{\"title\": \"Header 5\", \"format\": \"h5\"},{\"title\": \"Header 6\", \"format\": \"h6\"}]', 'textarea', 'tinymcerte', 'tinymcerte.style_formats', NULL),
('tinymcerte.image_advtab', '1', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.image_class_list', '', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.inline_format', '[{\"title\": \"Bold\", \"icon\": \"bold\", \"format\": \"bold\"},{\"title\": \"Italic\", \"icon\": \"italic\", \"format\": \"italic\"},{\"title\": \"Underline\", \"icon\": \"underline\", \"format\": \"underline\"},{\"title\": \"Strikethrough\", \"icon\": \"strike-through\", \"format\": \"strikethrough\"},{\"title\": \"Superscript\", \"icon\": \"superscript\", \"format\": \"superscript\"},{\"title\": \"Subscript\", \"icon\": \"subscript\", \"format\": \"subscript\"},{\"title\": \"Code\", \"icon\": \"sourcecode\", \"format\": \"code\"}]', 'textarea', 'tinymcerte', 'tinymcerte.style_formats', NULL),
('tinymcerte.links_across_contexts', '', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.link_class_list', '', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.max_height', '500', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.menubar', 'file edit insert view format table tools', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.modai.global.text.base_prompt', '- This is not a conversation, do not include justifcation, suggestions, or explanation\n- The output should be usable as is, without requiring editing or modification\n- Format it with HTML markup so it will work in the TinyMCE rich text editor', 'textarea', 'tinymcerte', 'modai', NULL),
('tinymcerte.modai.global.text.modify_prompts', '[{\"label\":\"Proofread\",\"prompt\":\"Proofread and fix any spelling or grammar mistakes\"},{\"label\":\"Clarify\",\"prompt\":\"Improve this copy to eliminate unclear thoughts or awkward phrasing\"},{\"label\":\"Length\",\"prompts\":[{\"label\":\"Add a Paragraph\",\"prompt\":\"- Add a paragraph to this copy.\\n- You can rewrite the other copy if it enahances the copy\\n- Format it with HTML markup so it will work in the TinyMCE editor when pasted in.\"},{\"label\":\"Add a Sentence\",\"prompt\":\"- Add a sentence to this copy that will improve it\\n- You can rewrite the other copy if it enahances the copy\\n- Format it with HTML markup so it will work in the TinyMCE editor when pasted in.\"},{\"label\":\"Remove a Sentence\",\"prompt\":\"- Remove a sentence from this copy. Format it with HTML markup so it will work in the TinyMCE editor when pasted in.\"},{\"label\":\"Cut in Half\",\"prompt\":\"- Condense this copy to roughly half of its current length\\n- Maintain important concepts and key topics\\n- Combine or eliminate paragraphs if it makes sense and helps with readability\\n- Format it with HTML markup so it will work in the TinyMCE editor when pasted in.\"}]},{\"label\":\"Reading Level\",\"prompts\":[{\"label\":\"Elementary school\",\"prompt\":\"Rewrite this copy to ensure it is readable at an Elementary school reading level.\"},{\"label\":\"Middle school\",\"prompt\":\"Rewrite this copy to ensure it is readable at a Middle school reading level.\"},{\"label\":\"High school\",\"prompt\":\"Rewrite this copy to ensure it is readable at a High school reading level.\"},{\"label\":\"College\",\"prompt\":\"Rewrite this copy to ensure it is readable at a College reading level.\"}]},{\"label\":\"Change Tone\",\"prompts\":[{\"label\":\"Formal\",\"prompt\":\"Rewrite this with a formal tone.\"},{\"label\":\"Conversational\",\"prompt\":\"Rewrite this with a casual, conversational tone.\"},{\"label\":\"Professional\",\"prompt\":\"Rewrite this with a professional tone.\"},{\"label\":\"Humorous\",\"prompt\":\"Rewrite this with a humorous tone.\"},{\"label\":\"Persuasive\",\"prompt\":\"Rewrite this with an persuasive tone.\"}]},{\"label\":\"Change Style\",\"prompts\":[{\"label\":\"Business\",\"prompt\":\"Rewrite this in a Business style\"},{\"label\":\"Technical\",\"prompt\":\"Rewrite this in a Technical style\"},{\"label\":\"AP Style Manual\",\"prompt\":\"Reformat this to adhere to the AP Style Manual\"},{\"label\":\"Chicago Style Manual\",\"prompt\":\"Reformat this to adhere to the Chicago Style Manual\"},{\"label\":\"David Olgivy\",\"prompt\":\"Rewrite this in the style of the expert ad copywriter David Olgivy\"}]},{\"label\":\"Translate\",\"prompts\":[{\"label\":\"Chinese\",\"prompt\":\"Translate this to Chinese\"},{\"label\":\"Dutch\",\"prompt\":\"Translate this to Dutch\"},{\"label\":\"English (CA)\",\"prompt\":\"Localise or translate this to Canadian English\"},{\"label\":\"English (UK)\",\"prompt\":\"Localise or translate this to British English\"},{\"label\":\"English (US)\",\"prompt\":\"Localize or translate this to American English\"},{\"label\":\"English (RN)\",\"prompt\":\"Localize this to the writing style of someone who lives in rural America and speaks with a lot of slang and colloquialisms like \\\"y\'all\\\" instead of \\\",you all\\\", and \\\"fixin\'\\\" instead of \\\"about to\\\"\"},{\"label\":\"French\",\"prompt\":\"Translate this to French\"},{\"label\":\"German\",\"prompt\":\"Translate this to German\"},{\"label\":\"Italian\",\"prompt\":\"Translate this to Italian\"},{\"label\":\"Japanese\",\"prompt\":\"Translate this to Japanese\"},{\"label\":\"Korean\",\"prompt\":\"Translate this to Korean\"},{\"label\":\"Portuguese (BR)\",\"prompt\":\"Translate this to Brazillian Portugese\"},{\"label\":\"Portuguese (PT)\",\"prompt\":\"Translate this to European Portugese\"},{\"label\":\"Russian\",\"prompt\":\"Translate this to Russian\"},{\"label\":\"Spanish\",\"prompt\":\"Translate this to Spanish\"}]}]', 'textarea', 'tinymcerte', 'modai', NULL),
('tinymcerte.object_resizing', '1', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.paste_as_text', '', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.plugins', 'autoresize advlist autolink lists charmap print preview anchor visualblocks searchreplace code fullscreen insertdatetime media table paste modxlink modximage modai', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.relative_urls', '1', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.remove_script_host', '1', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.settings', '', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.skin', 'modx', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.statusbar', '1', 'combo-boolean', 'tinymcerte', 'tinymcerte.default', NULL),
('tinymcerte.style_formats', '[{\"title\": \"Headers\", \"items\": \"headers_format\"},{\"title\": \"Inline\", \"items\": \"inline_format\"},{\"title\": \"Blocks\", \"items\": \"blocks_format\"},{\"title\": \"Alignment\", \"items\": \"alignment_format\"}]', 'textarea', 'tinymcerte', 'tinymcerte.style_formats', NULL),
('tinymcerte.style_formats_merge', '', 'combo-boolean', 'tinymcerte', 'tinymcerte.style_formats', NULL),
('tinymcerte.toolbar1', 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | modai_generate modai_generate_image modai_enhance', 'textfield', 'tinymcerte', 'tinymcerte.toolbar', NULL),
('tinymcerte.toolbar2', '', 'textfield', 'tinymcerte', 'tinymcerte.toolbar', NULL),
('tinymcerte.toolbar3', '', 'textfield', 'tinymcerte', 'tinymcerte.toolbar', NULL),
('tinymcerte.valid_elements', '', 'textfield', 'tinymcerte', 'tinymcerte.default', NULL),
('topmenu_show_descriptions', '1', 'combo-boolean', 'core', 'manager', NULL),
('tree_default_sort', 'menuindex', 'textfield', 'core', 'manager', NULL),
('tree_root_id', '0', 'numberfield', 'core', 'manager', NULL),
('tvs_below_content', '', 'combo-boolean', 'core', 'manager', NULL),
('unauthorized_page', '1', 'numberfield', 'core', 'site', NULL),
('upload_files', 'aac,au,avi,bmp,css,css.map,doc,docx,eot,gif,gz,htm,html,ico,jpeg,jpg,js,js.map,less,md,mp3,mp4,mpeg,mpg,odb,odf,odg,odp,ods,odt,pdf,png,ppt,pptx,psd,rar,scss,svg,svgz,tar,tgz,tiff,ttf,txt,wav,webp,wmv,woff,woff2,xls,xlsx,xml,z,zip', 'textfield', 'core', 'file', NULL),
('upload_file_exists', '1', 'combo-boolean', 'core', 'file', NULL),
('upload_maxsize', '67108864', 'numberfield', 'core', 'file', '2025-07-17 10:29:56'),
('upload_translit', '1', 'combo-boolean', 'core', 'file', NULL),
('upload_translit_restrict_chars_pattern', '/[\\0\\x0B\\t\\n\\r\\f\\a&=+%#<>\"~:`@\\?\\[\\]\\{\\}\\|\\^\'\\\\]/', 'textfield', 'core', 'file', NULL),
('user_nav_parent', 'usernav', 'textfield', 'core', 'manager', NULL),
('use_alias_path', '', 'combo-boolean', 'core', 'furls', NULL),
('use_context_resource_table', '1', 'combo-boolean', 'core', 'caching', NULL),
('use_editor', '1', 'combo-boolean', 'core', 'editor', NULL),
('use_frozen_parent_uris', '', 'combo-boolean', 'core', 'furls', NULL),
('use_multibyte', '1', 'combo-boolean', 'core', 'language', '2025-07-17 10:29:56'),
('use_weblink_target', '', 'combo-boolean', 'core', 'site', NULL),
('welcome_action', 'welcome', 'textfield', 'core', 'manager', NULL),
('welcome_namespace', 'core', 'textfield', 'core', 'manager', NULL),
('welcome_screen', '', 'combo-boolean', 'core', 'manager', '2025-07-17 10:30:14'),
('welcome_screen_url', '//misc.modx.com/revolution/welcome.31.html', 'textfield', 'core', 'manager', NULL),
('which_editor', 'TinyMCE RTE', 'modx-combo-rte', 'core', 'editor', '2025-07-17 10:55:06'),
('which_element_editor', 'Ace', 'modx-combo-rte', 'core', 'editor', '2025-07-17 10:31:34'),
('xhtml_urls', '1', 'combo-boolean', 'core', 'site', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_transport_packages`
--

CREATE TABLE `modx_transport_packages` (
  `signature` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `installed` datetime DEFAULT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `workspace` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `provider` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `source` tinytext,
  `manifest` text,
  `attributes` mediumtext,
  `package_name` varchar(191) NOT NULL,
  `metadata` text,
  `version_major` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `version_minor` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `version_patch` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `release` varchar(100) NOT NULL DEFAULT '',
  `release_index` smallint(5) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_transport_packages`
--

INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('ace-1.9.3-pl', '2025-07-17 13:30:54', '2025-07-17 10:31:34', '2025-07-17 13:31:34', 0, 1, 1, 0, 'ace-1.9.3-pl.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:271:\"--------------------\nExtra: Ace\n--------------------\nSince: March 29th, 2012\nAuthor: Danil Kostin <danya.postfactum@gmail.com>\nLicense: GNU GPLv2 (or later at your option)\n\nIntegrates Ace Code Editor into MODx Revolution.\n\nPress Ctrl+Alt+H to see all available shortcuts.\";s:9:\"changelog\";s:4624:\"Changelog for Ace integration into MODx Revolution.\n\nAce 1.9.3 [15.05.2022]\n====================================\n- Updated: Move settings into an own file [#12]\n- Fixed: Ace TV input [#11]\n- Fixed: Prevent PHP warning: Undefined variable $field [#10]\n\nAce 1.9.2\n====================================\n- Updated: Corrected search form [#8]\n- Added: TV input Ace field [#9]\n\nAce 1.9.1\n====================================\n- Fixed: Changed fonts\n- Updated: emmet.js with the support flex css styles and many other combinations\n\nAce 1.9.0\n====================================\n- Added: autodetecting file mode by modelist.js [#7]\n- Added: new modes from ace-builds for version 1.2.0\n\nAce 1.8.0\n====================================\n- Added: autocompletion for php functions.\n\nAce 1.7.0\n====================================\n- Added: new system setting \"ace.grow\".\n- Added: new system setting \"ace.html_elements_mime\".\n\nAce 1.6.5\n====================================\n- Added: \"Twig\" syntax for support of Twig in chunks.\n- Changed: Plugin is not static anymore.\n\nAce 1.6.4\n====================================\n- Fixed: Support of emmet in smarty mode. Again.\n\nAce 1.6.3\n====================================\n- Fixed: Support of emmet in smarty mode.\n\nAce 1.6.2\n====================================\n- Fixed: Editor mode handling.\n- Added: \"Markdown\" syntax for mime type \"text/x-markdown\".\n\nAce 1.6.1\n====================================\n- Fixed : Work with enabled system setting \"compress_js\".\n\nAce 1.6.0\n====================================\n- Added: \"Smarty\" syntax for support of Fenom in chunks.\n- Updated: Ace to version 1.2.0.\n\nAce 1.5.1\n====================================\n- Fixed: Bug with narrowing of the textarea.\n\nAce 1.5.0\n====================================\n- Changed: Assets are moved back to /assets/\n- Fixed: MODx tag completions (was completely broken)\n- Added: Editor height setting\n\nAce 1.4.3\n====================================\n- Added: MODx tag completions (Ctrl+Space)\n- Fixed: Issue caused AjaxManager (MODx Manager speed booster plugin) tree drag\'n\'drop bug\n\nAce 1.4.2\n====================================\n- Added: Undo coalescing\n- Changed: Mac fullscreen command is bound to Command+F12\n- Added: Drag delay (allow to start new selection inside current one) for Mac\n- Fixed: Use file extension of static chunks to detect code syntax\n\n\nAce 1.4.1\n====================================\n- Fixed: Tab handling\n- Fixed: Emmet shortcut listing by Ctr+Alt+H\n- Added: Expandable snippets support (see ace.snippets setting)\n- Added: Emmet wrap_with_abbreviation command (Alt+W)\n\nAce 1.4.0\n====================================\n- Added: Emmet (aka Zen Coding) support\n- Added: Terminal dark theme\n- Added: Hotkey table (Ctrl+Alt+H)\n- Fixed: Resource overview fatal error\n- Changed: Assets are moved to /manager/assets/components/\n\nAce 1.3.3\n====================================\n- Added: PHP live syntax check\n- Added: Chaos dark theme\n- Added: Setting show_invisibles\n\n\nAce 1.3.2\n====================================\n- Fixed: The bug while installing the Ace\n- Fixed: Broken word_wrap setting\n- Added: Tab settings (tab size, soft tab)\n- Added: Now completele compatible with AjaxManager extra\n\n\nAce 1.3.1\n====================================\n- Changed: Plugin content now is stored in static file\n\n\nAce 1.3.0\n====================================\n- Added: German translation\n- Added: MODx tags highlighting\n- Added: Ambiance and xcode themes\n- Added: less/scss syntax highlighting\n- Added: Fullwindow mode (Ctrl + F11)\n- Changed: Editor now ignores `wich_editor` setting. Set `use_editor` to false to use ACE for Resources.\n\n\nAce 1.2.1\n====================================\n- Changed: Assets are moved to manager folder\n- Added: Font size setting\n- Added: \"GitHub\" theme\n- Added: Support of html5 drag\'n\'drop (accepting of dropped text)\n- Added: XML / HTML tag autoclosing\n- Fixed: broken en lexicon and php 5.3 incompatibility\n\n\nAce 1.2.0\n====================================\n- Removed: Some unnecessary options\n- Changed: Editor options are moved to system settings\n- Fixed: Multiple little editor bugs\n- Added: Add missing \"OnFileEditFormPrerender\" event to MODx\n- Added: Multiline editing\n- Added: Advanced find/replace window\n\n\nAce 1.1.0\n====================================\n- Fixed: Fatal error on document create event\n- Fixed: Changing of properties has no effect\n- Added: File edition support\n- Added: MODx tree elements drag\'n\'drop support\n- Added: Auto-assigning which_element_editor to Ace\n\n\nAce 1.0.0\n====================================\n- Added: Plugin properties to adjust how Ace behaves\n- Initial commit\";s:9:\"signature\";s:12:\"ace-1.9.3-pl\";s:6:\"action\";s:26:\"Workspace/Packages/Install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:40:\"/workspace/package/install/ace-1.9.3-pl/\";s:14:\"package_action\";i:0;}', 'Ace', 'a:38:{s:2:\"id\";s:36:\"99066886-9dc8-4443-85ae-85953c2cc1b9\";s:7:\"package\";s:36:\"9906673c-127f-4765-ad53-d741a99978c1\";s:12:\"display_name\";s:12:\"ace-1.9.3-pl\";s:4:\"name\";s:3:\"Ace\";s:7:\"version\";s:5:\"1.9.3\";s:13:\"version_major\";s:1:\"1\";s:13:\"version_minor\";s:1:\"9\";s:13:\"version_patch\";s:1:\"3\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:0:\"\";s:6:\"author\";s:16:\"danya_postfactum\";s:11:\"description\";s:376:\"<p>New feature: modx tag code autocompletion! Press Ctrl+Space to get code suggestions with descriptions.</p><p>Works for snippets, chunks, system settings, tvs and resource fields, filters and properties.</p><p>Property sets, lexicon entries are not supported. Unfortunately, I have no idea how to retrieve chunk-specific placeholders, so there is no placeholder support.</p>\";s:12:\"instructions\";s:341:\"<p></p><p>Install via Package Management.</p><p>Set editor theme you wish in system settings (change namespace to \"ace\").</p><p>If you want to use this editor for resources, just set system option <i>use_editor</i> to <b>false</b> (global usage), or <i>richtext</i> setting of certain resource to <b>false</b> (specific usage).</p><p></p>\";s:9:\"changelog\";s:4571:\"Ace 1.9.3 [15.05.2022]\n====================================\n- Updated: Move settings into an own file [#12]\n- Fixed: Ace TV input [#11]\n- Fixed: Prevent PHP warning: Undefined variable $field [#10]\n\nAce 1.9.2\n====================================\n- Updated: Corrected search form [#8]\n- Added: TV input Ace field [#9]\n\nAce 1.9.1\n====================================\n- Fixed: Changed fonts\n- Updated: emmet.js with the support flex css styles and many other combinations\n\nAce 1.9.0\n====================================\n- Added: autodetecting file mode by modelist.js [#7]\n- Added: new modes from ace-builds for version 1.2.0\n\nAce 1.8.0\n====================================\n- Added: autocompletion for php functions.\n\nAce 1.7.0\n====================================\n- Added: new system setting \"ace.grow\".\n- Added: new system setting \"ace.html_elements_mime\".\n\nAce 1.6.5\n====================================\n- Added: \"Twig\" syntax for support of Twig in chunks.\n- Changed: Plugin is not static anymore.\n\nAce 1.6.4\n====================================\n- Fixed: Support of emmet in smarty mode. Again.\n\nAce 1.6.3\n====================================\n- Fixed: Support of emmet in smarty mode.\n\nAce 1.6.2\n====================================\n- Fixed: Editor mode handling.\n- Added: \"Markdown\" syntax for mime type \"text/x-markdown\".\n\nAce 1.6.1\n====================================\n- Fixed : Work with enabled system setting \"compress_js\".\n\nAce 1.6.0\n====================================\n- Added: \"Smarty\" syntax for support of Fenom in chunks.\n- Updated: Ace to version 1.2.0.\n\nAce 1.5.1\n====================================\n- Fixed: Bug with narrowing of the textarea.\n\nAce 1.5.0\n====================================\n- Changed: Assets are moved back to /assets/\n- Fixed: MODx tag completions (was completely broken)\n- Added: Editor height setting\n\nAce 1.4.3\n====================================\n- Added: MODx tag completions (Ctrl+Space)\n- Fixed: Issue caused AjaxManager (MODx Manager speed booster plugin) tree drag\'n\'drop bug\n\nAce 1.4.2\n====================================\n- Added: Undo coalescing\n- Changed: Mac fullscreen command is bound to Command+F12\n- Added: Drag delay (allow to start new selection inside current one) for Mac\n- Fixed: Use file extension of static chunks to detect code syntax\n\n\nAce 1.4.1\n====================================\n- Fixed: Tab handling\n- Fixed: Emmet shortcut listing by Ctr+Alt+H\n- Added: Expandable snippets support (see ace.snippets setting)\n- Added: Emmet wrap_with_abbreviation command (Alt+W)\n\nAce 1.4.0\n====================================\n- Added: Emmet (aka Zen Coding) support\n- Added: Terminal dark theme\n- Added: Hotkey table (Ctrl+Alt+H)\n- Fixed: Resource overview fatal error\n- Changed: Assets are moved to /manager/assets/components/\n\nAce 1.3.3\n====================================\n- Added: PHP live syntax check\n- Added: Chaos dark theme\n- Added: Setting show_invisibles\n\n\nAce 1.3.2\n====================================\n- Fixed: The bug while installing the Ace\n- Fixed: Broken word_wrap setting\n- Added: Tab settings (tab size, soft tab)\n- Added: Now completele compatible with AjaxManager extra\n\n\nAce 1.3.1\n====================================\n- Changed: Plugin content now is stored in static file\n\n\nAce 1.3.0\n====================================\n- Added: German translation\n- Added: MODx tags highlighting\n- Added: Ambiance and xcode themes\n- Added: less/scss syntax highlighting\n- Added: Fullwindow mode (Ctrl + F11)\n- Changed: Editor now ignores `wich_editor` setting. Set `use_editor` to false to use ACE for Resources.\n\n\nAce 1.2.1\n====================================\n- Changed: Assets are moved to manager folder\n- Added: Font size setting\n- Added: \"GitHub\" theme\n- Added: Support of html5 drag\'n\'drop (accepting of dropped text)\n- Added: XML / HTML tag autoclosing\n- Fixed: broken en lexicon and php 5.3 incompatibility\n\n\nAce 1.2.0\n====================================\n- Removed: Some unnecessary options\n- Changed: Editor options are moved to system settings\n- Fixed: Multiple little editor bugs\n- Added: Add missing \"OnFileEditFormPrerender\" event to MODx\n- Added: Multiline editing\n- Added: Advanced find/replace window\n\n\nAce 1.1.0\n====================================\n- Fixed: Fatal error on document create event\n- Fixed: Changing of properties has no effect\n- Added: File edition support\n- Added: MODx tree elements drag\'n\'drop support\n- Added: Auto-assigning which_element_editor to Ace\n\n\nAce 1.0.0\n====================================\n- Added: Plugin properties to adjust how Ace behaves\n- Initial commit\";s:9:\"createdon\";s:25:\"2022-05-15T03:38:35+00:00\";s:9:\"createdby\";s:10:\"ibochkarev\";s:8:\"editedon\";s:25:\"2023-05-04T19:23:53+00:00\";s:10:\"releasedon\";s:25:\"2022-05-15T03:38:35+00:00\";s:9:\"downloads\";s:6:\"370472\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:4:\"true\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:36:\"9861b09b-7176-455b-a9c1-bb7728924ad8\";s:8:\"supports\";s:3:\"2.0\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=99066886-9dc8-4443-85ae-85953c2cc1b9&uuid=b4ed6906-0048-4056-9298-8e85189b1d94\";s:9:\"signature\";s:12:\"ace-1.9.3-pl\";s:11:\"supports_db\";s:0:\"\";s:16:\"minimum_supports\";s:3:\"2.0\";s:9:\"breaks_at\";s:5:\"100.0\";s:10:\"screenshot\";s:0:\"\";s:4:\"file\";a:7:{s:2:\"id\";s:36:\"99066886-9dc8-4443-85ae-85953c2cc1b9\";s:7:\"version\";s:36:\"99066886-9dc8-4443-85ae-85953c2cc1b9\";s:8:\"filename\";s:26:\"ace-1.9.3-pl.transport.zip\";s:9:\"downloads\";s:5:\"35828\";s:6:\"lastip\";s:12:\"94.46.148.33\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=99066886-9dc8-4443-85ae-85953c2cc1b9&uuid=b4ed6906-0048-4056-9298-8e85189b1d94\";}s:17:\"package-signature\";s:12:\"ace-1.9.3-pl\";s:10:\"categories\";s:15:\"richtexteditors\";s:4:\"tags\";s:0:\"\";}', 1, 9, 3, 'pl', 0);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('migx-3.0.2-beta1', '2025-07-17 13:30:36', '2025-07-17 10:31:42', '2025-07-17 13:31:42', 0, 1, 1, 0, 'migx-3.0.2-beta1.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15504:\"GNU GENERAL PUBLIC LICENSE\r\n   Version 2, June 1991\r\n--------------------------\r\n\r\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\r\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\r\n\r\nEveryone is permitted to copy and distribute verbatim copies\r\nof this license document, but changing it is not allowed.\r\n\r\nPreamble\r\n--------\r\n\r\n  The licenses for most software are designed to take away your\r\nfreedom to share and change it.  By contrast, the GNU General Public\r\nLicense is intended to guarantee your freedom to share and change free\r\nsoftware--to make sure the software is free for all its users.  This\r\nGeneral Public License applies to most of the Free Software\r\nFoundation\'s software and to any other program whose authors commit to\r\nusing it.  (Some other Free Software Foundation software is covered by\r\nthe GNU Library General Public License instead.)  You can apply it to\r\nyour programs, too.\r\n\r\n  When we speak of free software, we are referring to freedom, not\r\nprice.  Our General Public Licenses are designed to make sure that you\r\nhave the freedom to distribute copies of free software (and charge for\r\nthis service if you wish), that you receive source code or can get it\r\nif you want it, that you can change the software or use pieces of it\r\nin new free programs; and that you know you can do these things.\r\n\r\n  To protect your rights, we need to make restrictions that forbid\r\nanyone to deny you these rights or to ask you to surrender the rights.\r\nThese restrictions translate to certain responsibilities for you if you\r\ndistribute copies of the software, or if you modify it.\r\n\r\n  For example, if you distribute copies of such a program, whether\r\ngratis or for a fee, you must give the recipients all the rights that\r\nyou have.  You must make sure that they, too, receive or can get the\r\nsource code.  And you must show them these terms so they know their\r\nrights.\r\n\r\n  We protect your rights with two steps: (1) copyright the software, and\r\n(2) offer you this license which gives you legal permission to copy,\r\ndistribute and/or modify the software.\r\n\r\n  Also, for each author\'s protection and ours, we want to make certain\r\nthat everyone understands that there is no warranty for this free\r\nsoftware.  If the software is modified by someone else and passed on, we\r\nwant its recipients to know that what they have is not the original, so\r\nthat any problems introduced by others will not reflect on the original\r\nauthors\' reputations.\r\n\r\n  Finally, any free program is threatened constantly by software\r\npatents.  We wish to avoid the danger that redistributors of a free\r\nprogram will individually obtain patent licenses, in effect making the\r\nprogram proprietary.  To prevent this, we have made it clear that any\r\npatent must be licensed for everyone\'s free use or not licensed at all.\r\n\r\n  The precise terms and conditions for copying, distribution and\r\nmodification follow.\r\n\r\n\r\nGNU GENERAL PUBLIC LICENSE\r\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\r\n---------------------------------------------------------------\r\n\r\n  0. This License applies to any program or other work which contains\r\na notice placed by the copyright holder saying it may be distributed\r\nunder the terms of this General Public License.  The \"Program\", below,\r\nrefers to any such program or work, and a \"work based on the Program\"\r\nmeans either the Program or any derivative work under copyright law:\r\nthat is to say, a work containing the Program or a portion of it,\r\neither verbatim or with modifications and/or translated into another\r\nlanguage.  (Hereinafter, translation is included without limitation in\r\nthe term \"modification\".)  Each licensee is addressed as \"you\".\r\n\r\nActivities other than copying, distribution and modification are not\r\ncovered by this License; they are outside its scope.  The act of\r\nrunning the Program is not restricted, and the output from the Program\r\nis covered only if its contents constitute a work based on the\r\nProgram (independent of having been made by running the Program).\r\nWhether that is true depends on what the Program does.\r\n\r\n  1. You may copy and distribute verbatim copies of the Program\'s\r\nsource code as you receive it, in any medium, provided that you\r\nconspicuously and appropriately publish on each copy an appropriate\r\ncopyright notice and disclaimer of warranty; keep intact all the\r\nnotices that refer to this License and to the absence of any warranty;\r\nand give any other recipients of the Program a copy of this License\r\nalong with the Program.\r\n\r\nYou may charge a fee for the physical act of transferring a copy, and\r\nyou may at your option offer warranty protection in exchange for a fee.\r\n\r\n  2. You may modify your copy or copies of the Program or any portion\r\nof it, thus forming a work based on the Program, and copy and\r\ndistribute such modifications or work under the terms of Section 1\r\nabove, provided that you also meet all of these conditions:\r\n\r\n    a) You must cause the modified files to carry prominent notices\r\n    stating that you changed the files and the date of any change.\r\n\r\n    b) You must cause any work that you distribute or publish, that in\r\n    whole or in part contains or is derived from the Program or any\r\n    part thereof, to be licensed as a whole at no charge to all third\r\n    parties under the terms of this License.\r\n\r\n    c) If the modified program normally reads commands interactively\r\n    when run, you must cause it, when started running for such\r\n    interactive use in the most ordinary way, to print or display an\r\n    announcement including an appropriate copyright notice and a\r\n    notice that there is no warranty (or else, saying that you provide\r\n    a warranty) and that users may redistribute the program under\r\n    these conditions, and telling the user how to view a copy of this\r\n    License.  (Exception: if the Program itself is interactive but\r\n    does not normally print such an announcement, your work based on\r\n    the Program is not required to print an announcement.)\r\n\r\nThese requirements apply to the modified work as a whole.  If\r\nidentifiable sections of that work are not derived from the Program,\r\nand can be reasonably considered independent and separate works in\r\nthemselves, then this License, and its terms, do not apply to those\r\nsections when you distribute them as separate works.  But when you\r\ndistribute the same sections as part of a whole which is a work based\r\non the Program, the distribution of the whole must be on the terms of\r\nthis License, whose permissions for other licensees extend to the\r\nentire whole, and thus to each and every part regardless of who wrote it.\r\n\r\nThus, it is not the intent of this section to claim rights or contest\r\nyour rights to work written entirely by you; rather, the intent is to\r\nexercise the right to control the distribution of derivative or\r\ncollective works based on the Program.\r\n\r\nIn addition, mere aggregation of another work not based on the Program\r\nwith the Program (or with a work based on the Program) on a volume of\r\na storage or distribution medium does not bring the other work under\r\nthe scope of this License.\r\n\r\n  3. You may copy and distribute the Program (or a work based on it,\r\nunder Section 2) in object code or executable form under the terms of\r\nSections 1 and 2 above provided that you also do one of the following:\r\n\r\n    a) Accompany it with the complete corresponding machine-readable\r\n    source code, which must be distributed under the terms of Sections\r\n    1 and 2 above on a medium customarily used for software interchange; or,\r\n\r\n    b) Accompany it with a written offer, valid for at least three\r\n    years, to give any third party, for a charge no more than your\r\n    cost of physically performing source distribution, a complete\r\n    machine-readable copy of the corresponding source code, to be\r\n    distributed under the terms of Sections 1 and 2 above on a medium\r\n    customarily used for software interchange; or,\r\n\r\n    c) Accompany it with the information you received as to the offer\r\n    to distribute corresponding source code.  (This alternative is\r\n    allowed only for noncommercial distribution and only if you\r\n    received the program in object code or executable form with such\r\n    an offer, in accord with Subsection b above.)\r\n\r\nThe source code for a work means the preferred form of the work for\r\nmaking modifications to it.  For an executable work, complete source\r\ncode means all the source code for all modules it contains, plus any\r\nassociated interface definition files, plus the scripts used to\r\ncontrol compilation and installation of the executable.  However, as a\r\nspecial exception, the source code distributed need not include\r\nanything that is normally distributed (in either source or binary\r\nform) with the major components (compiler, kernel, and so on) of the\r\noperating system on which the executable runs, unless that component\r\nitself accompanies the executable.\r\n\r\nIf distribution of executable or object code is made by offering\r\naccess to copy from a designated place, then offering equivalent\r\naccess to copy the source code from the same place counts as\r\ndistribution of the source code, even though third parties are not\r\ncompelled to copy the source along with the object code.\r\n\r\n  4. You may not copy, modify, sublicense, or distribute the Program\r\nexcept as expressly provided under this License.  Any attempt\r\notherwise to copy, modify, sublicense or distribute the Program is\r\nvoid, and will automatically terminate your rights under this License.\r\nHowever, parties who have received copies, or rights, from you under\r\nthis License will not have their licenses terminated so long as such\r\nparties remain in full compliance.\r\n\r\n  5. You are not required to accept this License, since you have not\r\nsigned it.  However, nothing else grants you permission to modify or\r\ndistribute the Program or its derivative works.  These actions are\r\nprohibited by law if you do not accept this License.  Therefore, by\r\nmodifying or distributing the Program (or any work based on the\r\nProgram), you indicate your acceptance of this License to do so, and\r\nall its terms and conditions for copying, distributing or modifying\r\nthe Program or works based on it.\r\n\r\n  6. Each time you redistribute the Program (or any work based on the\r\nProgram), the recipient automatically receives a license from the\r\noriginal licensor to copy, distribute or modify the Program subject to\r\nthese terms and conditions.  You may not impose any further\r\nrestrictions on the recipients\' exercise of the rights granted herein.\r\nYou are not responsible for enforcing compliance by third parties to\r\nthis License.\r\n\r\n  7. If, as a consequence of a court judgment or allegation of patent\r\ninfringement or for any other reason (not limited to patent issues),\r\nconditions are imposed on you (whether by court order, agreement or\r\notherwise) that contradict the conditions of this License, they do not\r\nexcuse you from the conditions of this License.  If you cannot\r\ndistribute so as to satisfy simultaneously your obligations under this\r\nLicense and any other pertinent obligations, then as a consequence you\r\nmay not distribute the Program at all.  For example, if a patent\r\nlicense would not permit royalty-free redistribution of the Program by\r\nall those who receive copies directly or indirectly through you, then\r\nthe only way you could satisfy both it and this License would be to\r\nrefrain entirely from distribution of the Program.\r\n\r\nIf any portion of this section is held invalid or unenforceable under\r\nany particular circumstance, the balance of the section is intended to\r\napply and the section as a whole is intended to apply in other\r\ncircumstances.\r\n\r\nIt is not the purpose of this section to induce you to infringe any\r\npatents or other property right claims or to contest validity of any\r\nsuch claims; this section has the sole purpose of protecting the\r\nintegrity of the free software distribution system, which is\r\nimplemented by public license practices.  Many people have made\r\ngenerous contributions to the wide range of software distributed\r\nthrough that system in reliance on consistent application of that\r\nsystem; it is up to the author/donor to decide if he or she is willing\r\nto distribute software through any other system and a licensee cannot\r\nimpose that choice.\r\n\r\nThis section is intended to make thoroughly clear what is believed to\r\nbe a consequence of the rest of this License.\r\n\r\n  8. If the distribution and/or use of the Program is restricted in\r\ncertain countries either by patents or by copyrighted interfaces, the\r\noriginal copyright holder who places the Program under this License\r\nmay add an explicit geographical distribution limitation excluding\r\nthose countries, so that distribution is permitted only in or among\r\ncountries not thus excluded.  In such case, this License incorporates\r\nthe limitation as if written in the body of this License.\r\n\r\n  9. The Free Software Foundation may publish revised and/or new versions\r\nof the General Public License from time to time.  Such new versions will\r\nbe similar in spirit to the present version, but may differ in detail to\r\naddress new problems or concerns.\r\n\r\nEach version is given a distinguishing version number.  If the Program\r\nspecifies a version number of this License which applies to it and \"any\r\nlater version\", you have the option of following the terms and conditions\r\neither of that version or of any later version published by the Free\r\nSoftware Foundation.  If the Program does not specify a version number of\r\nthis License, you may choose any version ever published by the Free Software\r\nFoundation.\r\n\r\n  10. If you wish to incorporate parts of the Program into other free\r\nprograms whose distribution conditions are different, write to the author\r\nto ask for permission.  For software which is copyrighted by the Free\r\nSoftware Foundation, write to the Free Software Foundation; we sometimes\r\nmake exceptions for this.  Our decision will be guided by the two goals\r\nof preserving the free status of all derivatives of our free software and\r\nof promoting the sharing and reuse of software generally.\r\n\r\nNO WARRANTY\r\n-----------\r\n\r\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\r\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\r\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\r\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\r\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\r\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\r\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\r\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\r\nREPAIR OR CORRECTION.\r\n\r\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\r\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\r\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\r\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\r\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\r\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\r\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\r\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\r\nPOSSIBILITY OF SUCH DAMAGES.\r\n\r\n---------------------------\r\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:1439:\"--------------------\r\nMIGX\r\n--------------------\r\nVersion: 2.1.0\r\nAuthor: Bruno Perner <b.perner@gmx.de>\r\n--------------------\r\n\r\n* MIGX (multiItemsGridTv for modx) is a custom-tv-input-type for adding multiple items into one TV-value and a snippet for listing this items on your frontend.\r\n* It has a configurable grid and a configurable tabbed editor-window to add and edit items.\r\n* Each item can have multiple fields. For each field you can use another tv-input-type.\r\n\r\nFeel free to suggest ideas/improvements/bugs on GitHub:\r\nhttp://github.com/Bruno17/multiItemsGridTV/issues\r\n\r\nInstallation:\r\n\r\ninstall by package-management.\r\nCreate a new menu:\r\nSystem -> Actions \r\n\r\nActions-tree:\r\nmigx -> right-click -> create Acton here\r\ncontroller: index\r\nnamespace: migx\r\nlanguage-topics: migx:default,file\r\n\r\nmenu-tree:\r\nComponents -> right-click -> place action here\r\nlexicon-key: migx\r\naction: migx - index\r\nparameters: &configs=migxconfigs||packagemanager||setup\r\n\r\nclear cache\r\ngo to components -> migx -> setup-tab -> setup\r\n\r\nIf you are upgrading from MIGX - versions before 2.0\r\ngo to tab upgrade. click upgrade.\r\nThis will add a new autoincrementing field MIGX_id to all your MIGX-TV-items\r\nThe getImageList-snippet needs this field to work correctly.\r\n\r\n\r\nAllways after upgrading MIGX of any Version:\r\ngo to components -> migx -> setup-tab -> setup\r\n\r\nthis will upgrade the migx-configs-table and add new fields, if necessary.\r\n\r\n\r\n\";s:9:\"changelog\";s:12265:\"Changelog for MIGX.\r\n\r\nMIGX 3.0.2\r\n==========\r\nfix some MODX 3 and PHP 8 compatibility and more issues\r\n\r\nMIGX 2.13.0\r\n==============\r\nadd snippet migxGetObject and property toPlaceholders\r\nadd property createChunk to create a chunk with all possible placeholders\r\nFix imageupload on PHP7 due to stray break statement\r\nFix for missing custom prefix in some packagemanager tasks\r\nUpdated image paths to use dynamic assets path\r\nFix the export if a join setting exist\r\nFinnish Translation\r\nadd userid to migxResourceMediapath snippet\r\nremove duplicate sort scriptProperty in export.php\r\n[getlist.php] add getcustomconfigs - hook, groupby, selectfields, specialfields\r\nparse MODX-tags in field-configs\r\npackagemanager fix new folder permission\r\nUse a textarea instead of an input in MIGX TV\r\nReduce indexed varchar fields for utf8mb4 support in mysql\r\nfix duplicate entries in csv-export\r\nAdd CSV Import functionality\r\nImprove CSV Export functionality\r\nadd toJson property to migxLoopCollection\r\nFix transparency in .png in renderimage column renderer\r\nOptimize loadfromxource functionality, especially for MIGX within MIGXdb\r\ndeep nested saving when nested windows are open and saving without closing the window\r\nexport/import single MIGX - items\r\n\r\nMIGX 2.12.0\r\n==============\r\nselect db-fields from defined class and its joins for formtabs and columns\r\nadd categories and a category-filter to MIGX Configs\r\nmultiple grouping-levels for &groupingField\r\nhooksnippet getformnames\r\nadd snippet migxAutoPublish for publishing by Cronjobs\r\nadd beforesave - hook to update-processor\r\nallow string in where-property\r\nadd a default schema-template, used at create package\r\nand some bugfixes\r\n\r\nMIGX 2.11.0\r\n==============\r\ngroupingfield, preparesnippet, _total, _count, improve @CODE\r\nhooksnippet beforecreateform\r\n\r\nMIGX 2.10.0\r\n==============\r\nhooksnippet getcustomconfigs for importcsvmigx\r\nsupport layout-rows/columns in formtabs\r\ncontextmenu \'flat formtabs\'\r\nmultiupload to db, resizeOnUpload - plugin\r\n[packagemanager] Add Extension Package - feature\r\nrespect joinalias in export.php and handlepositionselector.php\r\npossible to use TV-value in migxresourcemediapath - snippet\r\n[getImageList] inherit_children_tvname\r\nMIGXdb add item before/after\r\n\r\nMIGX 2.9.7\r\n==============\r\nadd emtpyTpl\r\nfix some MIGX-grid width - issues\r\nimport csv to MIGX\r\n\r\nMIGX 2.9.6\r\n==============\r\nhooksnippet getcustomconfigs for export-processor\r\nfix missing formtabs after saving\r\n\r\nMIGX 2.9.5\r\n==============\r\ncolumn-actionbuttons also for MIGX\r\nexport/import MIGX-items from/into MIGX-TV\r\nget tinymcewrapper working\r\nmore config-options for combo-filter\r\nFix and simplify Redactor implementation to use MODx.loadRTE()\r\n\r\nMIGX 2.9.4\r\n==============\r\n[migxResourcemediapath] add context_key as path option\r\nbutton for \'alter fields from schema\'\r\nfix MIGX-grid width\r\ncustom grid for MIGX-TV\r\nrespect context-default-media-source - setting\r\n\r\nMIGX 2.9.3\r\n==============\r\nbasic support for new TinyMCE RTE\r\nfix assetsUrl/connectorUrl - settings\r\nMIGX-TV MODX multifile-uploader/autocreate items  \r\nMIGX-TV configurable contextmenues\r\n\r\nMIGX 2.9.2\r\n==============\r\nsome smaller fixes\r\n\r\nMIGX 2.9.1\r\n==============\r\nadd hook-snippet setting\r\nsome handleRelated - update - functions\r\ndestroy updatewindow on close\r\n\r\nMIGX 2.9\r\n==============\r\n[migxLoopCollection] allow use of foreign database\r\nSottwell\'s improvements on migxresourcemediapath\r\nnew snippet: migxGetCollectionTree\r\naccess to foreign database from default processors\r\nimprovements on multiple formtabs\r\nmake inline-editing for MIGX - grid possible\r\noption to add MIGX-items directly without modal\r\nlistbox-cell-editor\r\nmovetotop,movetobottom - buttons for MIGX-grid\r\ncell-editing for MIgXdb - grids\r\noption to add MIGXdb-items directly without modal\r\n[getImageList] &inheritFrom - inherit MIGX-items from parents or other resources\r\nsome migxredactor - fixes \r\n\r\nMIGX 2.8.1\r\n==============\r\nlets disable the \'Add Item\' - button\r\nnew configs gridperpage and sortconfig\r\nwrapperTpl for getImageList and migxLoopCollection\r\n\r\nMIGX 2.8.0\r\n==============\r\nresolve tables on install\r\nrender cross, also when empty string\r\nreusable activaterelations - processors\r\n[migxLoopCollection] tpl_nN\r\n[#154] clean TV-value, if no MIGX-items \r\nadditional db-storage of formtabs and fields\r\nget menue working in MODX 2.3\r\nimprove description_is_code \r\n\r\n\r\nMIGX 2.6.8\r\n==============\r\nsome other small fixes\r\nrestrictive condition by processed MIGX-tags for formfields\r\nFilter-Button for Reset all filters to default-value\r\nextend date-filter\r\nmake cmp main caption translatable \r\nMigx::prepareJoins - optional rightjoin \r\n\r\nMIGX 2.6.7\r\n==============\r\nadd date - filter \r\nadd handlepositionselector - processor \r\nadd snippet exportmigx2db\r\n\r\nMIGX 2.6.6\r\n==============\r\nfixes only\r\n\r\nMIGX 2.6.5\r\n==============\r\nfixes only\r\n\r\nMIGX 2.6.4\r\n==============\r\n[redactor-field] get and use file-properties from a redactor-inputTV\r\nadd renderImageFromHtml - renderer\r\n\r\nMIGX 2.6.3\r\n==============\r\nconfigurable redactor-field with configs-configuration, make redactor work in MIGXdb - CMP\r\n\r\nMIGX 2.6.2\r\n==============\r\nfix issue with imported configs-field, if not an array \r\n\r\nMIGX 2.6.1\r\n==============\r\nMake Formfields translatable\r\n\r\nMIGX 2.6\r\n==============\r\n[getImageList] output inner arrays as json-string\r\nadded polish translation\r\n[getImageList] splits, build summaries\r\n make grid-columns translatable, let user add custom-lexicons from custom php-config-files \r\n\r\n\r\nMIGX 2.5.11\r\n==============\r\nadd simple MIGXdb - validation (only required for now)\r\nsome fixes\r\n\r\n\r\nMIGX 2.5.9\r\n==============\r\nlet us create new indexes, with altered field-def from schema \r\noptimize input-option-values-handling, see:http://forums.modx.com/thread/79757/sortable-editable-list-of-checkboxes?page=4#dis-post-483240\r\n\r\n\r\nMIGX 2.5.8\r\n\r\n==============\r\nAdded \'showScreenshot\' (big image in popup) \r\nAdded template-field for direct template-input for renderChunk\r\nAdded position - selector for new MIGX - items\r\nFix for not removed rte-editors when using formswitcher\r\nsend current store-params to iframe-window\r\n\r\n\r\nMIGX 2.5.6\r\n\r\n==============\r\n\r\nAdd support for the modmore.com Redactor editor \r\nsome work on multiuploader for MIGXdb\r\nmore eNotice - fixes\r\n\r\n\r\nMIGX 2.5.2\r\n\r\n==============\r\nread input-options into MIGX-TV\r\nrespect filter in default - export.php\r\nfix for empty value in TV - configs not loading renderers etc.\r\nfix changed processaction-param after export2csv \r\nstopEvent() by onClick - event\r\n\r\nMIGX 2.5.1\r\n\r\n==============\r\nfix bug with renderChunk - renderer\r\n\r\nMIGX 2.5\r\n\r\n==============\r\nget different rtes working - support for tinymce, ckeditor \r\nsome settings for MIGXfe\r\ncs - lexicons, \r\nsome eNotice - fixes\r\nfix with to big integers on TV-id (set phptype to string)\r\nlimit MIGX-record-count\r\n\r\n\r\nMIGX 2.4.2\r\n\r\n==============\r\ncolumnButtons for the migx - grid \r\nlittle form-layout-mods\r\nadded the option to have the first formtab outside the other tabs above of them.\r\n\r\nadded the option to use the TV-description-field as parsed code-areas in the formtabs, modx-tags are parsed there - \r\nsnippets, chunks, output-filters can be used there. All fields of the record can be used as placeholders.\r\n\r\nmigxupdate for MIGXfe\r\ndefault-values for MIGXdb-filters\r\nupdate co_id in iframe-window\r\nadd a searchbox to MIGX-Configurator\r\nread configs directly from exported configs-files from custom-packages - directory by using configname:packagename - configs\r\n\r\n\r\nMIGX 2.4.1\r\n\r\n==============\r\nsome new snippets:\r\ngetDayliMIGXrecord\r\nmigxgetrelations\r\n\r\nadded beta treecombo-filter-option for example to filter resources in MIGXdb by resourcetree\r\nadd window-title configuration, make window-caption dynamic (its possible to use placeholders now)\r\nhide tabs in form, when only one tab\r\nadded selectposition - renderer\r\n\r\n\r\nMIGX 2.4.0\r\n\r\n==============\r\nnew renderer - switchStatusOptions\r\nnew renderer - renderChunk\r\ngetImageList - added \'contains\' and \'snippet\' - where-filters\r\nadd duplicate-contextmenue to MIGXdb \r\nnew property for getImageList: &reverse\r\ngive TVs in each CMP-tab a unique id\r\nrefresh grid after closing iframe-window\r\nadded tpl_n{n} tplFirst tplLast tpl_n tpl_oneresult properties to getImageList\r\nexport jsonarray-fields as separate fields in csv-export\r\nalias, breadcrumb and ultimateparent for migxREsourceMediaPath\r\nAdded TV - description - field to configuration\r\n\r\n\r\nMIGX 2.3.1\r\n\r\n==============\r\nsome eNotice - error - fixes\r\nadd type - configuration to gridcolumns, now its possible to sort also numeric on the MIGX - grid: see https://github.com/Bruno17/MIGX/issues/41\r\n\r\nMIGX 2.3.0\r\n\r\n==============\r\nadd multifile - uploader, upload to MIGX - mediasource\r\nadd load from mediasource - button to MIGX\r\nadd migxResourcePath - snippet\r\nadd iframe - support - its now possible to create chunks with snippet-calls and show the result in an iframe-window. used by multifile-uploader.\r\n\r\n\r\nMIGX 2.2.3\r\n\r\n==============\r\nconfirmation before overriding schema-files\r\nsome additions for childresources-management by MIGXdb\r\nswitch between multiple forms - configurations\r\nadd renderDate - renderer , thanks to Jako\r\nadditional send all store-baseParams when opening the form-window. This way we can have different forms depending on filters for example.\r\nadd parent-property for dynamic filter-comboboxes\r\nadd getliste-where for default getlist-processor\r\nexport formtabs as clean json in editraw-mode\r\n\r\n\r\nMIGX 2.2.2\r\n\r\n==============\r\nadd migxLoopCollection-snippet\r\nmove prepareJoins into a migx-method\r\nconfirmation before remove db-record, getcombo did not use idfield \r\nallow empty prefix \r\nadd possibility to use tables without \'deleted\' - field and default-getlist-processor\r\nfix Call-time pass-by-reference errors\r\nget tinyMCE to work on richtext-TV-inputs in MIGXdb - CMPs \r\nfix prefix not sended to writeSchema\r\ngrid add cls \'main-wrapper\' to give it a bit padding, thanks to jako\r\n\r\n\r\nMIGX 2.2.0\r\n\r\n==============\r\n\r\nexport/import configuration-objects as json to/from files in custom-package-directories \r\nnew configs: getlist - defaultsort, joins, gridload_mode (by button, auto) \r\ngrid-smarty-template now can be also in custom-package-directories\r\nreworked handling of joined objects in default update-php \r\nadd connected_object_id baseparam to migx-grid\r\nadded snippet migxLoopCollection\r\n\r\n\r\nMIGX 2.1.1\r\n\r\n==============\r\n\r\n  fix for migx-snippet not working with multiple calls on one page\r\n  resource_id as script-property for getlist-processor when used with migx-snippet\r\n\r\nMIGX 2.1.0\r\n\r\n==============\r\n\r\n  add &sort to the getImageList - snippet\r\n  add new snippet \'migx\' to get items from db-tables, can use the same configurations and getList - processors as the MIGXdb - manager\r\n  make it possible to have config-files for grids and processors in another package-folder for easier packaging together custom - packages\r\n  more MIGXdb - configurations\r\n\r\n\r\nMIGX 2.0.1\r\n\r\n==============\r\n\r\n  more E_NOTICE - Error - fixes\r\n  Fix Missing Add - Item - Replacement - String \r\n\r\nMIGX 2.0.0\r\n\r\n==============\r\n\r\n- pl\r\n\r\n  fix for Revo 2.2.2\r\n  fix some E_NOTICE - errors\r\n\r\n- new in beta5\r\n\r\n  Configure multiple CMP - tabs\r\n  packagemanager ported to extjs - tab\r\n  added MIGX-setup/upgrade - tab\r\n  added configurable text and combo - filterboxes\r\n\r\n- new in beta3\r\n\r\n  This is a preview-version of MIGXdb\r\n  MIGXdb can now also be used as configurable CMP\r\n  MIGX - configurator for tabs, columns, MIGXdb-TV and MIGXdb-CMP\r\n  Package-manager, create and edit schemas and package-tables\r\n\r\n- new:\r\n  better compatibility with revo 2.2\r\n  working with mediasources\r\n  introduced MIGXdb\r\n\r\n\r\nMIGX 1.2.0\r\n==============\r\n- new:\r\n  merge scriptProperties to Placeholders \r\n  basic compatibility for modx 2.2 \r\n  autoinc-field: MIGX_id\r\n  autoResourceFolders - functionality, autoCreate directory for each resource\r\n  \r\n  \r\n- fixed:\r\n  url-TV support\r\n  context-based base_path issues\r\n  remove remaining []\r\n  remove Tiny-instances when switching form\r\n  enter on textarea closes window\r\n  fireResourceFormChange for drag,remove,duplicate \r\n\r\nMIGX 1.1.0\r\n==============\r\n- new:\r\n  &docidVarKey\r\n  &processTVs\r\n  \r\n- fixed:\r\n  context-filepath-issue\r\n\r\nMIGX 1.0.0\r\n==============\r\n- Initial release.\";s:9:\"signature\";s:16:\"migx-3.0.2-beta1\";s:6:\"action\";s:26:\"Workspace/Packages/Install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:44:\"/workspace/package/install/migx-3.0.2-beta1/\";s:14:\"package_action\";i:0;}', 'MIGX', 'a:38:{s:2:\"id\";s:36:\"99fb17bd-c7e2-459f-a0e5-a02c162cdb87\";s:7:\"package\";s:36:\"9906672f-bf6a-4575-8ed4-b4998222ede6\";s:12:\"display_name\";s:16:\"migx-3.0.2-beta1\";s:4:\"name\";s:4:\"MIGX\";s:7:\"version\";s:5:\"3.0.2\";s:13:\"version_major\";s:1:\"3\";s:13:\"version_minor\";s:1:\"0\";s:13:\"version_patch\";s:1:\"2\";s:7:\"release\";s:5:\"beta1\";s:8:\"vrelease\";s:4:\"beta\";s:14:\"vrelease_index\";s:1:\"1\";s:6:\"author\";s:7:\"bruno17\";s:11:\"description\";s:672:\"<p>MIGX (multiItemsGridTv for modx) is a custom-tv-input-type for adding multiple items into one TV-value and a snippet for listing this items on your frontend.</p><p>It has a cofigurable grid and a configurable tabbed editor-window to add and edit items.</p><p>Each item can have multiple fields. For each field you can use another tv-input-type.</p><p>MIGXdb can manage (resource-related) custom-db-table-items in a TV and can help to create CMPs for custom-db-tables</p><p>See the official documentation here: <a href=\"http://rtfm.modx.com/display/addon/MIGX\" style=\"color: rgb(15, 112, 150); \" title=\"\" target=\"\">http://rtfm.modx.com/display/addon/MIGX</a></p><p></p>\";s:12:\"instructions\";s:5844:\"<p></p><p style=\"margin: 10px 0px 20px; padding: 0px; border-width: 0px; outline-width: 0px; font-size: 13px; vertical-align: baseline; background-color: transparent; line-height: 1.4;\">Installation:Install via Package Management.</p><p style=\"margin: 10px 0px 20px; padding: 0px; border-width: 0px; outline-width: 0px; font-size: 13px; vertical-align: baseline; background-color: transparent; line-height: 1.4;\">For MIGX and MIGXdb - Configuration - Management:</p><p style=\"margin-top: 10px; margin-right: 0px; margin-bottom: 20px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; line-height: 1.4; background-position: initial initial; background-repeat: initial initial; \">Create a new menu:System -> Actions Actions-tree:migx -> right-click -> create Acton herecontroller: indexnamespace: migxlanguage-topics: migx:default,filemenu-tree:Components -> right-click -> place action herelexicon-key: migxaction: migx - indexparameters: &configs=migxconfigs||packagemanager||setupclear cachego to components -> migx -> setup-tab -> setupIf you are upgrading from MIGX - versions before 2.0go to tab upgrade. click upgrade.This will add a new autoincrementing field MIGX_id to all your MIGX-TV-itemsThe getImageList-snippet needs this field to work correctly.</p><p style=\"margin-top: 10px; margin-right: 0px; margin-bottom: 20px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; line-height: 1.4; background-position: initial initial; background-repeat: initial initial; \"><b style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; background-position: initial initial; background-repeat: initial initial; \">Note:</b> Make sure to remove older versions of multiItemsGridTv and the multiitemsgridTv-namespace, if you had them tried from Github.</p><p style=\"margin-top: 10px; margin-right: 0px; margin-bottom: 20px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; line-height: 1.4; background-position: initial initial; background-repeat: initial initial; \"><b style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; background-position: initial initial; background-repeat: initial initial; \">Note</b>: Input Options for the MIGX only work for Revolution 2.1.0-rc2 and later.</p><p style=\"margin-top: 10px; margin-right: 0px; margin-bottom: 20px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; line-height: 1.4; background-position: initial initial; background-repeat: initial initial; \"></p><p style=\"margin-top: 10px; margin-right: 0px; margin-bottom: 20px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-size: 13px; vertical-align: baseline; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: transparent; line-height: 1.4; background-position: initial initial; background-repeat: initial initial; \"></p>\";s:9:\"changelog\";s:135:\"MIGX 3.0.2\n===========\nfix some MODX 3 and PHP 8 compatibility and more issues\n\nMIGX 3.0.0\n============\nBasic Compatibility for MODX 3\n\";s:9:\"createdon\";s:25:\"2023-08-26T08:05:41+00:00\";s:9:\"createdby\";s:7:\"bruno17\";s:8:\"editedon\";s:25:\"2023-08-26T08:06:47+00:00\";s:10:\"releasedon\";s:25:\"2023-08-26T08:06:47+00:00\";s:9:\"downloads\";s:6:\"283698\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:4:\"true\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:36:\"9861b09b-7176-455b-a9c1-bb7728924ad8\";s:8:\"supports\";s:3:\"2.2\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=99fb17bd-c7e2-459f-a0e5-a02c162cdb87&uuid=b4ed6906-0048-4056-9298-8e85189b1d94\";s:9:\"signature\";s:16:\"migx-3.0.2-beta1\";s:11:\"supports_db\";s:0:\"\";s:16:\"minimum_supports\";s:3:\"2.2\";s:9:\"breaks_at\";s:5:\"100.0\";s:10:\"screenshot\";s:0:\"\";s:4:\"file\";a:7:{s:2:\"id\";s:36:\"99fb17bd-c7e2-459f-a0e5-a02c162cdb87\";s:7:\"version\";s:36:\"99fb17bd-c7e2-459f-a0e5-a02c162cdb87\";s:8:\"filename\";s:30:\"migx-3.0.2-beta1.transport.zip\";s:9:\"downloads\";s:5:\"15132\";s:6:\"lastip\";s:0:\"\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=99fb17bd-c7e2-459f-a0e5-a02c162cdb87&uuid=b4ed6906-0048-4056-9298-8e85189b1d94\";}s:17:\"package-signature\";s:16:\"migx-3.0.2-beta1\";s:10:\"categories\";s:15:\"content,gallery\";s:4:\"tags\";s:46:\"migx,multiitems,multitv,migxdb,CMP,MIGX,MIGXdb\";}', 3, 0, 2, 'beta', 1);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('tinymcerte-2.1.0-pl', '2025-07-17 13:53:12', '2025-07-17 10:55:07', '2025-07-17 13:55:06', 0, 1, 0, 0, 'tinymcerte-2.1.0-pl.transport.zip', NULL, 'a:4:{s:7:\"license\";s:15215:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\n\";s:6:\"readme\";s:639:\"# TinyMCE Rich Text Editor\n\nTinyMCE 5 for MODX Revolution.\n\n- Author: John Peca <john@modx.com>\n- Upgrade to TinyMCE 5: Thomas Jakobi <office@treehillstudio.com>\n- License: GNU GPLv2\n\n## Features\n\nTinyMCE is a platform independent web based Javascript HTML WYSIWYG editor. It\nallows non-technical users to format content without knowing how to code. This\nrelease was done as a companion project for the https://a11y.modx.com to provide\nan accessible RTE. It is based on the TinyMCE 5 code base.\n\n## Installation\n\nMODX Package Management\n\n## Usage\n\nInstall via package manager.\n\n## GitHub Repository\n\nhttps://github.com/modxcms/tinymce-rte\n\";s:9:\"changelog\";s:4918:\"# Changelog\n\nAll notable changes to this project will be documented in this file.\n\nThe format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),\nand this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).\n\n## [2.1.0] - 2025-02-28\n\n### Added\n\n- Add support for modAI\n\n## [2.0.9] - 2022-09-28\n\n### Fixed\n\n- Fix `max_height` system setting not casted right\n\n## [2.0.8] - 2022-08-01\n\n### Added\n\n- Add a default `max_height` system setting to restrict the height of the editor with an enabled `autoresize` plugin\n\n### Fixed\n\n- Fill the TinyMCE `document_base_url` with the `site_url` context setting instead of the `site_url` system setting [#121]\n\n## [2.0.7] - 2022-03-18\n\n### Fixed\n\n- Avoid and log an invalid TinyMCE configuration\n- Get the right manager language in MODX 3.x\n\n## [2.0.6] - 2022-02-16\n\n### Added\n\n- Change `lightgray` skin system setting to `modx` during an update\n- Add `autoresize` plugin per default\n\n## [2.0.5] - 2021-12-27\n\n### Added\n\n- Unescape escaped regex strings (i.e. to allow javascript regex filters in an external config) [#117] \n\n### Fix\n\n- Escape MySQL reserved word rank [#119]\n\n## [2.0.4] - 2021-12-03\n\n### Added\n\n- Load the TinyMCE configuration even if the resource is not using a rich text editor\n- Allow drop of MODX elements to the editor content in richtext template variables\n\n### Fix\n\n- Fix an uncaught type error when the current resource has richtext disabled and uses ContentBlocks\n\n## [2.0.3] - 2021-10-01\n\n### Fix\n\n- Fix setting the link text after selecting a resource\n\n## [2.0.2] - 2021-09-30\n\n### Changed\n\n- Update TinyMCE to 5.9.2\n- Restored compatibility for PHP 7.1 and less\n\n## [2.0.1] - 2021-05-14\n\n### Changed\n\n- Update TinyMCE to 5.8.0\n- Improve the configuration output in the manager html code\n\n### Fixed\n\n- Compatibility with moregallery and Collections\n\n## [2.0.0] - 2021-03-19\n\n### Added\n\n- MODX skintool.json for http://skin.tiny.cloud/t5/\n- MODX 3 compatibility\n- link_list_enable system setting\n\n### Changed\n\n- Upgrade TinyMCE to 5\n- Refactored modxlink TinyMCE plugin to use the nested link_list option\n- Refactored modximage TinyMCE plugin\n- Recursive merge the external config with the config\n- Remove the deprecated file_browser_callback and use the file_picker_callback \n- Allow direct JSON based style_formats items\n\n## [1.4.0] - 2020-09-11\n\n### Added\n\n- Build the modx skin with the internal tinymce grunt workflow\n\n### Changed\n\n- Extend/Fix the modx skin styles\n- Fix an issue with the table tool buttons\n\n## [1.3.4] - 2020-08-12\n\n### Added\n\n- The modx skin extends the lightgray skin, that way the css changes in the lightgray skin are available after a TinyMCE update\n\n### Changed\n\n- Some lexicon changes/improvements\n- Upgrade TinyMCE to 4.9.11\n\n### Removed\n\n- Removed some unnecessary files\n\n## [1.3.3] - 2020-02-04\n\n### Changed\n\n- Bugfix for not using full width when the editor is moved to a new tab [#86]\n- Upgrade TinyMCE to 4.9.7\n\n## [1.3.2] - 2019-06-13\n\n### Changed\n\n- Bugfix for showing only an english user interface\n\n## [1.3.1] - 2019-06-05\n\n### Added\n\n- Added field displaying resource pagetitle of MODX link [#83]\n- Added image_caption option for TinyMCE [#60]\n\n### Changed\n\n- Expanding the locale list [#82]\n- Get settings from a JSON encoded array in tinymcerte.settings system setting\n- Make the entity_encoding configurable [#79]\n- Upgrade TinyMCE to 4.9.4\n\n## [1.3.0] - 2019-05-22\n\n### Added\n\n- Manage TinyMCE release download by npm\n- Add Gruntfile.js that copies the current release of TinyMCE to the corresponding folders\n- Add version info to the registered assets\n- Adding Russian translation\n\n### Changed\n\n- Upgrade TinyMCE to 4.8.3\n\n## [1.2.1] - 2017-12-16\n\n### Added\n\n- Added language strings for the system settings added in 1.2.0\n\n### Changed\n\n- Escaped special HTML chars in the modxlink plugin\n- Fixing \'Media browser does not close when clicking on close\'\n\n## [1.2.0] - 2017-05-21\n\n### Added\n\n- Added `relative_urls` & `remove_script_host` settings\n- Added system setting to define \'valid_elements\'\n- Added \'links_across_contexts\' setting to limit links to the current context resources\n- Added support for configured default Media Source in context settings\n- CMPs can now pass any TinyMCE configuration property using the `OnRichTextEditorInit` system event\n\n### Changed\n\n- Plugin now makes use of `modManagerController::addJavascript` instead of `modX::regClientStartupScript`\n- Upgraded to TinyMCE 4.5.7\n\n## [1.1.1] - 2016-01-20\n\n### Added\n\n- Add tel: prefix\n- Add modximage - left/right image positioning\n- Add modx skin (Credits goes to fourroses666)\n- Add skin system setting\n\n### Changed\n\n- Allow base path parsing in the external_config system setting\n- Sync tinymce and textarea\n\n## [1.1.0] - 2015-07-13\n\n### Added\n\n- Add autocomplete search for links\n- Add external config\n- Support for link classes\n\n## [1.0.0] - 2015-02-23\n\n### Added\n\n- Initial release\n\";s:8:\"requires\";a:2:{s:3:\"php\";s:5:\">=5.6\";s:4:\"modx\";s:5:\">=2.7\";}}', 'tinymcerte', NULL, 2, 1, 0, 'pl', 0),
('tinymcerte-3.1.0-pl', '2025-07-17 13:53:48', '2025-07-17 10:54:36', NULL, 0, 1, 1, 0, 'tinymcerte-3.1.0-pl.transport.zip', NULL, 'a:5:{s:7:\"license\";s:15215:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\n\";s:6:\"readme\";s:693:\"# TinyMCE Rich Text Editor\n\nTinyMCE 6 for MODX Revolution.\n\n- Author: John Peca <john@modx.com>\n- Upgrade to TinyMCE 5: Thomas Jakobi <office@treehillstudio.com>\n- Upgrade to TinyMCE 6: Mat Dave Jones <mat@modx.com>\n- License: GNU GPLv2\n\n## Features\n\nTinyMCE is a platform independent web based Javascript HTML WYSIWYG editor. It\nallows non-technical users to format content without knowing how to code. This\nrelease was done as a companion project for the https://a11y.modx.com to provide\nan accessible RTE. It is based on the TinyMCE 5 code base.\n\n## Installation\n\nMODX Package Management\n\n## Usage\n\nInstall via package manager.\n\n## GitHub Repository\n\nhttps://github.com/modxcms/tinymce-rte\n\";s:9:\"changelog\";s:5704:\"# Changelog\n\nAll notable changes to this project will be documented in this file.\n\nThe format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),\nand this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).\n\n## [3.1.0] - 2025-06-13\n\n### Changed\n\n- Add \"rel\" link field\n- Add system setting \"enable_link_aria\" to show \"aria_label\". \"aria_labelledby\", \"aria_describedby\" and \"id\" in link field\n\n## [3.0.5] - 2025-06-10\n\n### Changed\n\n- Fix issue when multiple links are on the same line\n\n## [3.0.4] - 2025-06-06\n\n### Changed\n\n- Fix z-index issue with MIGX\n- Fix typo on tinymcerte.skin system setting\n\n## [3.0.3] - 2025-06-04\n\n### Changed\n\n- Automatically remove modximage from plugins if still installed\n\n## [3.0.2] - 2025-06-03\n\n### Changed\n\n- Added cache busting\n\n## [3.0.1] - 2025-05-29\n\n### Changed\n\n- Switch to local instance of TinyMCE 6\n\n## [3.0.0] - 2025-05-29\n\n### Changed\n\n- Refactored the project to use TinyMCE 6\n\n## [2.1.1] - 2025-03-21\n\n### Changed\n\n- Update to the newest modAI API\n\n## [2.1.0] - 2025-02-28\n\n### Added\n\n- Add support for modAI\n\n## [2.0.9] - 2022-09-28\n\n### Fixed\n\n- Fix `max_height` system setting not cast right\n\n## [2.0.8] - 2022-08-01\n\n### Added\n\n- Add a default `max_height` system setting to restrict the height of the editor with an enabled `autoresize` plugin\n\n### Fixed\n\n- Fill the TinyMCE `document_base_url` with the `site_url` context setting instead of the `site_url` system setting [#121]\n\n## [2.0.7] - 2022-03-18\n\n### Fixed\n\n- Avoid and log an invalid TinyMCE configuration\n- Get the right manager language in MODX 3.x\n\n## [2.0.6] - 2022-02-16\n\n### Added\n\n- Change `lightgray` skin system setting to `modx` during an update\n- Add `autoresize` plugin per default\n\n## [2.0.5] - 2021-12-27\n\n### Added\n\n- Unescape escaped regex strings (i.e. to allow javascript regex filters in an external config) [#117] \n\n### Fix\n\n- Escape MySQL reserved word rank [#119]\n\n## [2.0.4] - 2021-12-03\n\n### Added\n\n- Load the TinyMCE configuration even if the resource is not using a rich text editor\n- Allow drop of MODX elements to the editor content in richtext template variables\n\n### Fix\n\n- Fix an uncaught type error when the current resource has richtext disabled and uses ContentBlocks\n\n## [2.0.3] - 2021-10-01\n\n### Fix\n\n- Fix setting the link text after selecting a resource\n\n## [2.0.2] - 2021-09-30\n\n### Changed\n\n- Update TinyMCE to 5.9.2\n- Restored compatibility for PHP 7.1 and less\n\n## [2.0.1] - 2021-05-14\n\n### Changed\n\n- Update TinyMCE to 5.8.0\n- Improve the configuration output in the manager html code\n\n### Fixed\n\n- Compatibility with moregallery and Collections\n\n## [2.0.0] - 2021-03-19\n\n### Added\n\n- MODX skintool.json for http://skin.tiny.cloud/t5/\n- MODX 3 compatibility\n- link_list_enable system setting\n\n### Changed\n\n- Upgrade TinyMCE to 5\n- Refactored modxlink TinyMCE plugin to use the nested link_list option\n- Refactored modximage TinyMCE plugin\n- Recursive merge the external config with the config\n- Remove the deprecated file_browser_callback and use the file_picker_callback \n- Allow direct JSON based style_formats items\n\n## [1.4.0] - 2020-09-11\n\n### Added\n\n- Build the modx skin with the internal tinymce grunt workflow\n\n### Changed\n\n- Extend/Fix the modx skin styles\n- Fix an issue with the table tool buttons\n\n## [1.3.4] - 2020-08-12\n\n### Added\n\n- The modx skin extends the lightgray skin, that way the css changes in the lightgray skin are available after a TinyMCE update\n\n### Changed\n\n- Some lexicon changes/improvements\n- Upgrade TinyMCE to 4.9.11\n\n### Removed\n\n- Removed some unnecessary files\n\n## [1.3.3] - 2020-02-04\n\n### Changed\n\n- Bugfix for not using full width when the editor is moved to a new tab [#86]\n- Upgrade TinyMCE to 4.9.7\n\n## [1.3.2] - 2019-06-13\n\n### Changed\n\n- Bugfix for showing only an english user interface\n\n## [1.3.1] - 2019-06-05\n\n### Added\n\n- Added field displaying resource pagetitle of MODX link [#83]\n- Added image_caption option for TinyMCE [#60]\n\n### Changed\n\n- Expanding the locale list [#82]\n- Get settings from a JSON encoded array in tinymcerte.settings system setting\n- Make the entity_encoding configurable [#79]\n- Upgrade TinyMCE to 4.9.4\n\n## [1.3.0] - 2019-05-22\n\n### Added\n\n- Manage TinyMCE release download by npm\n- Add Gruntfile.js that copies the current release of TinyMCE to the corresponding folders\n- Add version info to the registered assets\n- Adding Russian translation\n\n### Changed\n\n- Upgrade TinyMCE to 4.8.3\n\n## [1.2.1] - 2017-12-16\n\n### Added\n\n- Added language strings for the system settings added in 1.2.0\n\n### Changed\n\n- Escaped special HTML chars in the modxlink plugin\n- Fixing \'Media browser does not close when clicking on close\'\n\n## [1.2.0] - 2017-05-21\n\n### Added\n\n- Added `relative_urls` & `remove_script_host` settings\n- Added system setting to define \'valid_elements\'\n- Added \'links_across_contexts\' setting to limit links to the current context resources\n- Added support for configured default Media Source in context settings\n- CMPs can now pass any TinyMCE configuration property using the `OnRichTextEditorInit` system event\n\n### Changed\n\n- Plugin now makes use of `modManagerController::addJavascript` instead of `modX::regClientStartupScript`\n- Upgraded to TinyMCE 4.5.7\n\n## [1.1.1] - 2016-01-20\n\n### Added\n\n- Add tel: prefix\n- Add modximage - left/right image positioning\n- Add modx skin (Credits goes to fourroses666)\n- Add skin system setting\n\n### Changed\n\n- Allow base path parsing in the external_config system setting\n- Sync tinymce and textarea\n\n## [1.1.0] - 2015-07-13\n\n### Added\n\n- Add autocomplete search for links\n- Add external config\n- Support for link classes\n\n## [1.0.0] - 2015-02-23\n\n### Added\n\n- Initial release\n\";s:8:\"requires\";a:2:{s:3:\"php\";s:5:\">=5.6\";s:4:\"modx\";s:5:\">=2.7\";}s:16:\"preexisting_mode\";s:1:\"1\";}', 'TinyMCE Rich Text Editor', 'a:38:{s:2:\"id\";s:36:\"9f2ba4b9-f8fd-414d-a8b0-91994206437a\";s:7:\"package\";s:36:\"9906674e-a7e9-483d-b149-86bece97cae2\";s:12:\"display_name\";s:19:\"tinymcerte-3.1.0-pl\";s:4:\"name\";s:24:\"TinyMCE Rich Text Editor\";s:7:\"version\";s:5:\"3.1.0\";s:13:\"version_major\";s:1:\"3\";s:13:\"version_minor\";s:1:\"1\";s:13:\"version_patch\";s:1:\"0\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:0:\"\";s:6:\"author\";s:8:\"theboxer\";s:11:\"description\";s:340:\"<p>TinyMCE is a platform independent web based Javascript HTML WYSIWYG editor. It allows non-technical users to format content without knowing how to code. This release was done as a companion project for the <a href=\"https://a11y.modx.com\">https://a11y.modx.com</a> to provide an accessible RTE. It is based on the TinyMCE 5 code base.</p>\";s:12:\"instructions\";s:46:\"Download and install via MODX package manager.\";s:9:\"changelog\";s:145:\"- Add \"rel\" link field\n- Add system setting \"enable_link_aria\" to show \"aria_label\". \"aria_labelledby\", \"aria_describedby\" and \"id\" in link field\";s:9:\"createdon\";s:25:\"2025-06-16T18:19:20+00:00\";s:9:\"createdby\";s:7:\"matdave\";s:8:\"editedon\";s:25:\"2025-06-16T18:19:30+00:00\";s:10:\"releasedon\";s:25:\"2025-06-16T18:19:30+00:00\";s:9:\"downloads\";s:6:\"158049\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:4:\"true\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:36:\"9861b09b-7176-455b-a9c1-bb7728924ad8\";s:8:\"supports\";s:3:\"2.7\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=9f2ba4b9-f8fd-414d-a8b0-91994206437a&uuid=b4ed6906-0048-4056-9298-8e85189b1d94\";s:9:\"signature\";s:19:\"tinymcerte-3.1.0-pl\";s:11:\"supports_db\";s:0:\"\";s:16:\"minimum_supports\";s:3:\"2.7\";s:9:\"breaks_at\";s:5:\"100.0\";s:10:\"screenshot\";s:0:\"\";s:4:\"file\";a:7:{s:2:\"id\";s:36:\"9f2ba4b9-f8fd-414d-a8b0-91994206437a\";s:7:\"version\";s:36:\"9f2ba4b9-f8fd-414d-a8b0-91994206437a\";s:8:\"filename\";s:33:\"tinymcerte-3.1.0-pl.transport.zip\";s:9:\"downloads\";s:4:\"1127\";s:6:\"lastip\";s:0:\"\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=9f2ba4b9-f8fd-414d-a8b0-91994206437a&uuid=b4ed6906-0048-4056-9298-8e85189b1d94\";}s:17:\"package-signature\";s:19:\"tinymcerte-3.1.0-pl\";s:10:\"categories\";s:15:\"richtexteditors\";s:4:\"tags\";s:0:\"\";}', 3, 1, 0, 'pl', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_transport_providers`
--

CREATE TABLE `modx_transport_providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `service_url` tinytext,
  `username` varchar(191) NOT NULL DEFAULT '',
  `api_key` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `priority` tinyint(4) NOT NULL DEFAULT '10',
  `properties` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_transport_providers`
--

INSERT INTO `modx_transport_providers` (`id`, `name`, `description`, `service_url`, `username`, `api_key`, `created`, `updated`, `active`, `priority`, `properties`) VALUES
(1, 'modx.com', 'The official MODX transport provider for 3rd party components.', 'https://rest.modx.com/extras/', '', '', '2025-04-02 10:20:59', NULL, 1, 10, ''),
(2, 'modstore pro', '', 'modstore.pro/extras', '', '', '2025-07-17 13:37:02', NULL, 1, 10, '');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_users`
--

CREATE TABLE `modx_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `cachepwd` varchar(255) NOT NULL DEFAULT '',
  `class_key` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modUser',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `remote_key` varchar(191) DEFAULT NULL,
  `remote_data` text,
  `hash_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\Hashing\\modNative',
  `salt` varchar(100) NOT NULL DEFAULT '',
  `primary_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `session_stale` text,
  `sudo` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_users`
--

INSERT INTO `modx_users` (`id`, `username`, `password`, `cachepwd`, `class_key`, `active`, `remote_key`, `remote_data`, `hash_class`, `salt`, `primary_group`, `session_stale`, `sudo`, `createdon`) VALUES
(1, 'masterkadaj', '$2y$10$rvvwSV7gz2ZuxgfcSd3aruZz/XMXKkV8PGSCAVtaAcqPrmmK0cg7K', '', 'MODX\\Revolution\\modUser', 1, NULL, NULL, 'MODX\\Revolution\\Hashing\\modNative', 'a939df25c3bbe071f74aa429712b5072', 1, NULL, 1, 1752748196),
(2, 'burdilo', '$2y$10$C6MntB4Focy51iMh/da/EO3qh2C/E6R/4.afNeu8mEJWJ.kGkhU1i', '', 'MODX\\Revolution\\modUser', 1, NULL, NULL, 'MODX\\Revolution\\Hashing\\modNative', 'f75353dbb187d117868569d6aa0bbcfd', 0, NULL, 1, 1752818374),
(3, 'editor', '$2y$10$NgQFwnVoWiyS1/7SHOLrAubY1tX0qZxBYwlfUj0wBhKdFH4KdQsUe', '', 'MODX\\Revolution\\modUser', 1, NULL, NULL, 'MODX\\Revolution\\Hashing\\modNative', '64af1e8e98b4f05ba627bb1671fd5b1e', 0, NULL, 1, 1752818469);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_user_attributes`
--

CREATE TABLE `modx_user_attributes` (
  `id` int(10) UNSIGNED NOT NULL,
  `internalKey` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `mobilephone` varchar(100) NOT NULL DEFAULT '',
  `blocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `blockeduntil` int(11) NOT NULL DEFAULT '0',
  `blockedafter` int(11) NOT NULL DEFAULT '0',
  `logincount` int(11) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT '0',
  `thislogin` int(11) NOT NULL DEFAULT '0',
  `failedlogincount` int(10) NOT NULL DEFAULT '0',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `dob` int(10) NOT NULL DEFAULT '0',
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  `address` text NOT NULL,
  `country` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(25) NOT NULL DEFAULT '',
  `zip` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `photo` varchar(255) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `website` varchar(255) NOT NULL DEFAULT '',
  `extended` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_user_attributes`
--

INSERT INTO `modx_user_attributes` (`id`, `internalKey`, `fullname`, `email`, `phone`, `mobilephone`, `blocked`, `blockeduntil`, `blockedafter`, `logincount`, `lastlogin`, `thislogin`, `failedlogincount`, `sessionid`, `dob`, `gender`, `address`, `country`, `city`, `state`, `zip`, `fax`, `photo`, `comment`, `website`, `extended`) VALUES
(1, 1, 'Администратор по умолчанию', 'masterkadaj@gmail.com', '', '', 0, 0, 0, 2, 1752748213, 1752818221, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', NULL),
(2, 2, 'Антон Кононович', 'burdilo@mail.ru', '', '', 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', '[]'),
(3, 3, 'Редактор контента', 'editor@smart-social.ru', '', '', 0, 0, 0, 0, 0, 0, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', '[]');

-- --------------------------------------------------------

--
-- Структура таблицы `modx_user_group_roles`
--

CREATE TABLE `modx_user_group_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_user_group_roles`
--

INSERT INTO `modx_user_group_roles` (`id`, `name`, `description`, `authority`) VALUES
(1, 'Member', NULL, 9999),
(2, 'Super User', NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `modx_user_group_settings`
--

CREATE TABLE `modx_user_group_settings` (
  `group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL,
  `value` text,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_user_messages`
--

CREATE TABLE `modx_user_messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(15) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `sender` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `recipient` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `date_sent` datetime DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_user_settings`
--

CREATE TABLE `modx_user_settings` (
  `user` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL DEFAULT '',
  `value` text,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `modx_workspaces`
--

CREATE TABLE `modx_workspaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `path` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `attributes` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modx_workspaces`
--

INSERT INTO `modx_workspaces` (`id`, `name`, `path`, `created`, `active`, `attributes`) VALUES
(1, 'Default MODX workspace', '{core_path}', '2025-07-17 13:29:51', 1, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `modx_access_actiondom`
--
ALTER TABLE `modx_access_actiondom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Индексы таблицы `modx_access_category`
--
ALTER TABLE `modx_access_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_access_context`
--
ALTER TABLE `modx_access_context`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Индексы таблицы `modx_access_elements`
--
ALTER TABLE `modx_access_elements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_access_media_source`
--
ALTER TABLE `modx_access_media_source`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_access_menus`
--
ALTER TABLE `modx_access_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Индексы таблицы `modx_access_namespace`
--
ALTER TABLE `modx_access_namespace`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_access_permissions`
--
ALTER TABLE `modx_access_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `template` (`template`),
  ADD KEY `name` (`name`);

--
-- Индексы таблицы `modx_access_policies`
--
ALTER TABLE `modx_access_policies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent` (`parent`),
  ADD KEY `class` (`class`),
  ADD KEY `template` (`template`);

--
-- Индексы таблицы `modx_access_policy_templates`
--
ALTER TABLE `modx_access_policy_templates`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_access_policy_template_groups`
--
ALTER TABLE `modx_access_policy_template_groups`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_access_resources`
--
ALTER TABLE `modx_access_resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_access_resource_groups`
--
ALTER TABLE `modx_access_resource_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`,`target`,`principal`,`authority`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_access_templatevars`
--
ALTER TABLE `modx_access_templatevars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Индексы таблицы `modx_actiondom`
--
ALTER TABLE `modx_actiondom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `set` (`set`),
  ADD KEY `action` (`action`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`),
  ADD KEY `for_parent` (`for_parent`),
  ADD KEY `rank` (`rank`);

--
-- Индексы таблицы `modx_actions_fields`
--
ALTER TABLE `modx_actions_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action` (`action`),
  ADD KEY `type` (`type`),
  ADD KEY `tab` (`tab`);

--
-- Индексы таблицы `modx_active_users`
--
ALTER TABLE `modx_active_users`
  ADD PRIMARY KEY (`internalKey`);

--
-- Индексы таблицы `modx_categories`
--
ALTER TABLE `modx_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category` (`parent`,`category`),
  ADD KEY `parent` (`parent`),
  ADD KEY `rank` (`rank`);

--
-- Индексы таблицы `modx_categories_closure`
--
ALTER TABLE `modx_categories_closure`
  ADD PRIMARY KEY (`ancestor`,`descendant`);

--
-- Индексы таблицы `modx_content_type`
--
ALTER TABLE `modx_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `modx_context`
--
ALTER TABLE `modx_context`
  ADD PRIMARY KEY (`key`),
  ADD KEY `name` (`name`),
  ADD KEY `rank` (`rank`);

--
-- Индексы таблицы `modx_context_resource`
--
ALTER TABLE `modx_context_resource`
  ADD PRIMARY KEY (`context_key`,`resource`);

--
-- Индексы таблицы `modx_context_setting`
--
ALTER TABLE `modx_context_setting`
  ADD PRIMARY KEY (`context_key`,`key`);

--
-- Индексы таблицы `modx_dashboard`
--
ALTER TABLE `modx_dashboard`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `hide_trees` (`hide_trees`);

--
-- Индексы таблицы `modx_dashboard_widget`
--
ALTER TABLE `modx_dashboard_widget`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `type` (`type`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `lexicon` (`lexicon`);

--
-- Индексы таблицы `modx_dashboard_widget_placement`
--
ALTER TABLE `modx_dashboard_widget_placement`
  ADD PRIMARY KEY (`user`,`dashboard`,`widget`),
  ADD KEY `rank` (`rank`);

--
-- Индексы таблицы `modx_deprecated_call`
--
ALTER TABLE `modx_deprecated_call`
  ADD PRIMARY KEY (`id`),
  ADD KEY `method` (`method`),
  ADD KEY `call_count` (`call_count`),
  ADD KEY `caller` (`caller`),
  ADD KEY `caller_file` (`caller_file`),
  ADD KEY `caller_line` (`caller_line`);

--
-- Индексы таблицы `modx_deprecated_method`
--
ALTER TABLE `modx_deprecated_method`
  ADD PRIMARY KEY (`id`),
  ADD KEY `definition` (`definition`);

--
-- Индексы таблицы `modx_documentgroup_names`
--
ALTER TABLE `modx_documentgroup_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `modx_document_groups`
--
ALTER TABLE `modx_document_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_group` (`document_group`),
  ADD KEY `document` (`document`);

--
-- Индексы таблицы `modx_element_property_sets`
--
ALTER TABLE `modx_element_property_sets`
  ADD PRIMARY KEY (`element`,`element_class`,`property_set`);

--
-- Индексы таблицы `modx_extension_packages`
--
ALTER TABLE `modx_extension_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `name` (`name`);

--
-- Индексы таблицы `modx_fc_profiles`
--
ALTER TABLE `modx_fc_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `rank` (`rank`),
  ADD KEY `active` (`active`);

--
-- Индексы таблицы `modx_fc_profiles_usergroups`
--
ALTER TABLE `modx_fc_profiles_usergroups`
  ADD PRIMARY KEY (`usergroup`,`profile`);

--
-- Индексы таблицы `modx_fc_sets`
--
ALTER TABLE `modx_fc_sets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile` (`profile`),
  ADD KEY `action` (`action`),
  ADD KEY `active` (`active`),
  ADD KEY `template` (`template`);

--
-- Индексы таблицы `modx_lexicon_entries`
--
ALTER TABLE `modx_lexicon_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `topic` (`topic`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `language` (`language`);

--
-- Индексы таблицы `modx_manager_log`
--
ALTER TABLE `modx_manager_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_occurred` (`user`,`occurred`);

--
-- Индексы таблицы `modx_media_sources`
--
ALTER TABLE `modx_media_sources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `is_stream` (`is_stream`);

--
-- Индексы таблицы `modx_media_sources_contexts`
--
ALTER TABLE `modx_media_sources_contexts`
  ADD PRIMARY KEY (`source`,`context_key`);

--
-- Индексы таблицы `modx_media_sources_elements`
--
ALTER TABLE `modx_media_sources_elements`
  ADD PRIMARY KEY (`source`,`object`,`object_class`,`context_key`);

--
-- Индексы таблицы `modx_membergroup_names`
--
ALTER TABLE `modx_membergroup_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent` (`parent`),
  ADD KEY `rank` (`rank`),
  ADD KEY `dashboard` (`dashboard`);

--
-- Индексы таблицы `modx_member_groups`
--
ALTER TABLE `modx_member_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role` (`role`),
  ADD KEY `rank` (`rank`);

--
-- Индексы таблицы `modx_menus`
--
ALTER TABLE `modx_menus`
  ADD PRIMARY KEY (`text`),
  ADD KEY `parent` (`parent`),
  ADD KEY `action` (`action`),
  ADD KEY `namespace` (`namespace`);

--
-- Индексы таблицы `modx_migx_configs`
--
ALTER TABLE `modx_migx_configs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_migx_config_elements`
--
ALTER TABLE `modx_migx_config_elements`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_migx_elements`
--
ALTER TABLE `modx_migx_elements`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_migx_formtabs`
--
ALTER TABLE `modx_migx_formtabs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_migx_formtab_fields`
--
ALTER TABLE `modx_migx_formtab_fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_namespaces`
--
ALTER TABLE `modx_namespaces`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `modx_property_set`
--
ALTER TABLE `modx_property_set`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`);

--
-- Индексы таблицы `modx_register_messages`
--
ALTER TABLE `modx_register_messages`
  ADD PRIMARY KEY (`topic`,`id`),
  ADD KEY `created` (`created`),
  ADD KEY `valid` (`valid`),
  ADD KEY `accessed` (`accessed`),
  ADD KEY `accesses` (`accesses`),
  ADD KEY `expires` (`expires`);

--
-- Индексы таблицы `modx_register_queues`
--
ALTER TABLE `modx_register_queues`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `modx_register_topics`
--
ALTER TABLE `modx_register_topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `queue` (`queue`),
  ADD KEY `name` (`name`);

--
-- Индексы таблицы `modx_session`
--
ALTER TABLE `modx_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `access` (`access`);

--
-- Индексы таблицы `modx_site_content`
--
ALTER TABLE `modx_site_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `published` (`published`),
  ADD KEY `pub_date` (`pub_date`),
  ADD KEY `unpub_date` (`unpub_date`),
  ADD KEY `parent` (`parent`),
  ADD KEY `isfolder` (`isfolder`),
  ADD KEY `template` (`template`),
  ADD KEY `menuindex` (`menuindex`),
  ADD KEY `searchable` (`searchable`),
  ADD KEY `cacheable` (`cacheable`),
  ADD KEY `hidemenu` (`hidemenu`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `context_key` (`context_key`),
  ADD KEY `uri` (`uri`(191)),
  ADD KEY `uri_override` (`uri_override`),
  ADD KEY `hide_children_in_tree` (`hide_children_in_tree`),
  ADD KEY `show_in_tree` (`show_in_tree`),
  ADD KEY `cache_refresh_idx` (`parent`,`menuindex`,`id`);
ALTER TABLE `modx_site_content` ADD FULLTEXT KEY `content_ft_idx` (`pagetitle`,`longtitle`,`description`,`introtext`,`content`);

--
-- Индексы таблицы `modx_site_htmlsnippets`
--
ALTER TABLE `modx_site_htmlsnippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `static` (`static`);

--
-- Индексы таблицы `modx_site_plugins`
--
ALTER TABLE `modx_site_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `disabled` (`disabled`),
  ADD KEY `static` (`static`);

--
-- Индексы таблицы `modx_site_plugin_events`
--
ALTER TABLE `modx_site_plugin_events`
  ADD PRIMARY KEY (`pluginid`,`event`),
  ADD KEY `priority` (`priority`);

--
-- Индексы таблицы `modx_site_snippets`
--
ALTER TABLE `modx_site_snippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `moduleguid` (`moduleguid`),
  ADD KEY `static` (`static`);

--
-- Индексы таблицы `modx_site_templates`
--
ALTER TABLE `modx_site_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `templatename` (`templatename`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `static` (`static`);

--
-- Индексы таблицы `modx_site_tmplvars`
--
ALTER TABLE `modx_site_tmplvars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `rank` (`rank`),
  ADD KEY `static` (`static`);

--
-- Индексы таблицы `modx_site_tmplvar_access`
--
ALTER TABLE `modx_site_tmplvar_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tmplvar_template` (`tmplvarid`,`documentgroup`);

--
-- Индексы таблицы `modx_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_site_tmplvar_contentvalues`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tv_cnt` (`tmplvarid`,`contentid`),
  ADD KEY `tmplvarid` (`tmplvarid`),
  ADD KEY `contentid` (`contentid`);

--
-- Индексы таблицы `modx_site_tmplvar_templates`
--
ALTER TABLE `modx_site_tmplvar_templates`
  ADD PRIMARY KEY (`tmplvarid`,`templateid`);

--
-- Индексы таблицы `modx_system_eventnames`
--
ALTER TABLE `modx_system_eventnames`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `modx_system_settings`
--
ALTER TABLE `modx_system_settings`
  ADD PRIMARY KEY (`key`);

--
-- Индексы таблицы `modx_transport_packages`
--
ALTER TABLE `modx_transport_packages`
  ADD PRIMARY KEY (`signature`),
  ADD KEY `workspace` (`workspace`),
  ADD KEY `provider` (`provider`),
  ADD KEY `disabled` (`disabled`),
  ADD KEY `package_name` (`package_name`),
  ADD KEY `version_major` (`version_major`),
  ADD KEY `version_minor` (`version_minor`),
  ADD KEY `version_patch` (`version_patch`),
  ADD KEY `release` (`release`),
  ADD KEY `release_index` (`release_index`);

--
-- Индексы таблицы `modx_transport_providers`
--
ALTER TABLE `modx_transport_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `api_key` (`api_key`),
  ADD KEY `username` (`username`),
  ADD KEY `active` (`active`),
  ADD KEY `priority` (`priority`);

--
-- Индексы таблицы `modx_users`
--
ALTER TABLE `modx_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `remote_key` (`remote_key`),
  ADD KEY `primary_group` (`primary_group`);

--
-- Индексы таблицы `modx_user_attributes`
--
ALTER TABLE `modx_user_attributes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `internalKey` (`internalKey`);

--
-- Индексы таблицы `modx_user_group_roles`
--
ALTER TABLE `modx_user_group_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `authority` (`authority`);

--
-- Индексы таблицы `modx_user_group_settings`
--
ALTER TABLE `modx_user_group_settings`
  ADD PRIMARY KEY (`group`,`key`);

--
-- Индексы таблицы `modx_user_messages`
--
ALTER TABLE `modx_user_messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modx_user_settings`
--
ALTER TABLE `modx_user_settings`
  ADD PRIMARY KEY (`user`,`key`);

--
-- Индексы таблицы `modx_workspaces`
--
ALTER TABLE `modx_workspaces`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `path` (`path`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `modx_access_actiondom`
--
ALTER TABLE `modx_access_actiondom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_category`
--
ALTER TABLE `modx_access_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_context`
--
ALTER TABLE `modx_access_context`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `modx_access_elements`
--
ALTER TABLE `modx_access_elements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_media_source`
--
ALTER TABLE `modx_access_media_source`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_menus`
--
ALTER TABLE `modx_access_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_namespace`
--
ALTER TABLE `modx_access_namespace`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_permissions`
--
ALTER TABLE `modx_access_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT для таблицы `modx_access_policies`
--
ALTER TABLE `modx_access_policies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `modx_access_policy_templates`
--
ALTER TABLE `modx_access_policy_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `modx_access_policy_template_groups`
--
ALTER TABLE `modx_access_policy_template_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `modx_access_resources`
--
ALTER TABLE `modx_access_resources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_resource_groups`
--
ALTER TABLE `modx_access_resource_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_access_templatevars`
--
ALTER TABLE `modx_access_templatevars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_actiondom`
--
ALTER TABLE `modx_actiondom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_actions_fields`
--
ALTER TABLE `modx_actions_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT для таблицы `modx_categories`
--
ALTER TABLE `modx_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `modx_content_type`
--
ALTER TABLE `modx_content_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `modx_dashboard`
--
ALTER TABLE `modx_dashboard`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_dashboard_widget`
--
ALTER TABLE `modx_dashboard_widget`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `modx_deprecated_call`
--
ALTER TABLE `modx_deprecated_call`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT для таблицы `modx_deprecated_method`
--
ALTER TABLE `modx_deprecated_method`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `modx_documentgroup_names`
--
ALTER TABLE `modx_documentgroup_names`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_document_groups`
--
ALTER TABLE `modx_document_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_extension_packages`
--
ALTER TABLE `modx_extension_packages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_fc_profiles`
--
ALTER TABLE `modx_fc_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_fc_sets`
--
ALTER TABLE `modx_fc_sets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_lexicon_entries`
--
ALTER TABLE `modx_lexicon_entries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `modx_manager_log`
--
ALTER TABLE `modx_manager_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=300;

--
-- AUTO_INCREMENT для таблицы `modx_media_sources`
--
ALTER TABLE `modx_media_sources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_membergroup_names`
--
ALTER TABLE `modx_membergroup_names`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_member_groups`
--
ALTER TABLE `modx_member_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_migx_configs`
--
ALTER TABLE `modx_migx_configs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `modx_migx_config_elements`
--
ALTER TABLE `modx_migx_config_elements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_migx_elements`
--
ALTER TABLE `modx_migx_elements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_migx_formtabs`
--
ALTER TABLE `modx_migx_formtabs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `modx_migx_formtab_fields`
--
ALTER TABLE `modx_migx_formtab_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `modx_property_set`
--
ALTER TABLE `modx_property_set`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_register_queues`
--
ALTER TABLE `modx_register_queues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_register_topics`
--
ALTER TABLE `modx_register_topics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_site_content`
--
ALTER TABLE `modx_site_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_site_htmlsnippets`
--
ALTER TABLE `modx_site_htmlsnippets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `modx_site_plugins`
--
ALTER TABLE `modx_site_plugins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `modx_site_snippets`
--
ALTER TABLE `modx_site_snippets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `modx_site_templates`
--
ALTER TABLE `modx_site_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_site_tmplvars`
--
ALTER TABLE `modx_site_tmplvars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_site_tmplvar_access`
--
ALTER TABLE `modx_site_tmplvar_access`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_site_tmplvar_contentvalues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modx_transport_providers`
--
ALTER TABLE `modx_transport_providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `modx_users`
--
ALTER TABLE `modx_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `modx_user_attributes`
--
ALTER TABLE `modx_user_attributes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `modx_user_group_roles`
--
ALTER TABLE `modx_user_group_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `modx_user_messages`
--
ALTER TABLE `modx_user_messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `modx_workspaces`
--
ALTER TABLE `modx_workspaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
