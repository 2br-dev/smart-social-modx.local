<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '15724300530718152d5ee2a0a33cf8cf',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/c1a2f5f7634403d3aee71e36f2b47c62.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => 'b8750ee944c3a11d446db64f28efd77d',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/b26603413dd188a737409e89cc030719.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => 'dd2d8dd8fa76319d1450467a19aa337a',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/b550d875af1654fc5f1f73beee948212.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'e3d634f3cfe2d7bf4df76f01be3087cf',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/5b136666a72569201cf0893970e30a33.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '466c93f2e93fffe02d0a95f7ed28ada2',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/cee851fd79c96218533051a745d825fb.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '66c1ec9b8cde855e675a95e404d01eb3',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/ef573b045f89978ba923eb527e8bd6ad.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '058c5fa880da5d49af7e4f2ac0b5da54',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/f0b2b01e32af1b50cca0e30bd6dfc5b1.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'b5fcab9e650744a682d8481e19a827b5',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/d07947898243c1178cf9eceaf12e381f.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'a86a044a9f2c665c669fd209e18838dd',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/c4f542066b84f062920545d0a57de269.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '0182a55ea1faf2d15e69fe3a831e4957',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/b0f00ed345d351b3ddfd0f6d821eeb02.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '40f6de659bc871edb474ffac3a63df8a',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/f5a4ed4f270903e31e38b32342e9a0e8.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'aebc8bbeeab1ed82c6ec67bd43d43cea',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/bddfb45db6a8ab65ebcd686755f786cc.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'ac7d46a3b07fecc166094c25d8fd65e6',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/930fe30b22318510c784e15ac9ce8077.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fe213d6e3df700e9c06ef09708bcc181',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/2d2f28ed0f0027514e455efea754ac96.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a5ddccccacfa70f4ae8bd41a0ab6687c',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/8fabc6c6edaaa2571cb9111c144144af.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '087027227f5cc98527a693bb8b66dd09',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/a24983f048eee5c34d827c48ac9b8f0c.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0a3e2d942d5ea60ba1d663d59c7b0f39',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/bcee5fad0c3fe643bb095a9935eaa5c4.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '69a18f59197bc7c0357ac76c6e80534e',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/32fb88304ddf1bc27c7c50bcf29a06b1.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1fe895092dbc9c39f0e2e59f84d01f0a',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/6a71bc26ec49f038e24bcd0962e6e5c3.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e1f7fd6b85d5d3ebcc3b06c7fa88744',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/283517b2f969172a558aba564a42f3cd.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '483e4c058b72167a08f5a3bb70982734',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/38f471d73160043e3d05d351e98265a9.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '973418e5066e22c67a74c8dd4e648ef5',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/e4ced43d5c719e296e604033d4e116a1.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1fc1edddaa355f8e3e7b2e211f15154c',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/90fd83f20ac61961e9da998668819b06.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8b83b1ad1f60f4cec480c1e87f5c5f71',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/22086ae6083d6ff24c60fcce6430b4ed.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9876d389c27d9e60ff116ab9675686fe',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/2315b6b4537b745b8cd50d6afceeda4c.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7fccf1807c6b7a3cfa4a7d0985ac6ec8',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/2a9db93ba80bce55880a28b0d0ea19d3.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4216f709f68f9ed7777323314ae1afb9',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/6ddc9f73f3667d18ceebffee22c7ba94.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '158bb3383b1f31ddcb615739fa57bb58',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/a3f813cc33c23c0098ed346bc3061d73.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1957d9acb40495f1ef897ef720612aa9',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/007c6e7155fff8b7f777f6e163e43044.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7053c154807d32c7f2e4020ecab07786',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/047da99ada562c25a950caa14b8c5e80.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ddcd34a4e4970208444219cb6d6773a4',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6e09391d39d462dcaf479c99d633ffa0.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '487bb111de27a1034f335da7cbe0fcf5',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/cb133aea2cbf0583a8c33aafe0e988ce.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '02ec5e329aaf683060684a2956abc369',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/0ec8d46dc78cabcb663f428509bd646c.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fd0fbd4f1aa28b90701590669929e219',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e9080e3fbfa2260a75ea7440c258c879.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0b8eea424040c9099432b1cc5f6f9c0f',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/d1ece66636998d67c559f29dc248542d.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7574ebff70c3be4b3bf9d22247b8e95e',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5ea710adcc0ac8e88c55d85b0ce19cf1.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '06a293482cffb14c902392027ec25a74',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/d3037802b7411f81bd26ddc9a2c2691f.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0692078120e6ac2697e7003eb17df2ef',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/659800688a8acd5ad386cd2b88eabb39.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6050a79b778b0a5ca5686a7c6128ae4c',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/c25506511ac24a50e3c6e801cebdbde0.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a309c5f4b68fa420f2d136dc2059b34f',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e4c55aa5fe623c01a3bc448928e9b15c.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '45ea0773ee4675cb0beeef42687602a3',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/ce9c802ba142fdf81d41cfbb89948e5a.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f0bb5a31333cb2d04ecd7ccc2e5284f9',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c8b18b9f6745223fb894e1481627fde8.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '702d3eba16341d4402ee11077ae3ccff',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/a624ea2db867dc5b194ee5177217a2d0.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e475a3098fae4108bb84fde85b3821a4',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/8af7f8a90ca1fe87a61f1eda62548c40.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '299038bf3bace6a2be7a095ca7068f38',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/f45650eb68cc850019fa8611923ec212.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5a96bd6e7e62c847dd8ea1f3838084dd',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/4090032ce27803683cfb3af1fa231cf7.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fc09e4deb60f5fb74b0ae2c758070c52',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/48a58d1d1205ecee92234cb38eac0bac.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '16c78f196f4782b3d2b839aa2c6739ae',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/9618bdcf7c5d6b304ecab9388b159801.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1111d6355adfc9b7740d06b25dba421c',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/b378bf9497d45f51f54cd80493305fab.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f28dbccc0bc657db11c91f904f85079f',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/37fd17048fed6279973e4bdab89efa8e.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ca8ccc5bc2f4264b75c61f5cfb5741a',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/36d543d10db172f4a50eaaeb1c337421.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cc07356eabae363e74520e932b1454ac',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/f64410ab3ef566c5882d0effc2c34f23.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1fd6442b76379341bbecaf7cab4c19c5',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/582acad1dd8da07638ddfa8f1ade9f64.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e59ed2e982d8be00a675509d24c2456b',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/74355b3457842792a191164a4d9fd39d.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '168a2c9bef65ba242b570836fc12f2f3',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/c0d18fc7b0ca9a3b67d46b33c1413b14.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7fdf186671710e8cd3e5a9991e1b1f75',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/1879bc5d3cb74d7277fc1ac363c5d1e5.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '822cf836f192a1c18193fc2cb9f3c4a7',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/0709f82913426565f039713ccf911c07.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bba8587ec8b52bc91c9d6396b0aa0880',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/9cfb173f6f66038a29d75ffb35acd8f3.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a954b2aeca6def317b96cb90b5f948ae',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/5ad88a430e99a17c9839a3fc0fc01b19.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aeb6f2088d1f1aa52b6ef6ad4f554b01',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/e6f7177631e44751c13381e39d83d6d1.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6f0c9c9cb2619ae3ecdd39fdb59266eb',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/b097d69aae74ce9ee155838801c7c7fa.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '620efdb9a8381eb17f09522003ecf40e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/d5acef999bc0dc1e27dfe0c2043888e7.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c0039bdb07f0ab0a0fda8e9f289ca606',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/4bce0371a3726a84a4ba71c2776abad6.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8f57f9616d518510c86bcf39621a39ed',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/b023eaef496ede51f055f27b411ef71f.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '428b80cb387d5560197d07a8e6dcd28b',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/a08e4582400ceb8776de0b7eaa44018d.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd007fad9f1bed0a8c867d9d4c9814680',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/d6e6056d68cbab28985f5cfb82e1cdb2.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc1eba2df3150baf0a87bd1155211e62',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/a44f046eb3d3090372da18c03889a042.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc9285b34a14fb800e168464b011f1ca',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/31869b13b3c67e0deb891090a1be1b23.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1cd47dfe98a11de9b1619eb8109f4bfc',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/78260d4ede4d9bd1ff177abaf8537f17.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '59f3636a3dd890c0b1f9c2c6839bb11d',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/14937c6b5ee566b17743d0025cbb3606.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4ef22ddfafe3167975e624342cfc4188',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/8eaac01380f025570d67735bd9f19844.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eccb29376838e8a2692b1e80e727f21f',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/4d37d348eb9fdde34fb79e8b113db6c0.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '77e7ec83b12ebf55a922a0e6fb160144',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/80fea28154df8e76378e3ed3bdb35ed4.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e3cd66f9e57a264512d6203ac188147c',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/f0d57a559d97c773d7d3432f18672ca1.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '89a9ad69dd6b218c4a2e41fb37d11d93',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/f501df2dba72d5ef6c2d078474fca38f.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3c7669746c3d038922a8aa4ef6210c5b',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/e55efe53c62381548c7491dcfe772520.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7231a57bb01cd58b9da2910cea4d55a4',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/019208fbe9c134af88a5db8fb5259ea6.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '54eea137b310c169f6b8222bff264516',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/aa94fa89e421b42fe6b7f7757f12568f.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dc7fc083b668216b1aecd6ed0d3d402f',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/292cee9472b29f53f7501b362d5f1d20.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '150b88a8965f91056beeee5f9cd7a4da',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/6dc789b378ba9ef1cd72ff0bf2073033.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd83895545ab9b8b336055ef14b87b0d9',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/437a963b1f51e38ebfd9cc0d2717e873.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '750e15bdb80145cd6a5d5cb49ff0612d',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/e3ec0b4ca371cf2322b3605f64912631.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e4aba25d7ce5b51ad1ebf1a3cb6dd73c',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/6fbcbe6241bec0223a2366e6dc4640c8.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ac50d555c31fdbb3fb33c0a4c97fac75',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/5bc860c6136abc19d9e8ef00d8f39841.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3f1137d3ae379296fdcc20a28122e13e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/94bad6976d6a2edbed0a06c68a3781aa.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '66993e48fb270158637431099c280185',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/4f28440e27dc0e15d0d236b07867f138.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd85d5a9582c5012b2fe1b11d5255ad0d',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/b86d0d8c56f1f71c887cb90c510fe21e.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09dd7b52d26b40b456071c2b0955a2fb',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/0e3241579c6fb7c4618b0b7099e7046f.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '510736d28f73746e9decbf3bd6d6ba50',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/b2c19bf8ccd5173b00f7947643bb0846.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '46f58462a2de7b761c580c4ee78237cf',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/96433000d1d628caf4fcedb9d0cb0e02.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '30347d7d116008dbd22d8da52a9e38bd',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/f3158ac927f89e767a88cdd18dc556b4.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4ad23f699c5f314c05c760bcc2d993bd',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/d74a32d19f058d38e9b288e2696079ac.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8480ecc1f36ba3a3687bf7bd53bb1899',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/c75ce5f88e45236a5452d3efce6f7287.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3b49e7132819978147b3111a1985de8b',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/e63766dfc78ddec88ae4e5067548796b.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f796ef2cd7bbaa94185287d7855c3259',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/5190e576ef2113f5ad8349135ee265b5.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '33b0778d29a47d6ca7919ebba2de2788',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/28315e5b3927c873652194701ffe18e0.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5bb6e3fe3b52208aef6e06fe9de25efa',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/c4e35aed87bd9bc79535c49bdc95014d.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bf7f174c8f88777c238aba06fe69976e',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/eca66e53f44c0e784473d52c2e154790.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd4bb49d2bfc170848a7f257fb46d601b',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/d7612d5ab0ad4059551237d9205f8269.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '41d3ebf3036cc547db3ca79e599b6a7f',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/77bb622a6d1ced6f8650f3820f160e0f.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6fe0272b832a7100996926196b9ae48f',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/70d50205bd45f4dd8956f019cb9328c2.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b0c92931a80fe06abdf58569471a1ad2',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/593d18a13f190fe8776c63c1be8272d2.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'feeb4b9058c8da1de1da01ebcbbb61cb',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/d8f910a8eb75b94c90e6313f6bd8f15d.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3185b1964c87ec0832cf04dc1e293cf1',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/332f0a9c765dedb6cf85423c37ea0b96.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '05ae68585da707b55c290fa69ac0cc4e',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/af43fc9dc35f816e21b927c9eaad3091.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9e7cfbd7f9b8b38ed46b71921bc98568',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/a918db2e48a0118b16c6720e94152a7f.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5c81e6b86b4d7b7989610f2310df6c30',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/b0bc8756b24ea53bb33f788ea9b55b85.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2be8c811c18aadd34c0efdc338ac1fd4',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/b8dc3da751d811bd95bbcc6b42ada895.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c3bddb962390e3199e238f775c810421',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/2db22bc6dd5e3411e4ad5a6c9e66834e.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4ba92a5b22be66dd7d20d31a49baadb6',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/910057dbf6164e4481cdae887da9a1fc.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4c8a48af0edfa743e8a423e368a8521b',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/eb88855cc08ad2d212ed0b10a0e73836.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '43794baa0f732005842b07ef7ff4a773',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/3fbf0623b2dfe3eda1ce87d943be813b.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1e5d945d5506df67b849c913ac59c4d1',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/fab5bc59f39850f295bbd18bd098fd93.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7d8161914dbe7450427d19bf104b92ee',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/11e17504ca8ce8b6e82e7e47e25faaa4.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0092d71f03bc351241261e118bc4c741',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/1bd8b3f28da1837d7017f872ba179ba0.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e0be92db1a98d350d1240040a6d7ab5a',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/472bf80288c38649a05f4edd7fd270d6.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'afa1aa8d92de015456df02959b1006b0',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/2d3fdce3642ff11a6128ce4b3d8f832a.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd6f392b6a47b003648a7c322f620a035',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/560b8404e0f9d28d135b63840dc0a550.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b00dbfe483490cc42974555ec7d9f508',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/ffc5602cd8f45fc9127f9f3bb1651218.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4bdbaa7afbc6bcab0d1376670509d334',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/67fd4b762b9c7b542922d7df2d95ada4.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ade864bd889cb01e3d485fcfdd31df3d',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/3362bb41a41b14ab9953a168b8c34120.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd1e7fc843f4346dac4f83bb7278f5f85',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/d084b8c9061216e7de143581f9eb37fe.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4f6560ed90326d14077b8b3b57d43316',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/43b98e447d9c2de6ca18142bfe166ae4.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f35c24ab0d97873b411bccc0e83151e',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/224543d81a15697284dea63eab6ef7e5.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3e7723e147545a98062d7768892a52ea',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/6a078b92d786894b58157dcadbc77532.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2103f53f967b196bdcc7ca2808108182',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/75a98f0efd17f9147ab30b473c6400d5.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3899645ad3026c1294ff6867920eb6c9',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/9cde463e69e66f2964974c09f7ab48bf.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ba70a1731b1cff4be2e7f70db61982d9',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/3f5fa5cbeb1758cbf33a5b2258572f5d.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da9518291dbda8983b016d2cf2fb1591',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/b10c797efe664fbb7a50e76705b1c759.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '131ccd7feb9245d871fda343a77eaeca',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/081f998f087df262e10e40359dad45ea.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9d165f8d52b44f20718ee69478dd8c6d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/4b465c95dca2b909a8e53704dddf3ee6.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '36490d14642f382851bcc565fa840225',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/ecaa1b479950a9476d26f908d76029ac.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '02ab8cca514bae6f1b620ba6c1149c22',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/c9e06c0ecccd6b4a3fa1bee9e38d601b.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f3c2a3b25bac60eff2630267002d7c4f',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/dfaf8a21b66c05ddab4ebfc3a9d5af6d.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cb47a9c9d0749b8535d22a116c72ab91',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/ada0bb52e358e7d9b761a8e96be8d40e.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '39b5383ed9a2709b0471da41607ad89c',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/b8ab0aa1652529874aaaeefb51b92343.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '52fadfc0404b04755a1cd9d5f95bc008',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/630e898167910f527cba2786c29d9fd1.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0040c2986f14b156a2755b570fb5d63e',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/ec60365e9275a5cb1147a873b6083ea1.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e0f6cdcb7e05e0c52bd615604d6985bb',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/8742d32e4a1469133fb4901e78e827f6.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e63e7aea46c5fdda15e02b7f918a3d4d',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/ac821b80de4260ceac38d8df06aaf3e3.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc47f280206d2d63249bf698f8df8307',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/6df9e1c4ea5f80ec859e5d757ae2cea2.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b9a71b9d0a769f0235aac032b20c83d',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/eaf47e6aa167fa51bbf6a8055bf77e65.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4b111c95ecd94f84889d34860330fe53',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/e5d2938554455c5272a9b6edc567bbf0.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd5b1eb41ee0691f4efdd3fb740da70d3',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/d04216c7faef1284ce94bf7211615889.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '38572f8c5ab7cd64639bb6b4257e20c1',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/527d6aeba18c269bd59e352e9e1f9a24.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '370fba901244348ed25e0e2ec699dbfc',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/084c9eabbbe7e194986ac0c9f07ac74e.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd5d9db2477434c02092a8bae3774c441',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/6f8b8fbc08668d902d68ca663ce3cc3c.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fd7cd0e65280409b12ee3a1fbf47e0f0',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/01f2f94cd1d665c45e383e35063ce53e.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1ae0b629ca809992131ea328dbb34565',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/3f066136659ebc27c61382f29e36df0f.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3891d9377172373f625d88e80358d3f6',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/b65deb33e46f143fbbab5afc0e7297fb.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cb265b2d3723618b495b811a1f4ca6f3',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/6a35334bf0a6e3a1aae21af48b15f69c.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '001d8c980e90004b83973b49a74d170c',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/e3eee24898212e1f1a6b4225dd68ae29.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '912b844562abc13e51994de6637466be',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/2dfde3bccc20815aa1532c9b6156343c.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c33d7529377d393fed2be45efeb6bdd0',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/3c32ea7d01e8bfd20067225cb346408b.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '22d08106454b0b3cd30f19fd7f834cdb',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/f20410b16d8b667773edc72ee1a80815.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e93bf8bd59a32ce26cfc376e6e297668',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/a33bdc9a87e68ee4fb5a0bedb8cae0d6.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '07b800cdcdb1f25901e2ad2d5ee0eeda',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/e6763d02243fb322b3c6741331baa4d4.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2a14f9823b0eb7402eda762d0caff99b',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/2811e95e45b693a32d668e62cda22f09.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb5be418c36a02d5eb42aeb550a8582e',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/12076e2b2759245066287615626f2587.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8bbb8f8afa987af7349583cb9023a572',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/abccb186c0395f47e53225e1f31a1169.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '08cc8c26ea57b495a1086ee4cb4d46f1',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/a4ee149c8254eeacda879b04a72d3ecf.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2a5740171aa41da8c64b4e1a8cab21d7',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/3330ab11ce6181c3766787b8580a19dc.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '34aedb1df21998f9fa3a36420a28ee4c',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/77679f181b837543ae97d14b42446c7e.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da42de318a199d8ecbcd3c159672005a',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/4a153ed6ca1c6edc4548ba729e40fb05.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bd1311adfeabc1fd442794b93e2529bd',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/f552642fa425ea1bb9919ac9d2805996.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5d999381a7ebe413d7c23cff65d5bd1b',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/fbab522ae0b6e5486bd4850328bd6b95.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9294df8bec564ef0a9ac0d6031744284',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/a8bc98100eb0d40954ed3fd25d8a978c.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '588f9d78e2a9aef3a5c1676b8026fecb',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/917bf24fc945b2f588dbae39b3a0743d.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4efeeb086a6b5fba5a5abb2ccce3046f',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/4c1afdddb96bd2de00ffe76c3623fc0c.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b214c991356b95b197dd1a2986d0b85a',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/c5407c34b43d425e14daadc84fbf3c8d.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5159a9461946f32486acb1a9ea4aa31c',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/fdaaeba09ccde9e1cdef20e7ff1fc0ac.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '27ed64f179aad4521cd44673ccc0ed05',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/a8a9fb7e58842377bc62c9d1f7ae4ae0.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '734297a2edd9b4109b0be882e61b8b34',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/0175e7b57be355bdc29b1fdf86c98043.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e26c4bfca956f311546cdc22a15ca726',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/097525c984a43d3c83746ba568d831c2.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e9a74155d4961e90c390413a8dd8518c',
      'native_key' => 'OnContextInit',
      'filename' => 'MODX/Revolution/modEvent/8ea1cf7e80a760b17bf722cc34639863.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '739e89edaf5b703c445f1b765f057d64',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/aac20bfab067817cdb3cb84d5bc8160a.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f372842042a55d63b52b0ddab50990f9',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/23ca5e9975a0c000e7c282822bc7e6a7.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '51e285db8f145ec0731c2206f47934a8',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/05cc94445baf048300fbd9d3c3d76bcc.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7575b9d2376f657e7f788e6293ecb6e4',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/ec70fd1c2684b8cbf81b3136225b3d58.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '20995d1aa561b97597cab2edd1da0188',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ce7edcb6e415819544e9f20ac8c0171a.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '218f03843e28bbec2d26cbe529007c39',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/7d485d7cc78ea4b9873ea92e4290ea40.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fd9daa9ed66871b4440dc927ed01aed6',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/347c3494db0efc594b3f8e66876720d0.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09a3f504546cec4548f7656b04fc6911',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/8f043c4f42c834befe8a01010d71c728.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aec31f6e4c3e61c0ccf296c0768f2549',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/aa257cd54394e08543279d1b0a49da94.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c7be595f516987098eb80bf5646fbc26',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/a4677179f3a554fcbde9ded27b98d746.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '39a0b0be05348a0b1c533bf435b0472e',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/162d2215c4623bec6f2ba78b2e783ccf.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da6b5230f4246f66655722f844e5e7dd',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/93e9553aedb0b5508dc839846e2b356b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '41c1491900893e8b372d333ec83f9006',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/457d23c782f6365dc90cd0012a9f5f8b.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e27df635de2e5b94f244269a552622ef',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/ac641e0e5ebdea0465c29e0729acb364.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '37689dae77d851c40d9262bd6e0364fd',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/8a36a0799fbe776fcbea8944ea643f2f.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5fc0a353e7e8f72d16ffda6669687753',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/0b00d57d5877a532cf5b9e1417ab1df2.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7b77c2334d2f2e1a7babe783a0f2f114',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/557b04a08b1af1caef1db49dc79fede6.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0f87295f49ed6665d695364dc8a5ae6f',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/ae93966d449c7aad15a8664c1dc912a7.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3b5b7e72b67b192e11bdbc96fe1547f4',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/567e1fd69bf59f01a34d37a84bf75816.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4dbb5e7a99427febce3e81264fb36452',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/b4b621c2b7e7e2dbc781b4505b4c7e4e.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '44318f773fdfb91c4403f339e10574cb',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/7fd3810d30d23e09525b9ffbce836c27.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '966432f31c4b1b4f12a3c9695a69e11d',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/9c085036b8546fd8b48be646b48de27a.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb2599e5374c28e67aaa648132ef7e6b',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/901ce4bf57961ecb7542c8350e7c1cdf.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c3a2380422027353b1b0165dc57a65f2',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/9241f8cbd5c7a7b0364aee66ed7776f5.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '41062b8713e84c3615c9596dcb6014ed',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/dbd93df98753fdba3471953ea816f1df.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '131e3b75b0b814469ec5557dee2628a9',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/367f936d79db803419f267f4fc864bce.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fbd906bdf6f145bdc5a36a44c6b8e18f',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/095bf83d7ab2310f0b7487c0fffde62a.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '85b744035c08ca599a0754508ba6825c',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/3658dbfc81bf548ffa640b3133547acf.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8deb6d848ecad935ef477ed4aebfc78f',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/a7c8fd5aa7093dc8c821b235da168390.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f446bf9a8293767051143ac130e04e43',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/c66e7fa7df112a9da014a08bdac0144c.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e3d7000f1265550b1863d6d8e892454',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/3ff6f3e3875bf39897ffd5f39b418bd0.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fabebb564266724230f2c32e12d3fbe0',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/c952e7625a9dbcac04a49a2688e60321.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4d43427c6ebbb310331be085011acdb6',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/6dab3d9b46f9680a62efce6e7450a87a.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4e9aa541bf0785c5eda8ad22a92b65f',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/9eddd24c45c2d9a05575f70c3652328e.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '03cfa8200b7348b99c0d5c00fee165b4',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/d52eeaa602615b83ad73bb7e94998d7b.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6e23bd751fa489a48b08c3f442ee118f',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/0371d3778a8924b5e881d6dece51be27.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74c6d2ca0cd07a7a6b684222a6dc2e46',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/06bbaf8ebeafdc4c215b90873b6b8fc7.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f1c56af6e2dc77acad5833645a98b7aa',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/2df65309f42ec52820d6a689e9110624.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'caf83e72229f6f7b0d5780aa9264de40',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/099a698cae583228c2b127a64299fe85.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3796c8460c2ee4e6855a02d61eef8cae',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/4d41213a9277a2f843a883fa1c0e8649.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71f63c29b36962c148d00226df2d33d3',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/4b5fac874d54dd067887cf64fffa0681.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a25a68a0a1e59c749fa569b47dd2617b',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/f1232a5d569779d6cc8e68bf8bcf0606.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da735d4eb635f7506a918d09ae12c6b4',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/ba5b225aee93ddf9e1c2291688dcffc6.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f44ec1161e9440dc64c8f0476ef3c81a',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/45a6a49105b3b60e2df132935ebddbc4.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '41cd1e16043274ea418d40b6534456e7',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/1f3dec900b65b3ed2b00df7dea0b6370.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8790529ba056f8335f2286faaae434f2',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/fc5beb6b8487b29d5ac1d04e1f2f9a03.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0c0433d573dae7e1f56d326006a49a8f',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/b26704a90452581b25738e540eb5a72a.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '995df1c8d98d1c64ed36bb8f17b6a715',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/c7b3bcf062d0196a7b425cd50dc44bc2.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ca98b21696b3f98d0db0149aa5374e93',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/28187cd80f679149d3fc5ea8141ab046.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a7449185e956dd440c946acffa901cb5',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/7d1b29f41757d4e342982292442786f8.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '516c8a21e828524a36960746141fa3b4',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/2f2f5b2b066ef80a3ff595dc915e25b2.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa9d7779d4aae6cb8c2e602eba7e8339',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/5b48ff65577c357748e544501f759e4f.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3910a188ca25aec5a88df9e250344559',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/018361fd0a2e2fb28b12ab3f7a3990d8.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9c55248c3e9e80d1944fac2f4d094f5d',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/0d1f1ef6c3f4097d257fd665e212204e.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66f76405c979ee46f30edbb1aca5d0bf',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/9361ec80141446d35bac05190e079574.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '381fc5336a4d1580890ce8be5a57e78e',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/770ef4182af842eecbdf96b2635d9289.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99297eec74e607d05b28f354b241423b',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/e0505794cc37f2770189fbf256418a2e.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a905c7ff04345326f9f8d696da1fb65',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/768c11c60e3a71a6da37ec617fddbc8f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31f5e2c79ef13932b48984679df57d3b',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/dd331b94907ba1cfb1d3efb59f79d09f.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '287b220ea7d67a1072cc4ee86afc3928',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/f1b30c5c5f804071e5442783f7dbc89a.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '300d11a54c1279a1d3c44423a001fa18',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/458bd51ffecfb8a24c6b049f4be27975.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5bb8b1904f12310e2ec5cbeb0e404aa3',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/257b8aa226222cdc65c1e2e31a0fdb8a.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f264df14a4f212a704b9405ce6f427ac',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/f4e9b2fc7b2dee8099777acfa39a7955.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd8ebdc0584bf14904367b81af8de2eea',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/2dcca90b2343cc57b0444d90b16dab72.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '80a2d3b845332d902deb058da4abd1d9',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/09a997469232292d3e587954f4bc9e67.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '17f6add1d936ce4dee8b1b78d8269123',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/1fd1da8a40c674e8f2f98c5f7b3e6c15.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4453e9368608fbd909aa043df9c33861',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/2fbd8420a3f97c961f97632b19d4317b.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c41e686afa1165c4adb610f4046a8de5',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/d0713666c2b1db52330859b2edf4375b.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c4653f90e38c2b260e79e5ec04cec3f0',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/c93e0f37a160e7c2af0b5a3041abd103.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dcb2b289b52dda6c736efeee1effa4a4',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/49ce3216b4684b6cafc9eae0f84c5942.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4065748db6a6e5c36eaf515ad534962d',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/495985bb65c5d58896014c4a4ff691d3.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0bfae2e4c8c815bb9a7dec3f08f979a9',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/b1730f15a51f1b6832d89390873835c0.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '241380a46a4d73a0dbc1463f98711750',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/bdaec976bb06d26a7596c1ab5993446d.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6d39100c01214577595530e63d14dec9',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/e9f122185d97c5eac2c89083ca1e7c52.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '917658149b39990793a3dba7cb301566',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/91468a2f63670abdde1dfd53cfc95e62.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe54973486011cd663057cb642ae09db',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/3fa4fa5371ec6698d31013cd88e593d5.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '57c5dd34f310dbd0704be088f2d45c8e',
      'native_key' => 'photo_profile_source',
      'filename' => 'MODX/Revolution/modSystemSetting/55877268e842a4978296bfd0e6b7baa2.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20a6a4503cfefcb4e550f4d4f775554b',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/8e33993e808a2ffbfb9a8a4424ee2546.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '734206a754a835c6d9d17c8337ed1679',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/10eb95e117eb4b1d6f3f72777d66eeee.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '04407f8eed97e84c7fc124ad4488358a',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/3ff09a9728027acc6eebbd89fdb11cb4.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b7492a9011d6ff814e815aec7699b6e8',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/c916e54a8a8d227c3fd4d9cd152719bb.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7c533549fe3b2480531a47dcb6086ce8',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/5c9ac9a58d23bb245411a7e8cb4c5237.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3ff3e5cd2a6fd18584495155073c5c67',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/a6236657cb5cc9494559dfafffc198bb.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ce9c76ea141d2f06403d7259b4a4e0b4',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/30c5d8e03ede74c3502817f275845f28.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e2812b3e047048a111a8c8cf0d22a6e6',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/1974521bbf3e541139c1ea31ade0babf.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '53ee3c1e8b83ba4e4565019cadb8f767',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/ad8fe3e11e6cd642a2c553c125e6e81a.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2cc0480e739a4d931461e4483e9c2906',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/a7e29f197305064742d3c4c66bd5e752.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e213bd8344325fae32a89d33e1782f6',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/b157970288f357601e21b6fb5bf7347b.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9f138fb502f049128732e606b7fd2761',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/cf95730ea7e8411a6f4b43b77d3805dc.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd2002fda603adf2ca83ae47e11eed1a3',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/5680626bd3b429c1b36369f158137754.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed29dad64e9f19b921cf0a88545f3b4e',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/2413ef1b8da3182348ae33f3d036bdae.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '280f7b76a5e2e0ca4664973c1c65fad6',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/e8bfb1527439e5464befb6e8117b10c7.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '36571fc5f6e031e197360b0747a41a32',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/3769e5b738f06e324068b6df8d23afe9.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3990d516ef730934b0c2772ba90859b',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/bf2b13b0ff1c3f3179b2c7ba0cfdd938.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe2beae0f85a55cb2465739f1b599399',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/ac96882e3fd424364da8629b39c85524.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c0d1df91edd9ec20055097bd246e0a02',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/695907ece98515f47fd800e59e5f4c84.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3fd2743c150d0574bec8c960342f487c',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/c47a02b26a44174f00e537baac0c98ad.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ae32211e1ffcb0d44109e74bea534dd5',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/f845471f17a978b6b6dc137847f83d6d.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8ce911cb25dda76b4ed2a386585404dd',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/5b04594e085dd344575c57a902c71406.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '85b6849d7a4979f8b9bb8d8fd4b73f50',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/2d7e0c0fd0bbf088f101d9190387251a.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f2db519a6a9670dc9cdcc2e55444023a',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/04e556638b816056882074fd31d779b6.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'deec3400efcd5cee4b437aeea7795f8e',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/273133ba894b96bf82df7a7be0d1bc4e.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e19a9892354921800af38d331cc6ccd2',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/ea90d100a03f099e2e9f5aed7568b670.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0e0011cf02de3114e780482a6a79c1c',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/5a10cce0784d42f732e81ac142be46f9.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1984a0c03897796701d7eb6f981daae3',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/14f3e9ebef1c4d5ea8c5ee22e52f6285.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4200b2d0bf2fb94b03dcefba7e31383',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/9faa7556d2efc1d3688b8f54d1f7a3f6.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '045c73e86e6f0cf4592a51e8aee9ae09',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/0d3105030f57c82e361f24d7eced59f1.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'efa816afedab552a03aca61c064b48cc',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/33840852813c4363b5cbee9aa66b0ade.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c0c0225539f90ae3f02e2a9d28fcefc0',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/afa8251a3b35740f72245adf3cd3f1b3.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'edf8137e3d813ff5d4cda6ff450ed075',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/7a311061722ae3794123b9aaffe0f870.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e247f06219d542465a70af2ccde41b52',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/9a3b9c069188989a2d85f2abe82587a0.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6f71c0d48aab222e89e25e8f9745792f',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/5a80d83b6a591a0f84c0d6f7093e0289.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42fbcb3355d32dbc93df66b1918a782f',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/5d505ccb61abc887ce7b72de615ec5cd.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f2fe783e7e2d24336e8bd6b267a2b691',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/7cea0a3cf2da3b42062d781effe0199e.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8151181e2dfb269f8d07e61607a50a13',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/1d9ae44b74f279012076bf85a3daeec9.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '47b6135898c7118e5db8f6cf1b71e23d',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/d363dc797ffe4242721c844da9a0231f.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a7b20c7fe9d4c353f21fed6eb8f79c36',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/1e7b77edf0dbd204bdab75b3f943ec16.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '02bb3e5378021446e341a8b68a446cc9',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/f7ddf7fb0659d6dce02d94bea63c669c.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e4eaa151cf19534d23813fb2a568f4be',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/066f38ac7547d87238dbd00c17d87993.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '987a414d3287266c920223d519b206bc',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/85cc59b7e287125573d4e746fe512ea6.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1be6562f9457ac1f537dc788c1d5f547',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/53128afa05beebe2b19f791c51c508bc.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1dc733d29cd872115eff9419bf67d0c4',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/f0ba74de6134ed3edfd1d3f8bd8186a7.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '65a25f036aabf74513d946310f29d321',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/fc7eef7f6fbaa42713d86b04d396a079.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71397015c76a731fa52c5f952ec40240',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/f2f3ea52e41e4b02e68dbf1b2133f67e.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '48131d68aacee0768085d59434bec0fc',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/f3fef520fc6707b4381e7a50b057e5e8.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a55c434a27e401dea2b41bdc513b46ad',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/a074bf26cb5630c248baddfe932c9f16.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7cf666092dd26a00a4cd93d92c7fcdec',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/908482fd9e5069018000228b989bbc52.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e37856c1165123ff2e9741b00567cbf',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/6a2c6823bda42422bf4d774ba154e120.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1bfd230111113812cd6d01727483a2d2',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/c424e0d3c61135b3c437b7a1fe571c97.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99f8916f40706fbf11833e5e27f8a8a7',
      'native_key' => 'mail_dkim_selector',
      'filename' => 'MODX/Revolution/modSystemSetting/e2af6e9e64acc53a451950d7e02a839d.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1f5753e52bc9b7d940a3c63f567f9300',
      'native_key' => 'mail_dkim_identity',
      'filename' => 'MODX/Revolution/modSystemSetting/1f315193ec7ec03b8bccc82db5779aa1.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1d846331047f236b96c0b0753bbbd908',
      'native_key' => 'mail_dkim_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/21451fb588f1208c84588b9aa62e5194.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '061a88ea31feac054696b5444cbe7ad4',
      'native_key' => 'mail_dkim_privatekeyfile',
      'filename' => 'MODX/Revolution/modSystemSetting/7e4f06ed536f67f7911afd7c6683afbb.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b16002297fb084d5df46c0f5570e57e5',
      'native_key' => 'mail_dkim_privatekeystring',
      'filename' => 'MODX/Revolution/modSystemSetting/6800b223beeec36f8a103675bd0fbd45.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3efde7ca4b1a08f56fcf962fac1f5ecf',
      'native_key' => 'mail_dkim_passphrase',
      'filename' => 'MODX/Revolution/modSystemSetting/5dbde0022cb67d81e974984de47d9164.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5259485e0b13117b4623b0348a97f7a6',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/cd7e65d329ee7de493c938447b2ba884.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66f03fdc67abfa5561833251dde87f29',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/6086a98e1aafb3f040f9adf8e37237d1.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a6a73cbe8690e48da83fac77eaeefa7b',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/402afba44c170b281e7828dee57e70af.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be2304aa80b26170fff46c25e7db11df',
      'native_key' => 'manager_datetime_separator',
      'filename' => 'MODX/Revolution/modSystemSetting/fd7c5a571d2b530b0bd032a89df4dd37.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '95d4476b6a9d3395c5e9f8f412bd2346',
      'native_key' => 'manager_datetime_empty_value',
      'filename' => 'MODX/Revolution/modSystemSetting/7ac95cd31a04fbb93712c276c262d13f.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cdfd9a2d965b375e42d8837b50f67900',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/057ea92c3eb3582d082d0c03e93f1479.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e9fc561652039caa312fad2b04141624',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/08fc8d232e927d98df71ff554403d610.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a28ac72388c00f73c6a78729bc63ad89',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/2d5105f3a4e659182ad097361ac06522.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82a1afae601a5a830de62183c6395ffe',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/532744b93a6bbe5df383f04ad6c2b0bf.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c6e5aab25aec30b3b8eed77d1d2b1a0c',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/3d6a66774afca2ae8e882ea99c4c3e4b.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5c5f3da161e316f626d841bf82b2ab5f',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/cba37bec9ce4abed917ad5abdd891aba.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '009033156a5bcf2921314e1ee710de01',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/83c0e7260256e6f5eec3135f4e3234dc.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe752821116314c3e09231c4694f9f6e',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/73e23b9f7ad65b45fb2d349771dad8fa.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '048dd07bdd4c7ef31b2cddddd7f141c9',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/bd54795288a0ef0191e33adec0bed2c4.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37b9af8646d0eff5640f9baf65372323',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/bc77d0a301960b6716b40e1ffa7faa4a.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5d695114b615a2ec32010118b9b7e829',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/df01ddadb6de567f460fb94753474da5.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '84d5db9657fa71c75689cd56e24d3c83',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/b6531ee610c59da3d2bbb78e460b9ac0.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3f3e48799c75fdd7b1f3c35bc59734eb',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/332ff512e6553b5a1661874a691f6bc1.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1a57d838beea4db35da7900f347bfb26',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/c5d4c6c07bee0993f669ab4febd95af1.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9332daebc0641702de274b198af12848',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/18b86c07793f622b52cf327c25d7cabd.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ec265739978b68a1aea997b05bc6979b',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/68eba01573592465d1b3b8a272797e7a.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37e8ad8dffe6ca05c7b45ad93b70dfe7',
      'native_key' => 'package_installer_at_top',
      'filename' => 'MODX/Revolution/modSystemSetting/ee91abf0b4abb58a04448dda17b41887.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ffdb7206ea52cf71599aa53bec66291',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/5d0a5e7f648cfa51287ba9ab27e8d8a5.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74f03d9f4f1daa9ef60fa050a793ab28',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/8860244ce37cf66dbda955760ea3fed4.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1295711d8ef1d1e17216934d4464e938',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/b7ab236e64c79b6aef2c33c2e2caf66b.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e78471e4bc2180553db6b8057e966595',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/b7a27d83bbec0f79952afabfb697f1af.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a97b2cc8f8c9418562e3c2db4e74e27',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/3ca543cf2146f4662ee09263dfab2f6c.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'adb356264b6c877991f6c5cd4300e375',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/c793899042794079f0f1f11d0edb58b4.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd8bb4e1e0482a90859d477322eeb9529',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/0eca4b98008594a4a9ccff6ee7b3ca04.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ab57519eb9b5cc550d63fdf50544ba6',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/a89b0b4ab4c64d1390ef04e9e6265dd1.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21e156f2c26727e7544c34149d9604b8',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/8b536e51f78edce8ecea8099a98a53a5.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b5753399c08a94d636f33dd6d1d4a1e4',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/90cbd85cc00ea05bd2b0d24745265c26.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7ab203d5f09c1cb694b789643d78835f',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/e66e348aa758f7cfee907818269096f1.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'adbdf02d459ed559b3b26b09bcaa942e',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/5777ac3169d6161c66dc02d5485e563d.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5fcad6459ee9bb647dc4ccc18128938',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/00532d50f454974454e9208edaa3523c.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '00b23657185ecec588fdfea0cc8178f2',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/6e14429253ac0c92ab1ccd86e55494a0.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fd433cf8bee7f7b0a4d8eb89c8710ffa',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/f339c705096cb2dd4e266c3ad7f5ab40.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '026e7eadbc9dc348ad0681c180746cb1',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/c10248908a659c3444467c3b260bf6c6.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac892a1999dc5ba60d48d0f0a7b6c9c7',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/a508733c1e0b51cc549fc4e67ddf7f98.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '967861ae7ee0aed11aa88c6dfaa953a0',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/7d0beafcea332d47e245570468b3d79b.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7981bd6572cebe67c7873d4884bd889e',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/6871388cd5ff4b0424419b0c5380fb68.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '13a3cd1a546562baef76a37c67cae1a8',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/d30a482593afd18ef2c112451e50e50e.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'caf6e06bc890a78dc8fff31bb9b304b0',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/117b1f12e6c4ab90e8a951e0b02937f5.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f9b717252fce338aff7d1382e2ee7c7',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/07c26768539701620f5d9fe4a8e1cc75.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7701f87b56fc0470d9d41362fcb3f14a',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/956e6abe5834b1d84eb0b12507192bcb.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a5cf29070fe35b81cbc2a91ba7163976',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/2afc391e505fbcdd5fb44e421587b14a.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e3132f5b1e4250b26f1f286da500b508',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/a000219c53a0a9cf499ce20581089279.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6d1feb7f4f594e45daea59f1a14bfe84',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/ed15965617714be815dd4cb92f88a747.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f112baf42517298f68eec1cd4cefe8cb',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/55096e90c9e0fb26d7f6b0cd2d95b85a.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99500a9326213a5d2d1ba2f5bce27cc7',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/08fbb89a31788dc9ea1f21ebf522d5af.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3a607bc1ffc68a6cd1bcf71cdf0f05a9',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/51e140eac8d64e9c45f63e4cc40b0a7e.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a429208b06fb58afaae3aa38fbf21a7b',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/ce90770bdb6dae4c35cea6a841dd3bc5.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cde1990a5bdeac7646fc7ec68e53d5e6',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/8f7d44f3cb840ccc9d0e6e66efca974e.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '34f2546bd04a1148e85fc6ea0fc026fb',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/18bf5c7a118dfabc0d8361b57bc52bec.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '112ac9c43fba48e1ec75da2864a7666c',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/bdb9132f921de1de37804bd615ba3085.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '465a10b729238b2ad668594b67a46319',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/574d0f1cb9c0891ffd82fe9624c59ab6.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '55503bfaecef00f2a0d5e6348715c7c1',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/4d7e89e34383631ae8a645321d7e111e.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd07e86ece0caea42d8bf889b1954f67e',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/08d9b122aae7df883720f5c2ec5ae6d7.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91e74f7767a18c74fb9d7e636d71860a',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/de979f78cd8f4a2bba5576a438e2fd71.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '94b64624ef6a31c0e39ee68cd2241665',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/afb6c6451bb251d951f975549c9ba0c5.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c7daa6e66ea364a37b8bf7944ad6ba5a',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/a0d852fbf27140c7b66829b95b533327.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'df966c723848707bed558b77267fa56a',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/edf91085b1e2d9a0a0c611b286f36697.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b64f870e3ae27c4ce70bbdf5ab8d905c',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/e785529eb7653014d74414b11af45d78.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '33203a44ae7b6ca0e24b18dc0c3ced3b',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/b5abd6a1089257e00a3ae37d429e940f.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f70ca0368beeebba822649394c77362',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/c730fcad7972b073aea500c3ea4493e8.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6202b4b24e67b35deff0bb86d8a694f7',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/04a99fae7a49b3b61a967c74e0fdcdfb.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ab070ebf4048f322ee2252c366195d4e',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/ea327faebabdbd74f9475a2c573c0fb5.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd02fd64bb9650c0aa4cd407fdfd3f48c',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/da12cfac697670efa6f89a7f7cea7b46.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e89a6595c87ee5ba3b22585008ea82aa',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/41ed2c46ddc60d05ff54849d190be694.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b5c09f81b2d9c68900351785b72fb00',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/bb552a3784e28b4aa0d35c742355e6f1.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a8bdfaf17648557d0a4e2a1d46f5c962',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/6b2c4583c2234f66d923b86853e1cca6.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3ed0a8adb6bdc585d924d89bca9b82d5',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/0296a967bfd22a2592df92604321654c.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ba0137cef1e8be505bbfa6ddf383d867',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/c3eabcc26ca56072dd739c82b6a0728b.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c61749e161fed440588d5d2c55cc85c8',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/efd4bc251b3d74829af03aa9e4588d48.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8c0ad7ca9f811c7ac630074bc6bbd4fc',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/529f847f8bbfd4e108e3cabc36c62e10.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8c599d30240a7f6e167878e3dba82993',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/d2613c682843e8e7f6d6ba45eaef7990.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b5518745281d81df9975e8cd61b71d72',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/b80b830c1907c00e7eee6fb3394ca7c0.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bfa8540c07e6fb7c33e08105003032bc',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/7e817a041af41710ea9e276938922ed2.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '77bbf4c6d8b0cb922ac1eebb32ece88b',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/ff2966be86090cb146f5ad3554f86ef7.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4cacbdea2fb64f3a585c42de65c069f5',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/7e0d4a30b1fd8ae3ba991902a4e8c94e.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5dd9c8841329b96addae4ce61c24b647',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/314f667efd7b27bbbb33055e01fbdea2.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '642cbeac9dd27605b9963303837e4257',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/1980e6708843f9bff745705b1a21c7f8.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a2f4abb8efba8b08208069f8dee39f15',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/085d5edfbb9df440aaf314e1131b4d74.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f772cd79c14c75c00351570fc7ddf62',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/5d9ac68aa16e37bc8a50791ed60a0be2.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f9a4e077bd768c95c0f484268fbf6db',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/cebd2569aa6bbeb06d93847a92823a3c.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b83adad5ab1b1f8961afcf38c7bfab62',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/c82f65cf35a8b7f4d676911baa27872a.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '837e130b397e3390e2808bd1538cb5ec',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/885d4e1f60077917196f39b657b70836.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c23245be18d6318ddf42bcdfb90cb37b',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/9cdbae1b94d48ad45eaf57d229cb9017.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8270f16aa9ccbe94981bc301c217dc55',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/3090182728e837cf27c39c4f22ad523b.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e3197369014cce32fcba4ad680f02f82',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/958a9c9f7a4461835759f13ed71c7598.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '671581f7d2dbc9050226706c4fd9d89d',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/b4aa6aad227da3e22832d1d4f1accc8e.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '09e5ac87d6454a90fbf398b84d938f5c',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/941b8f5699fd4974f2b05783cf81b4dc.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4215b175cf9d12e7d0cc856057b6ae35',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/2c79f283614db5141f2f04482b9ac965.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1dd9d731985daf2be3ed6ee3d4ac6173',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/194340785abd283027abcc61ee6f98fb.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1a0cb72acb6ee14698ae768463d1d31d',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/b9f3a988a12034dd52e153a31cb978b8.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '119104f6b776a589baae314123ce2b9d',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/22bcfd65a8fa28598781391df8b5d1ec.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '85fe62f650967231b2597feae99c3070',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/de395454f8f8cd1df051f6e1c8bff0c9.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '387d772fd2118a8a49b0cabac6bbb393',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/f6635fe7e687e6bd7df885e23dcb90b2.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ffcb52890bf231caea213f5ba7b27c96',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/37842bc0f05357db39b54878ef90ee29.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '00f728041a36dcf4d8c82810c8913fbd',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/74f59dc7277f99d11025882dbac5c0be.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd7fc5f4da7c732eed773426128a178cc',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/8af9e127fae973da1a3b245a62bcbcd2.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc8ad76b5354dec3242b293fb43b150c',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/4a507547cc147f43ffccfa8920609251.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1342583fa963dc58b0ef6a7cfc3a2b87',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/899b9b4ef92ea938159d7f8e3d27eb1c.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1c659410fe98d15a54778a436f507169',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/ae4da2bcfe91b3b874a99cad4acc4ab3.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '19812c89b0ac0b9df0df6c237be36ff8',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/836483f026d2098d02a8ab789a0cd2df.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0461b6fae178169358a6bf7073242d50',
      'native_key' => 'upload_translit_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/d399e4e77021da77f03dbe94b4900165.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3ecbf527a903c864e7abe4adc7500b0',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/ccc67b07d8e57a0522d72a44b868afbf.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '96e4812068a0fc190cb42e20ef2cc083',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/0c15b05554eb96f751ce92f44265b715.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74d93f5f152d0ba89e522e84b3b49f9f',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/f5bff3fde78c77e6674d5ff2a21c9b5c.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6b32620f68abd10d444c2aaf548c412c',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/c1aa64b94b597165fa9a867d3fba6eb2.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eb9946569cee27a7bce5e92bc7c9c7e4',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/96f26af75d115e3012944ca298861329.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f1a938af92e3a608d71cb8f057f8019',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/a0166191ad16c320ece29e8ae3d0f2e4.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3d97d558d96d9302d1ef4a0f2cb702f',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/779c391eb7a46303c511e6f4a0c0aae7.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c2529919992662b2a4891bfd6bf53df2',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/9dc7e6abc9671af5abbd1658b419c14e.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '40059216598a8dd66737bb4518b7917e',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/90b43f16d7cb13f2510b027f2030595e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '12cbee939388cf5c1552306c093ac4e5',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/dfbbaebe8913a25e8486fff26b83ba4e.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '404236bff2399b9b76524d9a94a5d1a5',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/7b11d89619f8ef3715b0aa9ed4235ae7.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e92e9baff89d823904d357fd4c8d6e8d',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/ff5d020377679cfc62647d6fbbd96ae0.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '44917212a0fb9ec120d2ea4ad37a555f',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/b881de450615bddf5102bdc2cad82e6d.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '825e1898d972c66028f552d398407367',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/bb5c3505e890c208004c8586df50593f.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b912735fa97f73d31db14057b61a4512',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/5392df569ecb12dc564c8b556b7c4f40.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60b088152c35459f63e0ef0fbd37b415',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/41f1713a3569ffec3bb713abb1cbb37a.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '34032a5f1b653bbc57dd2e4b2733d365',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/5241ce1cecf1bc2a70c222c43783fc5b.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c3c6bd89262f7688456a44214fb137b6',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/bfdf281c8964e69e777877ba5e8e1958.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ceacfcde7c5220b72bcc5a33aa5fcae',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/0300167dccc4756c64643cbac23fb350.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2e423397ba04f8295fd0390894b5e8a7',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/062760b8a3a367563aff4499eef73918.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2dd5686d9b2e98ba868f1c84034faba9',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/9557a5c4aed59332f4ecdfbd64bfbfdc.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be2f89ffc0896a91b5a3644e76fd79d3',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/f3b4a939a6c7a06ac68a346ff7bb9a46.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4dd216854b75b99e57fc18e1ed057f6b',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/1862d2f8e2e774da22a2e235fb7d1092.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f407fcd6641a4839e07454bf285d5c39',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/980e5bed6953805ab441af6546640444.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2dda28ac1ad92b6c5dbb6226bef57e12',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/ae01b346dac554346bfcb0dc4b01c147.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '746f7062cccd25b271639e26730a15c7',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/ba4169f7a5ab04f281b74649245d5097.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => 'e1938f2317b12157932021d48d2b525a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/bbbd98e8b8e8a672b8d9a8abd30554fa.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '23ea9107fb2f1a4ed450afda0bc1dce4',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/651dbc630e60eb53a97659fee6663d4f.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => '8ae219a01c100bf39fca4634bb380f59',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/986e2e5925ecc915601297c2840b87f8.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => 'cf263fab21d4b1964f8e87b99ebc27b1',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/bf19e57f740f8895ef4885ab26ca1ade.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => '98dbf987d3445cd942aace8b66f3734d',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/4dae20202da05162c1d337a89d6b05c7.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'a3268967e7a72e58b0d63202288cec9f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/b6af9b81a93bef3e420e310eef69749b.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '2abbb75606059207d4e783cd97626404',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/1af9304ff33b868847f852d0d7aede75.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '209589b3db9d7c6ef9d08e6d414e2646',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/5aebbba82af072132ea72fc7c845b3b5.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'e63179d736013aa8c06f7f4bfa19dc76',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/d0760500a9c657762a0fa8b03a4bf111.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '7352a3ccdd98400b6a4706d41cecb923',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/08ffcf3a0b2be4172252b4336bd0188f.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'f59d0c4dc52dd94914f965333a86322f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/843e7ef4c4012c87096d5a4458245d9d.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'addaa0f1cb2cecd17d1d3f801c8a5044',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/128226ac14111c7fb9e225483e2b91ca.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => 'de9b53105f8716ac8cbef97bbfb4d8dd',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/db390bb29908012b94df6461e89bed0e.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '69738de0d6efe59982859758ada2002f',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/516f7b0e9d199bf86617226a034547a5.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'aba911c97df78e05a4d4640c561b5357',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/a048ac63c2c873a75b15ac16df6c7131.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '52f8612d9aec9714c8b99449b5704179',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/da0ba616669bd8375f1b7724e3967b82.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '60a329c07d81c1956bf93d9fd2a38254',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/d6ea215299c3e0f31c39a32d691b9798.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '5c2a6f081b8e4ca6ef9f458731e2b08f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/45b30e1fdbc6067a525a5c5added284d.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '96fb3d1718c3e447caf8ec59ac55ebae',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/7a1f1782d0517f397a3e64ce46ab1642.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '2d9347877915cf29b1c9dd7b544e1ea4',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/a8be9c00ee68b9a0aa01b851d1d4a9d3.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '9ba6a128662244daceb5e6024b5a6e76',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/606344b616339f5f67500be7d54752fc.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'e6b51fd2fbef5c3ea93c5bec92a8f58e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/ccaadb3a8fdc985db180b6c6f85e6335.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'e3bb2e0f6ec307dce4b870f1186df625',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/9b02e5afa20fc1113d79f0016c6f149a.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '0167070e295ad5999f4823ea409b051f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/3d1aa800ad036a5e88e39a3116bf6793.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'c45b58d2ba0307d7c40667af52aba50e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/21e33d6164e95527314ca3c7ce1343ba.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '32876d9f266e38b9f2c640e52a453b0e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/0ad2b49b3626304c018a890b2c33d86a.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '4e2a5262fcb3595af07cf11e2e8c4d45',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/459566ba63429f77f7db00a16900c1ab.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '32ffe00a0e267ae1fbe07a05946bb631',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/df56b5f43c79a34479093e7c88df65e3.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '030522d09958a7946aaaf01962b96ee2',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/1698260cf5bd35c93030789ae940ede6.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '1473b0bb21ccfbc566795236449369fd',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/1d6169e077515f61741cce97589619e1.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '02e872365a7bceb3fff854ce8d450343',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/b5e34f176944c7e6550c7fe908c9f3ed.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'd15ca5eee38ec9f6967db350b5c5038a',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/733025b2eba8b3a73fee4996487b5dbc.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '072e8f2ce1faf3ec3a487165ec9fd489',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/c286ea6a57e1caa425e473b9a2f74c09.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '288f3f6603ef7353b7244a36ee19c6c0',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/892082d61baa1b4824e83ca09202a995.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'f011cc89e523a001bb554c5c3048afcb',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/bf9a6e3bdc0b5d2b44c7707964228360.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ed78b3bfbdbf8636c47ac041c380a903',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/f951e5870d892a9fb841e75626d707c6.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '058ffd0cb6eb16d034d4edff52e0e10a',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/ab572fa554a2908ef8afac0b21b26d26.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'b209d9374fb56954bec00f7940131366',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/3bf3f012a7c3af4b89e537eff6591f9c.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '511753ac2e286b2043bc93117534be4f',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/f3d4d64dbcc95432dc74bf9ef70fc15d.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ecebbc976cf349b8d2a9e31dbb4d6834',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/1422ef8ba35bd251c3a9aeaebf8a919c.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '9f19027f0661ea88c79853a2a066d326',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/a37eb76cfe1e79bee598c874f684b53c.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => 'bf9f1d67b2e057ff1bb5bcc82a57bf28',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/f7042837ebd5538e18ef195d614e9dad.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '9d0f4b81468f823fc0c4b4846824f903',
      'native_key' => '9d0f4b81468f823fc0c4b4846824f903',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/8bfd9354405849d83fce7ff20ef5c675.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '31b8b34dc7d67438f6f73846e8f240da',
      'native_key' => '31b8b34dc7d67438f6f73846e8f240da',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/6bc81fc77ae1ca808167d6a71f404cc0.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '680bb9527629e0b8d56db2b78e2811f3',
      'native_key' => '680bb9527629e0b8d56db2b78e2811f3',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/9b952c39ba6ba64eda3b5f58fffb0a63.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '42e7f19916b270a9946131b35573ff77',
      'native_key' => '42e7f19916b270a9946131b35573ff77',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/5ce8dd9f23113c51b05b2cf114b16f5f.vehicle',
    ),
  ),
);